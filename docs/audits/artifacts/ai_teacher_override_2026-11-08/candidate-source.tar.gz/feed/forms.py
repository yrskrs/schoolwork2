"""
Форми Django для SchoolNet.

Включає:
    - AssignmentForm      — створення та редагування завдань
    - TeacherLoginForm    — вхід вчителя
    - ClassSelectForm     — вибір класу для учня
    - TeacherProfileForm  — редагування профілю вчителя
"""

import os
from django import forms
from django.core.exceptions import ValidationError
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Q
from .models import Assignment, Teacher, ClassGroup, Subject, Student
from .roster_identity import has_stable_class_roster
from .outside_students import teaching_classes


# ─── Кастомний widget для множинного завантаження файлів (Django 6+) ───────────
class MultipleFileInput(forms.FileInput):
    """HTML5 FileInput з атрибутом multiple для вибору кількох файлів."""
    allow_multiple_selected = True

    def __init__(self, attrs=None):
        default_attrs = {'multiple': 'multiple'}
        if attrs:
            default_attrs.update(attrs)
        super().__init__(default_attrs)

    def value_from_datadict(self, data, files, name):
        """Повертає список завантажених файлів."""
        if hasattr(files, 'getlist'):
            return files.getlist(name)
        return files.get(name)


class MultipleFileField(forms.FileField):
    """Поле форми що приймає кілька файлів одночасно."""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault('widget', MultipleFileInput(attrs={
            'class': 'form-file-input',
            'accept': '*/*',
            'id': 'id_files',
        }))
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        # Якщо порожньо — повертаємо пустий список
        if not data:
            return []
        if not isinstance(data, list):
            data = [data]
        office_exts = {
            '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
            '.odt', '.ods', '.odp', '.pdf',
            '.accdb', '.mdb', '.accde', '.mde'
        }
        result = []
        for item in data:
            if not item:
                continue
            fname = getattr(item, 'name', '') or ''
            base_name = os.path.basename(fname)
            ext = os.path.splitext(base_name)[1].lower()

            # 1. Службові файли блокування (Access .laccdb/.ldb, Word/Excel ~$..., LibreOffice .~lock...)
            if ext in ('.laccdb', '.ldb'):
                raise ValidationError(
                    f"Файл «{base_name}» є службовим тимчасовим файлом блокування Microsoft Access ({ext}). "
                    "Схоже, ця база даних зараз відкрита в Access. Будь ласка, збережіть її, "
                    "закрийте Microsoft Access та оберіть ваш основний файл бази даних (.accdb або .mdb)."
                )
            if base_name.startswith('~$') or base_name.startswith('.~lock.'):
                raise ValidationError(
                    f"Файл «{base_name}» є тимчасовим службовим файлом автозбереження/блокування. "
                    "Схоже, цей документ зараз відкритий у програмі. Будь ласка, збережіть його, "
                    "закрийте програму (Word, Excel тощо) та оберіть ваш основний збережений документ (без знаків «~$» на початку)."
                )

            # 2. Порожні офісні файли та бази даних (0 байтів)
            if getattr(item, 'size', 0) == 0 and ext in office_exts:
                if ext in ('.accdb', '.mdb', '.accde', '.mde'):
                    raise ValidationError(
                        f"Файл «{base_name}» порожній (0 байтів). "
                        "Якщо ви зараз створюєте базу даних у Microsoft Access, зміни ще не збережено на диск. "
                        "Будь ласка, збережіть файл бази даних, закрийте Microsoft Access та прикріпіть його (.accdb або .mdb) повторно."
                    )
                else:
                    raise ValidationError(
                        f"Файл «{base_name}» порожній (0 байтів). "
                        "Якщо ви зараз працюєте над ним у Word або Excel, зміни ще не збережено на диск. "
                        "Будь ласка, збережіть документ («Файл» → «Зберегти»), закрийте програму та прикріпіть його повторно."
                    )

            # 3. Перевірка на ексклюзивне блокування читання файловою системою
            try:
                if hasattr(item, 'seek'):
                    item.seek(0)
                item.read(512)
                if hasattr(item, 'seek'):
                    item.seek(0)
            except (PermissionError, OSError, IOError):
                raise ValidationError(
                    f"Не вдалося прочитати вміст файлу «{base_name}» (файл заблокований або відкритий в іншій програмі). "
                    "Будь ласка, збережіть та закрийте програму (Word, Excel, Access тощо), де відкрито цей файл, і спробуйте знову."
                )
            result.append(super().clean(item, initial))
        return result


# ─── Форма авторизації вчителя ─────────────────────────────────────────────────

class TeacherLoginForm(forms.Form):
    """Форма входу вчителя (username + password)."""

    username = forms.CharField(
        label='Логін',
        max_length=150,
        widget=forms.TextInput(attrs={
            'placeholder': 'Введіть логін',
            'autocomplete': 'username',
            'class': 'form-input',
        })
    )
    password = forms.CharField(
        label='Пароль',
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Введіть пароль',
            'autocomplete': 'current-password',
            'class': 'form-input',
        })
    )


# ─── Форма майстра першого запуску ───────────────────────────────────────────
class FirstRunSetupForm(forms.Form):
    """Форма створення головного адміністратора при першому запуску системи."""

    username = forms.CharField(
        label='Логін адміністратора',
        max_length=150,
        initial='admin',
        help_text='Латинські літери, цифри та символи @/./+/-/_',
        widget=forms.TextInput(attrs={
            'class': 'form-input',
            'placeholder': 'admin',
            'autocomplete': 'username',
            'required': 'required',
            'autofocus': 'autofocus',
        })
    )
    full_name = forms.CharField(
        label='ПІБ вчителя / адміністратора',
        max_length=200,
        initial='Адміністратор системи',
        help_text='Буде відображатися учням та в журналі',
        widget=forms.TextInput(attrs={
            'class': 'form-input',
            'placeholder': 'Іваненко Іван Іванович',
            'required': 'required',
        })
    )
    email = forms.EmailField(
        label='Email (необов\'язково)',
        required=False,
        widget=forms.EmailInput(attrs={
            'class': 'form-input',
            'placeholder': 'admin@school.ua',
            'autocomplete': 'email',
        })
    )
    password = forms.CharField(
        label='Пароль',
        min_length=6,
        widget=forms.PasswordInput(attrs={
            'class': 'form-input',
            'placeholder': 'Введіть надійний пароль (мін. 6 символів)',
            'autocomplete': 'new-password',
            'required': 'required',
        })
    )
    password_confirm = forms.CharField(
        label='Підтвердження пароля',
        widget=forms.PasswordInput(attrs={
            'class': 'form-input',
            'placeholder': 'Повторіть пароль',
            'autocomplete': 'new-password',
            'required': 'required',
        })
    )
    seed_default_data = forms.BooleanField(
        label='Ініціалізувати базу стандартними предметами та класами НУШ',
        required=False,
        initial=True,
        help_text='Автоматично створить популярні шкільні предмети (Інформатика, Математика, Фізика...), класи (9А, 10А...) та шкали критеріїв НУШ'
    )

    def clean_username(self):
        username = self.cleaned_data.get('username', '').strip()
        if not username:
            raise ValidationError('Вкажіть логін адміністратора.')
        if User.objects.filter(username__iexact=username).exists():
            raise ValidationError(f'Користувач з логіном "{username}" вже існує.')
        return username

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        password_confirm = cleaned_data.get('password_confirm')

        if password and password_confirm:
            if password != password_confirm:
                self.add_error('password_confirm', 'Введені паролі не збігаються.')
        return cleaned_data


# ─── Форма вибору класу учнем ─────────────────────────────────────────────────
class ClassSelectForm(forms.Form):
    """Форма вибору класу учнем при вході до стрічки."""

    class_group = forms.ModelChoiceField(
        queryset=teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter'),
        label='Ваш клас',
        empty_label='— Всі класи —',
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )


# ─── Форма профілю вчителя ────────────────────────────────────────────────────
class TeacherProfileForm(forms.ModelForm):
    """Форма редагування профілю вчителя."""

    class Meta:
        model = Teacher
        fields = ['full_name', 'avatar_color', 'avatar_image']
        labels = {
            'full_name': 'ПІБ вчителя',
            'avatar_color': 'Колір фону аватара',
            'avatar_image': 'Фото аватара',
        }
        widgets = {
            'full_name': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Шевченко Тарас Григорович',
            }),
            'avatar_color': forms.TextInput(attrs={
                'type': 'color',
                'class': 'form-color-input',
            }),
            'avatar_image': forms.FileInput(attrs={
                'class': 'form-input',
                'accept': 'image/*',
                'id': 'avatar-file-input',
            }),
        }


# ─── Форми створення Предметів та Класів ────────────────────────────────────────
class SubjectForm(forms.ModelForm):
    """Форма створення новий предмету."""

    class Meta:
        model = Subject
        fields = ['name', 'icon', 'color']
        labels = {
            'name': 'Назва предмету',
            'icon': 'Іконка (емодзі)',
            'color': 'Колір (HEX)',
        }
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Наприклад: Астрономія'}),
            'icon': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '🌌'}),
            'color': forms.TextInput(attrs={'type': 'color', 'class': 'form-color-input'}),
        }


class ClassGroupForm(forms.ModelForm):
    """Форма створення нового класу."""

    class Meta:
        model = ClassGroup
        fields = ['name', 'grade', 'letter']
        labels = {
            'name': 'Назва класу',
            'grade': 'Паралель (номер)',
            'letter': 'Літера',
        }
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Наприклад: 9А'}),
            'grade': forms.NumberInput(attrs={'class': 'form-input', 'placeholder': '9'}),
            'letter': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'А'}),
        }


# ─── Форми супер-адміністратора ───────────────────────────────────────────────
class TeacherCreateForm(forms.Form):
    """Форма створення нового облікового запису вчителя (для Супер-Адміна)."""

    username = forms.CharField(
        label='Логін вчителя',
        max_length=150,
        widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'teacher_ivanov'})
    )
    password = forms.CharField(
        label='Початковий пароль',
        widget=forms.PasswordInput(attrs={'class': 'form-input', 'placeholder': '••••••••'})
    )
    full_name = forms.CharField(
        label='ПІБ вчителя',
        max_length=200,
        widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Іванов Іван Іванович'})
    )
    is_superuser = forms.BooleanField(
        label='Надати права Супер-Адміністратора',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-checkbox'})
    )

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise ValidationError('Користувач з таким логіном вже існує.')
        return username


class PasswordResetForm(forms.Form):
    """Форма скидання пароля вчителя."""

    user_id = forms.IntegerField(widget=forms.HiddenInput())
    new_password = forms.CharField(
        label='Новий пароль',
        widget=forms.PasswordInput(attrs={'class': 'form-input', 'placeholder': 'Введіть новий пароль'})
    )




# ─── Форма завдання ────────────────────────────────────────────────────────────
class AssignmentForm(forms.ModelForm):
    """
    Форма створення та редагування завдання.

    Валідація: обов'язкова наявність хоча б одного з:
        - опис (description)
        - файл (файли додаються через AssignmentFileFormSet)
        - посилання (link_url)
    """

    cloud_imports = forms.JSONField(required=False, initial=list, widget=forms.HiddenInput)

    # Поле для вибору типу публікації (замінює поле status напряму)
    PUBLISH_CHOICE_NOW = 'now'
    PUBLISH_CHOICE_SCHEDULED = 'scheduled'
    PUBLISH_CHOICE_DRAFT = 'draft'

    PUBLISH_CHOICES = [
        (PUBLISH_CHOICE_NOW, '✅ Опублікувати зараз'),
        (PUBLISH_CHOICE_SCHEDULED, '⏰ Відкласти публікацію'),
        (PUBLISH_CHOICE_DRAFT, '📝 Зберегти як чернетку'),
    ]

    publish_choice = forms.ChoiceField(
        choices=PUBLISH_CHOICES,
        initial=PUBLISH_CHOICE_NOW,
        label='Публікація',
        widget=forms.RadioSelect(attrs={'class': 'publish-radio'}),
    )

    scheduled_at = forms.DateTimeField(
        required=False,
        label='Дата та час публікації',
        input_formats=['%Y-%m-%dT%H:%M', '%d.%m.%Y %H:%M'],
        widget=forms.DateTimeInput(
            attrs={
                'type': 'datetime-local',
                'class': 'form-input',
            },
            format='%Y-%m-%dT%H:%M'
        )
    )

    due_date = forms.DateField(
        required=False,
        label='Термін виконання',
        input_formats=['%Y-%m-%d', '%d.%m.%Y'],
        widget=forms.DateInput(
            attrs={
                'type': 'date',
                'class': 'form-input',
            },
            format='%Y-%m-%d'
        )
    )

    # Файли завантажуються через MultipleFileField (підтримує кілька файлів)
    files = MultipleFileField(
        required=False,
        label='Прикріпити файли',
    )


    class Meta:
        model = Assignment
        fields = [
            'subject', 'title', 'description',
            'classes', 'is_individual', 'student_name',
            'link_url', 'link_label', 'youtube_url',
            'due_date', 'scheduled_at',
            'no_submission_required',
            'allow_student_ai_check', 'allow_ai_usage',
            'ai_thinking_mode',
            'allow_student_ai_understanding',
            'custom_criteria',
            'teacher_ai_instructions',
        ]
        labels = {
            'subject': 'Предмет',
            'title': 'Тема / Заголовок',
            'description': 'Опис завдання',
            'classes': 'Призначити класам',
            'is_individual': 'Індивідуальне завдання (для конкретного учня / учениці)',
            'student_name': "Прізвище та ім'я учня / учениці",
            'link_url': 'Посилання (URL)',
            'link_label': 'Текст посилання',
            'youtube_url': 'Посилання на YouTube',
            'no_submission_required': 'Не вимагає здачі робіт (усне / для опрацювання)',
            'allow_student_ai_check': 'Дозволити учням 1 самоперевірку через ШІ',
            'allow_ai_usage': 'Дозволити учням використання ШІ при виконанні завдання',
            'ai_thinking_mode': 'Режим глибокого мислення ШІ (Thinking mode)',
            'allow_student_ai_understanding': 'Дозволити учням бачити аналіз ШІ («Як ШІ розуміє завдання»)',
            'custom_criteria': 'Індивідуальні критерії оцінювання для цього завдання',
            'teacher_ai_instructions': 'Вказівки для ШІ при оцінюванні (приховано від учнів)',
        }
        widgets = {
            'subject': forms.Select(attrs={'class': 'form-select'}),
            'title': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Наприклад: Параграф 12, вправа 5',
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-textarea',
                'rows': 5,
                'placeholder': 'Детальний опис завдання, умова задачі...',
            }),
            'classes': forms.CheckboxSelectMultiple(attrs={'class': 'class-checkbox-group'}),
            'is_individual': forms.CheckboxInput(attrs={
                'class': 'form-checkbox',
                'id': 'id_is_individual',
            }),
            'student_name': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': "Прізвище та ім'я учня або учениці",
            }),
            'link_url': forms.URLInput(attrs={
                'class': 'form-input',
                'placeholder': 'https://...',
            }),
            'link_label': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Відкрити підручник, Переглянути відео...',
            }),
            'youtube_url': forms.URLInput(attrs={
                'class': 'form-input',
                'placeholder': 'https://www.youtube.com/watch?v=... або https://youtu.be/...',
            }),
            'no_submission_required': forms.CheckboxInput(attrs={'class': 'form-checkbox'}),
            'allow_student_ai_check': forms.CheckboxInput(attrs={'class': 'form-checkbox'}),
            'allow_ai_usage': forms.CheckboxInput(attrs={'class': 'form-checkbox'}),
            'allow_student_ai_understanding': forms.CheckboxInput(attrs={'class': 'form-checkbox'}),
            'custom_criteria': forms.Textarea(attrs={
                'class': 'form-textarea',
                'rows': 4,
                'placeholder': 'Вкажіть специфічні критерії, розбаловку або правила перевірки для цього завдання (будуть показані учням та враховані ШІ)...',
            }),
            'teacher_ai_instructions': forms.Textarea(attrs={
                'class': 'form-textarea',
                'rows': 3,
                'placeholder': 'Наприклад: Для 7-Б класу бути лояльнішим до оформлення: якщо учні не створили бюлетень, але знайшли інформацію — не занижувати бал за оформлення, головне зміст роботи...',
            }),
        }

    def __init__(self, teacher=None, *args, **kwargs):
        """Ініціалізація: відображає класи та предмети даного вчителя (або всі, якщо не вказані)."""
        super().__init__(*args, **kwargs)
        self.teacher = teacher
        self.cloud_jobs = []

        if teacher:
            if teacher.subjects.exists():
                self.fields['subject'].queryset = teacher.subjects.all()
            else:
                self.fields['subject'].queryset = Subject.objects.all()

            if teacher.classes.exists():
                self.fields['classes'].queryset = teaching_classes(teacher.classes.all()).order_by('grade', 'letter', 'name')
            else:
                self.fields['classes'].queryset = teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter', 'name')

            default_subject = teacher.get_default_subject()
            if default_subject and not self.initial.get('subject'):
                self.initial['subject'] = default_subject.pk
        else:
            self.fields['subject'].queryset = Subject.objects.all().order_by('name')
            self.fields['classes'].queryset = teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter', 'name')



        from .models import AICriteriaPreset
        presets = list(AICriteriaPreset.objects.all())
        self.ai_policy_presets = [{'id': preset.pk, 'type': preset.evaluation_type, 'grs': preset.get_gr_list()} for preset in presets]
        gr_choices = dict((gr['code'], gr['code'] + ': ' + gr.get('name', ''))
                          for preset in presets for gr in preset.get_gr_list())
        self.assessment_rows = []
        self.fields['default_ai_preset'] = forms.ModelChoiceField(queryset=AICriteriaPreset.objects.all(), required=False)
        for class_group in self.fields['classes'].queryset:
            preset_key, gr_key = f'class_ai_preset_{class_group.pk}', f'class_ai_grs_{class_group.pk}'
            previous = (self.instance.class_ai_overrides or {}).get(str(class_group.pk), {})
            self.fields[preset_key] = forms.ModelChoiceField(
                queryset=AICriteriaPreset.objects.all(), required=False,
                empty_label='Критерії завдання', initial=previous.get('preset_id'),
                widget=forms.Select(attrs={'class': 'form-select'}))
            self.fields[gr_key] = forms.MultipleChoiceField(
                required=False, choices=list(gr_choices.items()), initial=previous.get('grs', []),
                widget=forms.CheckboxSelectMultiple)
            self.assessment_rows.append({'class_group': class_group, 'preset': self[preset_key], 'grs': self[gr_key]})

        # Заповнення publish_choice з існуючого об'єкта (при редагуванні)
        if self.instance and self.instance.pk:
            if self.instance.status == Assignment.STATUS_DRAFT:
                self.initial['publish_choice'] = self.PUBLISH_CHOICE_DRAFT
            elif self.instance.status == Assignment.STATUS_SCHEDULED:
                self.initial['publish_choice'] = self.PUBLISH_CHOICE_SCHEDULED
            else:
                self.initial['publish_choice'] = self.PUBLISH_CHOICE_NOW

    def clean(self):
        """Валідація: перевіряємо наявність хоча б одного вмісту."""
        cleaned_data = super().clean()
        from .cloud_files import CloudStorageError
        from .cloud_imports import prepare
        try:
            self.cloud_jobs = prepare(cleaned_data.get('cloud_imports') or [], self.teacher, self.instance)
        except CloudStorageError as error:
            self.add_error('cloud_imports', str(error))
        description = cleaned_data.get('description', '').strip()
        link_url = cleaned_data.get('link_url', '').strip()
        files_uploaded = cleaned_data.get('files', [])

        # Перевіряємо що є хоча б щось
        has_existing_files = bool(self.instance and self.instance.pk and self.instance.files.exists())
        if not description and not link_url and not files_uploaded and not has_existing_files and not self.cloud_jobs:
            raise ValidationError(
                'Додайте хоча б одне з: опис завдання, посилання або файл.'
            )

        # Валідація відкладеної публікації
        publish_choice = cleaned_data.get('publish_choice')
        scheduled_at = cleaned_data.get('scheduled_at')

        if publish_choice == self.PUBLISH_CHOICE_SCHEDULED and not scheduled_at:
            self.add_error(
                'scheduled_at',
                'Вкажіть дату та час відкладеної публікації.'
            )

        # Валідація адресації (Кому призначено: обов'язково клас або індивідуально)
        is_individual = cleaned_data.get('is_individual')
        student_name = cleaned_data.get('student_name', '').strip()
        classes = cleaned_data.get('classes')

        if is_individual:
            if not student_name:
                self.add_error(
                    'student_name',
                    "Обов'язково вкажіть прізвище та ім'я учня або учениці для індивідуального завдання."
                )
        else:
            if not classes or classes.count() == 0:
                self.add_error(
                    'classes',
                    'Обовʼязково оберіть хоча б один клас або позначте як індивідуальне завдання.'
                )

        overrides = {}
        for class_group in classes or []:
            preset_key, gr_key = f'class_ai_preset_{class_group.pk}', f'class_ai_grs_{class_group.pk}'
            preset = cleaned_data.get(preset_key)
            grs = cleaned_data.get(gr_key) or []
            if preset:
                allowed = {gr['code'] for gr in preset.get_gr_list()}
                if preset.evaluation_type != 'traditional' and set(grs) - allowed:
                    self.add_error(gr_key, 'Оберіть тільки групи результатів цього шаблону.')
                overrides[str(class_group.pk)] = {'preset_id': preset.pk, 'grs': grs if preset.evaluation_type != 'traditional' else []}
        cleaned_data['class_ai_overrides'] = overrides
        return cleaned_data

    def cloud_import_descriptors(self):
        from .cloud_imports import describe
        return [describe(job) for job in self.cloud_jobs]

    def save_with_status(self, teacher, commit=True):
        """Зберігає завдання з правильним статусом на основі publish_choice."""
        instance = super().save(commit=False)
        instance.teacher = teacher
        instance.class_ai_overrides = self.cleaned_data.get('class_ai_overrides', {})

        publish_choice = self.cleaned_data.get('publish_choice')

        if publish_choice == self.PUBLISH_CHOICE_DRAFT:
            instance.status = Assignment.STATUS_DRAFT
        elif publish_choice == self.PUBLISH_CHOICE_SCHEDULED:
            instance.status = Assignment.STATUS_SCHEDULED
            instance.scheduled_at = self.cleaned_data.get('scheduled_at')
        else:
            instance.status = Assignment.STATUS_PUBLISHED
            if not instance.published_at or instance.duplicated_from_id is not None:
                instance.published_at = timezone.now()

        if commit:
            instance.save()
            self.save_m2m()

        return instance


# ─── Форма здачі роботи учнем ──────────────────────────────────────────────────

class SubmissionForm(forms.Form):
    """Форма здачі роботи учнем по конкретному завданню."""

    student_id = forms.IntegerField(required=False, widget=forms.HiddenInput())
    coauthor_ids = forms.CharField(required=False, widget=forms.HiddenInput())
    other_student = forms.BooleanField(required=False, label='Мене немає у списку класу')

    full_name = forms.CharField(
        label="Прізвище та ім'я",
        max_length=200,
        widget=forms.TextInput(attrs={
            'placeholder': "Наприклад: Іванченко Тарас",
            'class': 'form-input',
            'autocomplete': 'name',
            'id': 'id_full_name',
        })
    )
    class_group = forms.ModelChoiceField(
        label='Клас',
        queryset=ClassGroup.objects.none(),
        empty_label='— Оберіть клас —',
        widget=forms.Select(attrs={
            'class': 'form-input',
            'id': 'id_class_group',
        })
    )
    files = MultipleFileField(
        label='Файли роботи (можна прикріпити декілька)',
        required=False,
        widget=MultipleFileInput(attrs={
            'class': 'form-file-input',
            'accept': '*/*',
            'id': 'id_files',
        })
    )
    file = forms.FileField(
        label='Файл роботи',
        required=False,
        widget=forms.FileInput(attrs={
            'class': 'form-file-input',
            'accept': '*/*',
            'id': 'id_file',
        })
    )
    link = forms.URLField(
        label='Або посилання на роботу',
        required=False,
        widget=forms.URLInput(attrs={
            'placeholder': 'https://...',
            'class': 'form-input',
            'id': 'id_link',
        })
    )
    comment_student = forms.CharField(
        label='Висновки по роботі або коментар',
        required=False,
        widget=forms.Textarea(attrs={
            'placeholder': 'Напишіть висновки по роботі (якщо забули записати у файлі), номер завдання, коментар або співавторів...',
            'class': 'form-input',
            'rows': 3,
            'id': 'id_comment_student',
            'oninput': 'autoResizeComment(this);',
            'onfocus': 'autoResizeComment(this);',
        })
    )

    def __init__(self, *args, assignment=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.assignment = assignment
        if assignment:
            # Якщо завдання індивідуальне, автоматично підставляємо прізвище та ім'я учня
            if assignment.is_individual and assignment.student_name and not self.initial.get('full_name'):
                self.fields['full_name'].initial = assignment.student_name

            # Показуємо тільки класи, яким призначено це завдання (або всі)
            assigned_classes = assignment.classes.filter(integration_active=True).order_by('grade', 'letter', 'name')
            if assignment.classes.exists():
                self.fields['class_group'].queryset = assigned_classes
                first_class = assigned_classes.first()
                if not self.initial.get('class_group'):
                    self.fields['class_group'].initial = first_class
                self.fields['class_group'].empty_label = None
            else:
                self.fields['class_group'].queryset = teaching_classes(ClassGroup.objects.filter(integration_active=True)).order_by('grade', 'letter', 'name')
        else:
            self.fields['class_group'].queryset = teaching_classes(ClassGroup.objects.filter(integration_active=True)).order_by('grade', 'letter', 'name')

    def clean(self):
        cleaned_data = super().clean()
        from .models import Student
        import json
        group = cleaned_data.get('class_group')
        shared = has_stable_class_roster(group)
        pupil_id = cleaned_data.get('student_id')
        pupil = Student.objects.filter(pk=pupil_id, class_group=group, integration_active=True).first() if pupil_id else None
        if pupil_id and not pupil:
            self.add_error('full_name', 'Оберіть активного учня цього класу.')
        if pupil and cleaned_data.get('other_student'):
            self.add_error('full_name', 'Оберіть своє ім’я або позначте, що вас немає у списку.')
        if shared and not pupil and not cleaned_data.get('other_student'):
            self.add_error('full_name', 'Оберіть своє ім’я зі списку або позначте «Мене немає у списку класу» та введіть його вручну.')
        if pupil:
            cleaned_data['full_name'] = pupil.get_full_name()
        cleaned_data['selected_student'] = pupil
        cleaned_data['shared_roster'] = bool(shared)
        try:
            selected_coauthors = json.loads(cleaned_data.get('coauthor_ids') or '[]')
            if not isinstance(selected_coauthors, list) or len(selected_coauthors) > 5 or any(isinstance(v, bool) or not isinstance(v, int) for v in selected_coauthors):
                raise ValueError
            co_rows = list(Student.objects.filter(pk__in=selected_coauthors, class_group=group, integration_active=True))
            if len(co_rows) != len(set(selected_coauthors)):
                raise ValueError
            cleaned_data['selected_coauthors'] = [row for row in co_rows if row != pupil]
        except (ValueError, TypeError):
            self.add_error('full_name', 'Оберіть співавторів цього класу зі списку.')
            cleaned_data['selected_coauthors'] = []
        files = cleaned_data.get('files') or []
        file = cleaned_data.get('file')
        link = cleaned_data.get('link')

        raw_list = list(files) if isinstance(files, list) else ([files] if files else [])
        if file and file not in raw_list:
            raw_list.append(file)

        # Дедуплікація файлів за назвою та розміром (щоб уникнути подвійного завантаження)
        seen_keys = set()
        all_uploaded = []
        for f in raw_list:
            if not f:
                continue
            key = (getattr(f, 'name', None), getattr(f, 'size', None))
            if key not in seen_keys:
                seen_keys.add(key)
                all_uploaded.append(f)
        # Перевірка на заблоковані або тимчасові службові файли (Word, Excel, LibreOffice, MS Access)
        office_exts = {
            '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
            '.odt', '.ods', '.odp', '.pdf',
            '.accdb', '.mdb', '.accde', '.mde'
        }
        for f in all_uploaded:
            fname = getattr(f, 'name', '') or ''
            base_name = os.path.basename(fname)
            ext = os.path.splitext(base_name)[1].lower()

            # 1. Службові файли блокування (Access .laccdb/.ldb, Word/Excel ~$..., LibreOffice .~lock...)
            if ext in ('.laccdb', '.ldb'):
                raise forms.ValidationError(
                    f"Файл «{base_name}» є службовим тимчасовим файлом блокування Microsoft Access ({ext}). "
                    "Схоже, ця база даних зараз відкрита в Access. Будь ласка, збережіть її, "
                    "закрийте Microsoft Access та оберіть ваш основний файл бази даних (.accdb або .mdb)."
                )
            if base_name.startswith('~$') or base_name.startswith('.~lock.'):
                raise forms.ValidationError(
                    f"Файл «{base_name}» є тимчасовим службовим файлом автозбереження/блокування. "
                    "Схоже, цей документ зараз відкритий у програмі. Будь ласка, збережіть його, "
                    "закрийте програму (Word, Excel тощо) та оберіть ваш основний збережений документ (без знаків «~$» на початку)."
                )

            # 2. Порожні офісні файли та бази даних (0 байтів)
            if getattr(f, 'size', 0) == 0 and ext in office_exts:
                if ext in ('.accdb', '.mdb', '.accde', '.mde'):
                    raise forms.ValidationError(
                        f"Файл «{base_name}» порожній (0 байтів). "
                        "Якщо ви зараз створюєте базу даних у Microsoft Access, зміни ще не збережено на диск. "
                        "Будь ласка, збережіть файл бази даних, закрийте Microsoft Access та прикріпіть його (.accdb або .mdb) повторно."
                    )
                else:
                    raise forms.ValidationError(
                        f"Файл «{base_name}» порожній (0 байтів). "
                        "Якщо ви зараз працюєте над ним у Word або Excel, зміни ще не збережено на диск. "
                        "Будь ласка, збережіть документ («Файл» → «Зберегти»), закрийте програму та прикріпіть його повторно."
                    )

            # 3. Перевірка на ексклюзивне блокування читання
            try:
                if hasattr(f, 'seek'):
                    f.seek(0)
                f.read(512)
                if hasattr(f, 'seek'):
                    f.seek(0)
            except (PermissionError, OSError, IOError):
                raise forms.ValidationError(
                    f"Не вдалося прочитати вміст файлу «{base_name}» (файл заблокований або відкритий в іншій програмі). "
                    "Будь ласка, збережіть та закрийте програму (Word, Excel, Access тощо), де відкрито цей файл, і спробуйте знову."
                )

        cleaned_data['all_files'] = all_uploaded

        # Обробка списку співавторів (до 5 осіб, без дублікатів та автора)
        if hasattr(self.data, 'getlist'):
            raw_coauthors = self.data.getlist('coauthors') or self.data.getlist('coauthors[]')
        else:
            raw_coauthors = self.data.get('coauthors', [])
            if isinstance(raw_coauthors, str):
                raw_coauthors = [raw_coauthors]
        if getattr(self, 'public_personal_access', False):
            raw_coauthors = []
        cleaned_coauthors = []
        full_name_input = (cleaned_data.get('full_name') or '').strip().lower()
        seen_co = set()
        if full_name_input:
            seen_co.add(full_name_input)

        for co in raw_coauthors:
            c_str = (co or '').strip()
            if not c_str:
                continue
            c_lower = c_str.lower()
            if c_lower in seen_co:
                continue
            seen_co.add(c_lower)
            cleaned_coauthors.append(c_str)
            if len(cleaned_coauthors) >= 5:
                break

        selected_names = {row.get_full_name().casefold() for row in cleaned_data.get('selected_coauthors', [])}
        if cleaned_data.get('shared_roster') and any(name.casefold() not in selected_names for name in cleaned_coauthors):
            self.add_error('full_name', 'Оберіть кожного співавтора зі списку.')
        cleaned_data['coauthors'] = cleaned_coauthors

        comment_st = cleaned_data.get('comment_student')
        if not all_uploaded and not link and not (comment_st and comment_st.strip()):
            raise forms.ValidationError(
                'Будь ласка, завантажте файл(и) роботи, вкажіть посилання або надайте відповідь у полі коментаря.'
            )
        return cleaned_data

    def save(self, assignment):
        """Roll back both DB state and newly stored files if saving fails."""
        from django.db import transaction
        self._saved_uploads = []
        try:
            with transaction.atomic():
                # Keep lock order consistent with incoming roster updates.
                from school_sync.django_backend import operate
                operate(lambda engine, store: None)
                # Serialize attempt numbering and canonical student creation per class.
                ClassGroup.objects.select_for_update().get(pk=self.cleaned_data['class_group'].pk)
                return self._save_submission(assignment)
        except Exception:
            for storage, name in self._saved_uploads:
                try:
                    storage.delete(name)
                except OSError:
                    import logging
                    logging.getLogger(__name__).exception('Could not clean up failed upload %s', name)
            raise

    def _save_submission(self, assignment):
        """Зберігає здачу роботи з кількома файлами, підтримкою колективної роботи (співавторів) та прив'язкою до учня."""
        from .models import Submission, SubmissionFile, Student
        from .student_matcher import resolve_canonical_student_name, is_same_student_identity
        from .utils import optimize_uploaded_file

        class_grp = self.cleaned_data['class_group']
        # The journal may have connected between form validation and this lock.
        self.cleaned_data['shared_roster'] = has_stable_class_roster(class_grp)
        student_obj = self.cleaned_data.get('selected_student')
        if student_obj:
            # Recheck the selected ID inside the class-locked transaction.
            student_obj = Student.objects.get(pk=student_obj.pk, class_group=class_grp, integration_active=True)
            last_name, first_name = student_obj.last_name, student_obj.first_name
        elif self.cleaned_data.get('other_student'):
            parts = self.cleaned_data['full_name'].strip().split(maxsplit=1)
            last_name, first_name = parts[0], parts[1] if len(parts) > 1 else ''
        else:
            if self.cleaned_data['shared_roster']:
                raise forms.ValidationError('Список класу оновився. Оберіть своє ім’я або позначте, що вас немає у списку.')
            last_name, first_name = resolve_canonical_student_name(self.cleaned_data['full_name'], class_group=class_grp)
            matches = [p for p in Student.objects.filter(class_group=class_grp, integration_active=True)
                if is_same_student_identity(last_name, first_name, p.last_name, p.first_name)]
            if len(matches) > 1:
                raise forms.ValidationError('Кілька учнів мають однакове ім’я. Оберіть своє ім’я зі списку.')
            student_obj = matches[0] if matches else Student.objects.create(last_name=last_name or "Учень", first_name=first_name, class_group=class_grp)
        all_files = self.cleaned_data.get('all_files') or []
        coauthors_list = self.cleaned_data.get('coauthors') or []

        # Резолвимо дані для кожного співавтора
        resolved_coauthors = []
        all_authors_display = [f"{last_name} {first_name}".strip()]
        for co_raw in ([] if self.cleaned_data.get('shared_roster') or self.cleaned_data.get('selected_coauthors') else coauthors_list):
            co_ln, co_fn = resolve_canonical_student_name(co_raw, class_group=class_grp)
            if not co_ln and not co_fn:
                continue
            if is_same_student_identity(co_ln, co_fn, last_name, first_name):
                continue
            co_st = None
            for s in Student.objects.filter(class_group=class_grp):
                if is_same_student_identity(co_ln, co_fn, s.last_name, s.first_name):
                    co_st = s
                    break
            if not co_st:
                other_class_exists = Student.objects.filter(
                    Q(last_name__iexact=co_ln) & Q(first_name__iexact=co_fn)
                ).exclude(class_group=class_grp).exists()
                if other_class_exists:
                    continue
                co_st = Student.objects.create(
                    last_name=co_ln or "Учень",
                    first_name=co_fn,
                    class_group=class_grp
                )
            co_full = f"{co_ln} {co_fn}".strip()
            resolved_coauthors.append({
                'student': co_st,
                'last_name': co_ln,
                'first_name': co_fn,
                'full_name': co_full
            })
            all_authors_display.append(co_full)

        if self.cleaned_data.get('shared_roster') or self.cleaned_data.get('selected_coauthors'):
            resolved_coauthors = [{'student': row, 'last_name': row.last_name, 'first_name': row.first_name, 'full_name': row.get_full_name()}
                for row in self.cleaned_data.get('selected_coauthors', [])]
            all_authors_display = [f"{last_name} {first_name}".strip()] + [row['full_name'] for row in resolved_coauthors]

        is_group = bool(resolved_coauthors)
        group_authors_str = ", ".join(all_authors_display) if is_group else ""

        # Визначаємо, чи учень здає роботу повторно (перездача / робота над помилками)
        q_prev = Q(assignment=assignment, class_group=class_grp)
        if student_obj:
            q_prev &= Q(student=student_obj) if self.cleaned_data.get('shared_roster') else (Q(student=student_obj) | (Q(student__isnull=True) & Q(last_name__iexact=last_name) & Q(first_name__iexact=first_name)))
        elif self.cleaned_data.get('other_student'):
            from uuid import uuid4
            self.outside_student_id = getattr(self, 'outside_student_id', None) or uuid4()
            q_prev &= Q(student__isnull=True, outside_student_id=self.outside_student_id)
        else:
            q_prev &= (Q(last_name__iexact=last_name) & Q(first_name__iexact=first_name))

        prev_submissions = list(Submission.objects.filter(q_prev).order_by('-submitted_at'))
        is_resub = len(prev_submissions) > 0
        attempt_num = len(prev_submissions) + 1
        latest_prev = prev_submissions[0] if prev_submissions else None

        submission = Submission(
            outside_student_id=getattr(self, 'outside_student_id', None) if not student_obj else None,
            assignment=assignment,
            student=student_obj,
            last_name=last_name,
            first_name=first_name,
            class_group=class_grp,
            file=None,  # Прив'язуємо нижче без дублювання файлу на диску
            link=self.cleaned_data.get('link') or None,
            comment_student=self.cleaned_data.get('comment_student') or None,
            is_group_work=is_group,
            group_authors=group_authors_str,
            is_resubmission=is_resub,
            resubmission_attempt=attempt_num,
            previous_submission=latest_prev,
            is_latest_attempt=True,
        )
        submission.save()

        # Оновлюємо попередні спроби учня: вони позначаються як не останні
        if prev_submissions:
            Submission.objects.filter(id__in=[p.id for p in prev_submissions]).update(is_latest_attempt=False)

        # Зберігаємо всі завантажені файли як окремі SubmissionFile об'єкти (рівно по 1 разу)
        saved_sub_files = []
        for f in all_files:
            try:
                if hasattr(f, 'seek'):
                    f.seek(0)
            except Exception:
                pass
            orig_name = getattr(f, 'name', '') or 'file'
            opt_f = optimize_uploaded_file(f)
            try:
                if hasattr(opt_f, 'seek'):
                    opt_f.seek(0)
            except Exception:
                pass
            sub_file = SubmissionFile(submission=submission, original_name=orig_name)
            sub_file.file.save(orig_name, opt_f, save=False)
            self._saved_uploads.append((sub_file.file.storage, sub_file.file.name))
            sub_file.save()
            saved_sub_files.append(sub_file)

        # Встановлюємо шлях до першого файлу для зворотної сумісності без збереження копії на диску
        if saved_sub_files and saved_sub_files[0].file:
            submission.file.name = saved_sub_files[0].file.name
            submission.save(update_fields=['file'])

        # Створюємо зв'язані роботи для кожного співавтора (колективна робота)
        if is_group:
            for co in resolved_coauthors:
                co_st = co['student']
                co_ln = co['last_name']
                co_fn = co['first_name']

                # Перевіряємо чи є попередня спроба у цього співавтора
                q_co_prev = Q(assignment=assignment, class_group=class_grp)
                if co_st:
                    q_co_prev &= Q(student=co_st) if self.cleaned_data.get('shared_roster') else (Q(student=co_st) | (Q(student__isnull=True) & Q(last_name__iexact=co_ln) & Q(first_name__iexact=co_fn)))
                else:
                    q_co_prev &= (Q(last_name__iexact=co_ln) & Q(first_name__iexact=co_fn))

                co_prev_subs = list(Submission.objects.filter(q_co_prev).order_by('-submitted_at'))
                co_is_resub = len(co_prev_subs) > 0
                co_attempt_num = len(co_prev_subs) + 1
                co_latest_prev = co_prev_subs[0] if co_prev_subs else None

                co_comment = f"Колективна робота (спільно з {submission.get_student_full_name()})"
                if self.cleaned_data.get('comment_student'):
                    co_comment += f": {self.cleaned_data.get('comment_student')}"

                co_sub = Submission.objects.create(
                    assignment=assignment,
                    student=co_st,
                    last_name=co_ln,
                    first_name=co_fn,
                    class_group=class_grp,
                    teacher=submission.teacher,
                    file=submission.file,
                    link=submission.link,
                    comment_student=co_comment,
                    is_group_work=True,
                    group_authors=group_authors_str,
                    primary_submission=submission,
                    is_resubmission=co_is_resub,
                    resubmission_attempt=co_attempt_num,
                    previous_submission=co_latest_prev,
                    is_latest_attempt=True,
                )
                if co_prev_subs:
                    Submission.objects.filter(id__in=[p.id for p in co_prev_subs]).update(is_latest_attempt=False)

                # Прив'язуємо файли до роботи співавтора
                for sf in saved_sub_files:
                    SubmissionFile.objects.create(
                        submission=co_sub,
                        file=sf.file,
                        original_name=sf.original_name
                    )

        # Автоматичне розпізнавання та прив'язка співавторів з коментаря учня
        from .student_matcher import auto_bind_coauthors_from_comment
        if not self.cleaned_data.get('shared_roster') and not self.cleaned_data.get('selected_coauthors'):
            auto_bind_coauthors_from_comment(submission)

        from .submission_notifications import record_submission_notification
        record_submission_notification(submission)
        return submission


# ─── Форма створення / редагування учня ───────────────────────────────────────
class StudentForm(forms.ModelForm):
    """Форма додавання та редагування профілю учня вчителем."""

    sync_submissions = forms.BooleanField(
        label="Синхронізувати попередні здані роботи учня",
        required=False,
        initial=True,
        help_text="Оновити ім’я у власних роботах; клас призначеного завдання та історію зберегти"
    )

    class Meta:
        model = Student
        fields = ['last_name', 'first_name', 'class_group', 'notes']
        widgets = {
            'last_name': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Наприклад: Шевченко',
                'id': 'id_student_last_name',
                'required': True,
            }),
            'first_name': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Наприклад: Тарас',
                'id': 'id_student_first_name',
                'required': True,
            }),
            'class_group': forms.Select(attrs={
                'class': 'form-input',
                'id': 'id_student_class_group',
            }),
            'notes': forms.Textarea(attrs={
                'class': 'form-input',
                'rows': 2,
                'placeholder': 'Нотатки про учня (необовʼязково)...',
                'id': 'id_student_notes',
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['class_group'].queryset = teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter')


# ─── Форма імпорту списку учнів та класів ────────────────────────────────────
class StudentImportForm(forms.Form):
    """Форма імпорту списку учнів через завантаження файлу або вставку тексту."""

    IMPORT_MODES = [
        ('text', '📝 Вставка тексту зі списком'),
        ('file', '📁 Завантаження файлу (CSV / TXT / TSV)'),
    ]

    import_mode = forms.ChoiceField(
        choices=IMPORT_MODES,
        initial='text',
        widget=forms.RadioSelect(attrs={'class': 'import-mode-radio'})
    )
    raw_text = forms.CharField(
        label="Список учнів",
        required=False,
        widget=forms.Textarea(attrs={
            'class': 'form-input code-font',
            'rows': 8,
            'placeholder': "Вставте список учнів. Приклади:\nІваненко Тарас, 9-А\nПетренко Олена, 9-А\nКоваленко Дмитро, 10-Б\n\nАбо оберіть клас нижче і вставте лише імена:\nШевченко Тарас\nЛеся Українка",
            'id': 'id_import_raw_text'
        })
    )
    file = forms.FileField(
        label="Файл зі списком (.csv, .txt, .tsv)",
        required=False,
        widget=forms.FileInput(attrs={
            'class': 'form-file-input',
            'accept': '.csv,.txt,.tsv',
            'id': 'id_import_file'
        })
    )
    default_class = forms.ModelChoiceField(
        queryset=teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter'),
        label="Клас за замовчуванням (якщо клас не вказано в рядку)",
        required=False,
        empty_label="— Визначити автоматично з рядка —",
        widget=forms.Select(attrs={'class': 'form-input', 'id': 'id_import_default_class'})
    )
    create_missing_classes = forms.BooleanField(
        label="Автоматично створювати класи, якщо їх ще немає в системі",
        initial=True,
        required=False,
        widget=forms.CheckboxInput(attrs={'id': 'id_create_missing_classes'})
    )

