"""Ordered failover and durable, private, observable evaluation progress."""
import json
from unittest.mock import patch

from django.test import TestCase
from django.urls import reverse

from . import tests_ai_connections as fixtures
from .ai_jobs import enqueue_submission_job, execute_job, fail_job
from .ai_progress import emit_event, track_job
from .gemini_service import evaluate_submission_with_gemini, call_ai_api
from .models import AIJob, AIRequestLog


class EvaluationProgressTests(TestCase):
    setUp = fixtures.AIConnectionsTests.setUp
    add_connection = fixtures.AIConnectionsTests.add_connection
    answer = fixtures.AIConnectionsTests.answer

    def job(self, kind='teacher_check'):
        return AIJob.objects.create(kind=kind, submission=self.sub, requested_by=self.user)

    @patch('feed.gemini_service.call_ai_api')
    def test_verbose_level_is_saved_without_wasting_a_second_model_request(self, call):
        self.add_connection('gemini', 'first')
        self.add_connection('groq', 'never-called')
        code, text, error, raw = self.answer()
        answer = json.loads(text)
        level = 'Достатній рівень: учень виконав завдання та пояснив отриманий результат. ' * 5
        level = level.strip()
        answer['level'] = level
        call.return_value = code, json.dumps(answer), error, raw
        result = evaluate_submission_with_gemini(self.sub)
        self.assertEqual(result['status'], 'success')
        self.sub.refresh_from_db()
        self.assertEqual(self.sub.ai_score_level, level)
        self.sub.student_ai_level = level
        self.sub._meta.get_field('student_ai_level').clean(level, self.sub)
        self.sub.save(update_fields=['student_ai_level'])
        self.sub.refresh_from_db()
        self.assertEqual(self.sub.student_ai_level, level)
        call.assert_called_once()

    @patch('feed.gemini_service.time.sleep')
    @patch('feed.gemini_service.call_ai_api')
    def test_free_router_retries_received_gateway_failure_once_then_succeeds(self,call,sleep):
        self.add_connection('openrouter','openrouter/free')
        self.add_connection('groq','never-called')
        call.side_effect=[(502,'','Provider returned error',{}),self.answer()]
        job=self.job()
        execute_job(job.pk)
        job.refresh_from_db()
        self.assertEqual(job.status,'succeeded')
        self.assertEqual([c.kwargs['model_name'] for c in call.call_args_list],['openrouter/free']*2)
        self.assertEqual(sum(e['kind']=='retry' for e in job.events),1)

    @patch('feed.gemini_service.time.sleep')
    @patch('feed.gemini_service.call_ai_api')
    def test_free_router_legacy_configuration_still_has_only_one_retry(self,call,sleep):
        self.settings.unified_model_queue=False
        self.settings.api_key='synthetic'
        self.settings.save()
        config={'provider':'openrouter','api_key':'synthetic','model':'openrouter/free',
                'custom_url':'','is_backup':False}
        call.return_value=(200,'User Safety: safe',None,{})
        with patch.object(type(self.settings),'get_request_configs',return_value=[config]):
            result=evaluate_submission_with_gemini(self.sub)
        self.assertEqual(result['status'],'failed')
        self.assertEqual(call.call_count,2)

    @patch('feed.gemini_service.time.sleep')
    @patch('feed.gemini_service.call_ai_api')
    def test_free_router_retries_safety_classification_once_without_inventing_grade(self,call,sleep):
        self.add_connection('openrouter','openrouter/free')
        call.side_effect=[(200,'User Safety: safe',None,{}),self.answer()]
        result=evaluate_submission_with_gemini(self.sub)
        self.assertEqual(result['status'],'success')
        self.assertEqual(call.call_count,2)
        self.assertTrue(self.sub.ai_error_logs.filter(error_type='Unexpected Assessment Format').exists())

    @patch('feed.gemini_service.time.sleep')
    @patch('feed.gemini_service.call_ai_api')
    def test_free_router_invalid_json_retry_budget_is_shared_and_then_fails_over(self,call,sleep):
        self.add_connection('openrouter','openrouter/free')
        self.add_connection('groq','second')
        call.side_effect=[(502,'','gateway',{}),(200,'User Safety: safe',None,{}),self.answer()]
        result=evaluate_submission_with_gemini(self.sub)
        self.assertEqual(result['status'],'success')
        self.assertEqual(call.call_count,3)
        self.assertEqual([c.kwargs['model_name'] for c in call.call_args_list],['openrouter/free','openrouter/free','second'])

    @patch('feed.gemini_service.call_ai_api')
    def test_truncated_json_cannot_create_grade_from_recovered_fields(self,call):
        self.add_connection('groq','single')
        call.return_value=(200,'{"suggested_grade":12,"summary":"unfinished',None,{})
        result=evaluate_submission_with_gemini(self.sub)
        self.assertEqual(result['status'],'failed')
        self.sub.refresh_from_db()
        self.assertFalse(self.sub.ai_suggested_grade)

    @patch('feed.gemini_service.time.sleep')
    @patch('feed.gemini_service.call_ai_api')
    def test_free_router_retries_empty_cold_start_once_then_succeeds(self,call,sleep):
        self.add_connection('openrouter','openrouter/free')
        call.side_effect=[(200,'','Порожня відповідь від моделі',{}),self.answer()]
        job=self.job()
        execute_job(job.pk)
        job.refresh_from_db()
        self.assertEqual(job.status,'succeeded')
        self.assertEqual(call.call_count,2)
        self.assertEqual(sum(e['kind']=='retry' for e in job.events),1)
        self.assertEqual(call.call_args.kwargs['thinking_budget'],0)
        self.assertEqual(call.call_args.kwargs['timeout'],90)
        self.assertLess(len(call.call_args.kwargs['system_prompt']),4000)

    @patch('feed.gemini_service.time.sleep')
    @patch('feed.gemini_service.call_ai_api')
    def test_free_router_timeout_and_rate_limit_are_not_retried(self,call,sleep):
        self.add_connection('openrouter','openrouter/free')
        self.add_connection('groq','second')
        from .ai_concurrency import clear_model_cooldown
        for code in [0,429,200]:
            clear_model_cooldown('openrouter', 'openrouter/free')
            call.reset_mock()
            call.side_effect=[(code,'','MAX_TOKENS: reasoning exhausted' if code == 200 else 'synthetic failure',{}),self.answer()]
            result=evaluate_submission_with_gemini(self.sub)
            self.assertEqual(result['status'],'success')
            self.assertEqual(call.call_count,2)
            self.assertEqual(call.call_args_list[-1].kwargs['model_name'],'second')
        sleep.assert_not_called()

    @patch('feed.gemini_service.call_ai_api')
    def test_exact_six_model_sequence_waits_for_temporary_quota_after_one_pass(self, call):
        models = ['gemini-3.1-flash-lite', 'gemini-3.6-flash', 'gemini-3.8-flash',
                  'gemini-3.7-flash', 'gemini-flash-latest', 'openai/gpt-oss-120b']
        for index, name in enumerate(models):
            self.add_connection('gemini' if index < 5 else 'groq', name)
        call.side_effect = [(code, '', 'synthetic failure', {}) for code in [503, 429, 429, 429, 429, 413]]
        job = self.job()
        execute_job(job.pk)
        job.refresh_from_db()
        self.assertEqual([c.kwargs['model_name'] for c in call.call_args_list], models)
        self.assertEqual(job.status, 'queued')
        self.assertEqual([e['model'] for e in job.events if e['kind'] == 'model_start'], models)
        self.assertEqual([e['status_code'] for e in job.events if e['kind'] == 'model_error'], [503,429,429,429,429,413])
        self.assertEqual(sum(e['kind'] == 'switching' for e in job.events), 5)
        self.assertEqual(job.events[-2]['kind'], 'exhausted')
        self.assertEqual(job.events[-1]['kind'], 'waiting_quota')
        self.assertTrue(any('розміру, а не квоти' in event['message'] for event in job.events))
        result = self.client.get(reverse('ai_job_status', args=[job.pk])).json()
        self.assertEqual(result['events'], job.events)
        self.assertEqual([e['sequence'] for e in job.events], list(range(1, len(job.events)+1)))
        self.assertNotIn('synthetic-key', json.dumps(result))
        page = self.client.get(reverse('view_file', args=[self.sub.pk]))
        self.assertContains(page, 'data-ai-job-status=')
        self.assertContains(page, 'Робота в черзі на перевірку ШІ')

    @patch('feed.gemini_service.call_ai_api')
    def test_progress_is_readable_while_request_is_running_and_success_stops_queue(self, call):
        self.add_connection('gemini', 'first')
        self.add_connection('groq', 'second')
        self.add_connection('openrouter', 'never-called')
        job = self.job()
        snapshots = []
        def respond(**kwargs):
            response = self.client.get(reverse('ai_job_status', args=[job.pk]))
            self.assertEqual(response.status_code, 202)
            snapshots.append(response.json()['events'])
            return (503, '', 'Overloaded', {}) if len(snapshots) == 1 else self.answer()
        call.side_effect = respond
        execute_job(job.pk)
        job.refresh_from_db()
        self.assertEqual(call.call_count, 2)
        self.assertEqual(snapshots[0][-1]['model'], 'first')
        self.assertEqual(snapshots[1][-1]['model'], 'second')
        self.assertTrue(any(e['kind'] == 'switching' for e in snapshots[1]))
        self.assertEqual([e['kind'] for e in job.events[-2:]], ['model_success', 'completed'])

    @patch('feed.gemini_service.call_ai_api')
    def test_every_unusable_answer_advances_to_next_model(self, call):
        self.add_connection('gemini', 'first')
        self.add_connection('groq', 'second')
        failures = [(200, '   ', '', {}), (200, '', '', {}), (200, 'broken JSON', '', {}),
                    (200, json.dumps({'suggested_grade': None}), '', {}),
                    (200, json.dumps({'suggested_grade': 12, 'assessment_blocked': True}), '', {}),
                    (200, json.dumps({'suggested_grade': 'NaN'}), '', {}),
                    (200, '[]', '', {}), (403, '', 'Forbidden', {}), RuntimeError('connection interrupted')]
        for failure in failures:
            with self.subTest(failure=failure):
                call.reset_mock()
                call.side_effect = [failure, self.answer()]
                job = self.job()
                execute_job(job.pk)
                job.refresh_from_db()
                self.assertEqual(job.status, 'succeeded')
                self.assertEqual(call.call_count, 2)
                self.assertEqual(sum(e['kind'] == 'model_error' for e in job.events), 1)
                self.assertEqual(sum(e['kind'] == 'switching' for e in job.events), 1)

    @patch('feed.gemini_service.call_ai_api')
    def test_disabled_auto_failover_makes_no_false_switching_event(self, call):
        self.add_connection('gemini', 'first')
        self.add_connection('groq', 'second')
        self.settings.auto_failover_enabled = False
        self.settings.save()
        call.return_value = (429, '', 'Limit', {})
        job = self.job()
        execute_job(job.pk)
        job.refresh_from_db()
        self.assertEqual(call.call_count, 1)
        self.assertFalse(any(e['kind'] == 'switching' for e in job.events))

    @patch('feed.gemini_service.call_ai_api')
    def test_secrets_from_any_connection_are_removed_from_events_and_errors(self, call):
        self.add_connection('gemini', 'first', key='secret-one')
        self.add_connection('groq', 'second', key='secret-two')
        call.side_effect = [(403, '', 'key=secret-one; secret-two', {}), self.answer()]
        job = self.job()
        execute_job(job.pk)
        job.refresh_from_db()
        data = json.dumps(job.events) + json.dumps(job.result)
        self.assertNotIn('secret-one', data)
        self.assertNotIn('secret-two', data)
        self.assertIn('приховано', str(job.events))

    def test_progress_is_bounded_and_context_does_not_leak_to_next_job(self):
        job = self.job()
        with track_job(job.pk):
            for index in range(210):
                emit_event('preparing', str(index))
        emit_event('preparing', 'outside worker')
        job.refresh_from_db()
        self.assertEqual(len(job.events), 200)
        self.assertEqual(job.events[-1]['sequence'], 210)
        self.assertEqual(job.events[-1]['message'], '209')
        fail_job(job.pk, 'Перевірку перервано.')
        job.refresh_from_db()
        self.assertEqual(job.events[-1]['kind'], 'failed')
        emit_event('preparing', 'must not reopen job', job_id=job.pk)
        job.refresh_from_db()
        self.assertEqual(job.events[-1]['kind'], 'failed')

    def test_teacher_progress_cannot_be_read_by_anonymous_student(self):
        job = self.job()
        emit_event('model_start', 'private teacher event', job_id=job.pk)
        self.client.logout()
        response = self.client.get(reverse('ai_job_status', args=[job.pk]))
        self.assertEqual(response.status_code, 403)
        page = self.client.get(reverse('submission_detail', args=[self.sub.pk]))
        self.assertNotContains(page, 'private teacher event')

    @patch('feed.gemini_service.call_ai_api')
    def test_student_failed_job_has_events_and_does_not_consume_attempt(self, call):
        self.assignment.allow_student_ai_check = True
        self.assignment.save()
        self.add_connection('gemini', 'first')
        call.return_value = (503, '', 'High demand', {})
        job = enqueue_submission_job(self.sub, 'student_check')
        execute_job(job.pk)
        job.refresh_from_db()
        self.assertEqual(job.status, 'failed')
        self.assertFalse(job.reservations.filter(used=True).exists())
        self.assertTrue(any(e['kind'] == 'model_error' for e in job.events))
        self.client.logout()
        response = self.client.get(reverse('ai_job_status', args=[job.pk]))
        self.assertEqual(response.json()['events'], job.events)

    @patch('feed.gemini_service._http_post_json')
    def test_visual_gpt_oss_rejects_instead_of_dropping_evidence(self, post):
        media = [{'mime_type': 'application/pdf', 'data': 'synthetic', 'source': 'Карта знань'}]
        response = call_ai_api('Text', inline_media=media, provider='groq', model_name='openai/gpt-oss-120b', api_key='synthetic')
        self.assertEqual(response[0], 415)
        post.assert_not_called()
        self.assertEqual(len(media), 1)
        self.assertEqual(media[0]['source'], 'Карта знань')

    @patch('feed.gemini_service._http_post_json')
    def test_text_only_gpt_oss_still_calls_groq(self, post):
        post.return_value = (200, {'choices': [{'message': {'content': 'text reply'}}]}, '')
        response = call_ai_api('Text', provider='groq', model_name='openai/gpt-oss-120b', api_key='synthetic')
        self.assertEqual(response[:2], (200, 'text reply'))
        self.assertEqual(post.call_count, 1)
        self.assertEqual(AIRequestLog.objects.count(), 1)

    @patch('feed.gemini_service._http_post_json')
    @patch('feed.ai_payload.optimize_media', side_effect=lambda items, provider: items)
    def test_known_groq_image_limit_rejects_instead_of_capping(self, optimize, post):
        from .tests_ai_payload import picture
        media = [picture(color) for color in ('red', 'blue', 'green', 'black')]
        response = call_ai_api('Text', inline_media=media, provider='groq', model_name='qwen/qwen3.8-27b', api_key='synthetic')
        self.assertEqual(response[0], 413)
        post.assert_not_called()
        self.assertEqual(len(media), 4)

    @patch('feed.gemini_service._http_post_json')
    @patch('feed.ai_payload.optimize_media', side_effect=lambda items, provider: items)
    def test_text_only_groq_is_skipped_then_gemini_gets_complete_visual(self, optimize, post):
        self.add_connection('groq', 'openai/gpt-oss-120b')
        self.add_connection('gemini', 'vision-model')
        from .tests_ai_payload import picture
        media = [picture()]
        self.settings.privacy_mode = 'redact'
        self.settings.save(update_fields=['privacy_mode'])
        answer = self.answer()[1]
        # Only the multimodal adapter sends the complete visual evidence.
        post.return_value = (200, {'candidates': [{'content': {'parts': [{'text': answer}]}}]}, '')
        original = call_ai_api
        def inject_media(**kwargs):
            kwargs['inline_media'] = list(media)  # copy so each invocation gets its own list
            return original(**kwargs)
        job = self.job()
        with patch('feed.gemini_service.call_ai_api', side_effect=inject_media):
            execute_job(job.pk)
        job.refresh_from_db()
        self.assertEqual(job.status, 'succeeded')
        self.assertEqual(post.call_count, 1)
        # Last call is to gemini and contains the image
        gemini_payload = post.call_args.args[1]
        image_data = gemini_payload['contents'][0]['parts'][-1]['inlineData']['data']
        import base64, io
        from PIL import Image
        from .ai_payload import image_signature
        self.assertEqual(image_signature(Image.open(io.BytesIO(base64.b64decode(image_data)))),
                         image_signature(Image.open(io.BytesIO(base64.b64decode(media[0]['data'])))))
        # Local preflight rejection is not a provider request.
        self.assertEqual(AIRequestLog.objects.count(), 1)
        self.assertEqual(AIRequestLog.objects.order_by('pk').last().provider, 'gemini')
        self.assertEqual([e['model'] for e in job.events if e['kind'] == 'model_start'], ['openai/gpt-oss-120b', 'vision-model'])

    @patch('feed.gemini_service._get_http_pool')
    @patch('feed.gemini_service.urllib.request.urlopen')
    def test_network_timeout_is_not_resent_via_another_transport(self, urlopen, pool):
        pool.return_value.request.side_effect = TimeoutError('timed out')
        result = call_ai_api('Text', provider='groq', model_name='openai/gpt-oss-120b', api_key='synthetic')
        self.assertEqual(result[0], 0)
        self.assertIn('timed out', result[2])
        self.assertIs(pool.return_value.request.call_args.kwargs['retries'], False)
        urlopen.assert_not_called()
