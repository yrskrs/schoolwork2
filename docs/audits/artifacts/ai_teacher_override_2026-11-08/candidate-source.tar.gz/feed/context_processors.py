"""
Глобальні контекстні процесори для шаблонів SchoolNet.
"""
from django.db.models import Q
from .models import Submission, School, BellSchedule, AssignmentRescheduleLog, Teacher, ClassGroup
from .changelog import SITE_VERSION, SITE_VERSION_SHORT, CHANGELOG_DATA
from .outside_students import teaching_classes

def teacher_stats_context(request):
    """
    Додає у всі шаблони:
    - pending_submissions_count: кількість зданих робіт, що очікують перевірки та оцінки вчителем.
    - current_school: дані поточного навчального закладу.
    - is_superadmin_mode: чи увімкнено активний режим супер-адміністратора для поточного сеансу.
    - all_bell_slots: всі налаштовані дзвінки школи.
    - all_classes: всі класи школи.
    - reschedule_reason_choices: типи причин перенесення занять.
    - site_version, site_version_full, changelog_data: версія та історія змін сайту.
    """
    is_super_mode = False
    if request.user.is_authenticated and request.user.is_superuser:
        is_super_mode = bool(request.session.get('superadmin_mode', False))

    context = {
        'pending_submissions_count': 0,
        'current_school': None,
        'is_superadmin_mode': is_super_mode,
        'all_bell_slots': [],
        'all_classes': [],
        'reschedule_reason_choices': AssignmentRescheduleLog.REASON_CHOICES,
        'teacher_conducted_lessons': None,
        'site_version': SITE_VERSION_SHORT,
        'site_version_full': SITE_VERSION,
        'changelog_data': CHANGELOG_DATA,
    }

    try:
        context['current_school'] = School.objects.first()
        context['all_bell_slots'] = list(BellSchedule.objects.all().order_by('lesson_number'))
        from .access_control import scope_classes
        context['all_classes'] = list(scope_classes(request, teaching_classes(ClassGroup.objects.all())).order_by('grade', 'letter', 'name'))
    except Exception:
        pass

    if request.user.is_authenticated:
        try:
            teacher = getattr(request.user, 'teacher_profile', None)
            if not teacher and (request.user.is_superuser or is_super_mode):
                teacher = Teacher.objects.first()

            if teacher:
                if is_super_mode:
                    count = Submission.objects.filter(is_latest_attempt=True).filter(Q(grade__isnull=True) | Q(grade='')).count()
                else:
                    count = Submission.objects.filter(
                        assignment__teacher=teacher,
                        is_latest_attempt=True
                    ).filter(
                        Q(grade__isnull=True) | Q(grade='')
                    ).count()
                context['pending_submissions_count'] = count

                # Інформер поточного уроку вчителя
                from .utils import get_teacher_live_lesson_status, get_teacher_upcoming_notifications
                context['live_lesson_status'] = get_teacher_live_lesson_status(teacher)

                # Центр сповіщень
                notifs = get_teacher_upcoming_notifications(teacher)
                context['upcoming_notifications'] = notifs
                context['unread_notifications_count'] = len([n for n in notifs if n.get('type') == 'missing_task'])

                # Лічильник проведених уроків вчителя
                context['teacher_conducted_lessons'] = teacher.get_conducted_lessons_info()
        except Exception:
            pass

    # Lightweight status survives navigation; student jobs remain public.
    from .models import AIJob
    match = getattr(request, 'resolver_match', None)
    job_filter = None
    if match and match.url_name in ('submission_detail', 'view_file'):
        job_filter = {'submission_id': match.kwargs.get('submission_id')}
    elif match and match.url_name == 'submit_success':
        submission_id = request.session.get('last_submission_id')
        if submission_id:
            job_filter = {'submission_id': submission_id, 'submission__assignment_id': match.kwargs.get('pk')}
    if job_filter:
        jobs = AIJob.objects.filter(**job_filter)
        if not request.user.is_authenticated:
            jobs = jobs.filter(kind='student_check')
        else:
            from .permissions import teacher_submissions
            jobs = jobs.filter(Q(kind='student_check') | Q(submission__in=teacher_submissions(request, Submission.objects.all())))
        context['active_ai_job'] = jobs.filter(status__in=['queued', 'running']).first()
        if not context['active_ai_job']:
            context['last_ai_event_job'] = jobs.filter(status__in=['succeeded', 'failed']).exclude(events=[]).order_by('-created_at').first()
    return context
