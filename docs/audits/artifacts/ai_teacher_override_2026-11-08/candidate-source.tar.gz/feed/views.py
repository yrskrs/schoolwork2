"""
Views (представлення) для SchoolNet.

Публічна частина:
    - index          — стрічка завдань з фільтрацією по класу
    - assignment_detail — детальна сторінка/AJAX для модального вікна

Панель вчителя (захищена сесією):
    - teacher_login      — форма входу
    - teacher_logout     — вихід
    - teacher_dashboard  — головна панель (список завдань)
    - assignment_create  — створення нового завдання
    - assignment_edit    — редагування завдання
    - assignment_delete  — видалення завдання
    - assignment_duplicate — дублювання завдання
    - assignment_archive — архівування завдання
    - teacher_profile    — редагування профілю
    - publish_scheduled  — AJAX: перевірка та публікація відкладених
"""

import os
from pathlib import Path
import re
import csv
import json
import zipfile
import io
import mimetypes
import threading
import tempfile
import glob
import shutil
import subprocess
import logging
from .assignment_ai_policy import export_ai_policy, import_ai_policy
from .outside_students import teaching_classes
from functools import wraps
from datetime import datetime, timedelta

# Concurrency control for background preview generation (LibreOffice & pdftoppm)
_PREVIEW_LOCK = threading.Lock()
_ACTIVE_PREVIEWS = set()
_ACTIVE_PREVIEWS_LOCK = threading.Lock()
_PREVIEW_EVENTS = {}  # file_id -> threading.Event
_PREVIEW_EVENTS_LOCK = threading.Lock()
_PREVIEW_SEMAPHORE = threading.Semaphore(2)  # Limit concurrent LibreOffice conversions to protect server CPU


from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import JsonResponse, HttpResponse, HttpResponseForbidden, FileResponse, Http404
from django.utils import timezone
from django.db.models import Q, Sum, Count
from django.db import transaction
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views.decorators.http import require_POST
from django.views.decorators.clickjacking import xframe_options_exempt, xframe_options_sameorigin
from django.views.decorators.csrf import csrf_exempt


from .models import (
    Assignment, AssignmentFile, AssignmentLink, AssignmentYouTubeLink,
    Teacher, ClassGroup, Student, Subject,
    Submission, SubmissionFile, SubmissionComment, SubmissionActivityLog, School, log_submission_activity,
    AISettings, AI_PROVIDER_CHOICES, DEFAULT_NUS_SYSTEM_PROMPT, DEFAULT_NUS_GR_SYSTEM_PROMPT, AICriteriaPreset, DEFAULT_TRADITIONAL_SYSTEM_PROMPT,
    BellSchedule, TeacherLessonSchedule, AssignmentScheduleTarget, SystemNotification,
    AssignmentRescheduleLog, AIErrorLog
)

from .forms import (
    AssignmentForm, TeacherLoginForm, ClassSelectForm,
    TeacherProfileForm, SubjectForm, ClassGroupForm,
    TeacherCreateForm, PasswordResetForm, SubmissionForm,
    StudentForm, StudentImportForm, FirstRunSetupForm
)
from .search import search_assignments
from .fuzzy_search import fuzzy_search_submissions
from .utils import (
    convert_docx_to_html, convert_xlsx_to_html, convert_pptx_to_html,
    convert_odt_to_html, convert_ods_to_html, convert_odp_to_html,
    get_archive_content, get_file_type_info, parse_embed_url
)
from .duplicate_detector import check_submission_duplicates
from .access_utils import convert_access_to_html
from .permissions import teacher_submissions, can_manage_submission, require_assignment_access
from .grading import validate_grade, member_grades
from .settings_navigation import AI_SETTINGS_SECTIONS, ai_settings_section, ai_settings_url
from .file_serving import file_response
from .pagination import AssignmentChain
from .environment_storage import get_storage_snapshot

logger = logging.getLogger(__name__)



# ═══════════════════════════════════════════════════════════════════════════════
# ДОПОМІЖНІ ФУНКЦІЇ
# ═══════════════════════════════════════════════════════════════════════════════

from .access_control import (scope_assignments, scope_classes, scope_students, scope_submissions,
    bind_submission_form, link_for, scope_duplicate_info)


def get_teacher_or_none(request):
    """Повертає профіль вчителя або None якщо не авторизовано."""
    if request.user.is_authenticated:
        try:
            return request.user.teacher_profile
        except Teacher.DoesNotExist:
            pass
    return None


def teacher_required(view_func):
    """Декоратор: перевіряє чи є активна сесія вчителя."""
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        teacher = get_teacher_or_none(request)
        if not teacher:
            messages.warning(request, 'Необхідно увійти як вчитель.')
            return redirect('teacher_login')
        return view_func(request, *args, **kwargs)
    wrapper.__name__ = view_func.__name__
    return wrapper


def auto_archive_expired_assignments():
    """
    Автоматично архівує всі опубліковані завдання, яким понад 14 днів з моменту публікації або розархівації.
    """
    from datetime import timedelta
    cutoff = timezone.now() - timedelta(days=14)
    # Завдання без розархівації — рахуємо від первинної дати публікації / створення
    q_normal = Q(unarchived_at__isnull=True) & (
        Q(published_at__lte=cutoff) | (Q(published_at__isnull=True) & Q(created_at__lte=cutoff))
    )
    # Завдання з розархівацією — рахуємо 14 днів від дати розархівації
    q_unarchived = Q(unarchived_at__isnull=False) & Q(unarchived_at__lte=cutoff)

    expired_count = Assignment.objects.filter(
        status=Assignment.STATUS_PUBLISHED
    ).filter(
        q_normal | q_unarchived
    ).update(
        status=Assignment.STATUS_ARCHIVED
    )
    return expired_count


def _async_trigger_ai_task_understanding(assignment_id, force_refresh=False):
    """Persist automatic analysis so a server restart does not lose it."""
    from .ai_jobs import enqueue_understanding_job
    from django.conf import settings
    # Test requests must not invoke a real provider implicitly.
    if settings.AI_JOBS_EAGER:
        return
    assignment = Assignment.objects.filter(pk=assignment_id, status=Assignment.STATUS_PUBLISHED,
                                            allow_student_ai_understanding=True).first()
    if assignment:
        enqueue_understanding_job(assignment, force_refresh=force_refresh, eager=False)


def get_visible_assignments(class_group_id=None, request=None):
    """
    Повертає QuerySet опублікованих завдань.
    - Автоматично архівує завдання старше 14 днів.
    - Автоматично публікує відкладені, якщо час настав.
    """
    # Автоматична архівація завдань, старших за 14 днів
    auto_archive_expired_assignments()

    # Оновлюємо відкладені публікації
    scheduled_to_publish = list(Assignment.objects.filter(
        status=Assignment.STATUS_SCHEDULED,
        scheduled_at__lte=timezone.now()
    ).values_list('id', 'allow_student_ai_understanding'))

    if scheduled_to_publish:
        Assignment.objects.filter(
            id__in=[item[0] for item in scheduled_to_publish]
        ).update(
            status=Assignment.STATUS_PUBLISHED,
            published_at=timezone.now()
        )
        for asg_id, allow_ai in scheduled_to_publish:
            if allow_ai:
                _async_trigger_ai_task_understanding(asg_id)

    qs = Assignment.objects.filter(
        status=Assignment.STATUS_PUBLISHED
    ).select_related(
        'teacher', 'subject'
    ).prefetch_related(
        'classes', 'files', 'schedule_targets__class_group',
        'schedule_targets__bell_slot', 'teacher__lesson_schedules__bell_slot'
    )

    if class_group_id:
        qs = qs.filter(classes__id=class_group_id)

    if request is not None:
        qs = scope_assignments(request, qs)

    # ── Сортування за актуальністю ──────────────────────────────────────────────
    # Спочатку завдання з target_date >= сьогодні (найближчий урок — першим),
    # потім решта у зворотньо-хронологічному порядку за датою публікації.
    from django.db.models import Min, Value, DateField
    from django.db.models.functions import Coalesce
    import datetime
    today = timezone.localtime(timezone.now()).date()

    qs = qs.annotate(
        earliest_future_target=Min(
            'schedule_targets__target_date',
        )
    )

    # Розділяємо на актуальні та неактуальні, потім з'єднуємо
    # Актуальні: є target_date і вона >= сьогодні
    upcoming_qs = qs.filter(earliest_future_target__gte=today).order_by('earliest_future_target', 'pk')
    rest_qs = qs.filter(Q(earliest_future_target__lt=today) | Q(earliest_future_target__isnull=True)).order_by('-published_at', '-pk')

    # Повертаємо queryset через union для збереження структури
    from itertools import chain
    # Зберігаємо як list для подальшої пагінації
    # (union() не підтримує prefetch_related, тому повертаємо два qs)
    return (upcoming_qs, rest_qs)


# ═══════════════════════════════════════════════════════════════════════════════
# ПУБЛІЧНА ЧАСТИНА — СТРІЧКА НОВИН
# ═══════════════════════════════════════════════════════════════════════════════

def get_calendar_context(year=None, month=None, selected_date_str=None, class_group_id=None, subject_id=None, request=None):
    """
    Формує матрицю днів та кількість завдань для віджета Google Calendar.
    """
    import calendar
    from datetime import timedelta, datetime
    from django.utils import timezone
    from collections import Counter

    today = timezone.localtime(timezone.now()).date()

    if not year or not month:
        if selected_date_str:
            try:
                d = datetime.strptime(selected_date_str, '%Y-%m-%d').date()
                year, month = d.year, d.month
            except Exception:
                year, month = today.year, today.month
        else:
            year, month = today.year, today.month
    else:
        try:
            year = int(year)
            month = int(month)
        except Exception:
            year, month = today.year, today.month

    # Назви місяців українською
    uk_months = [
        '', 'Січень', 'Лютий', 'Березень', 'Квітень', 'Травень', 'Червень',
        'Липень', 'Серпень', 'Вересень', 'Жовтень', 'Листопад', 'Грудень'
    ]

    # Навігація по місяцях
    if month <= 1:
        prev_month, prev_year = 12, year - 1
    else:
        prev_month, prev_year = month - 1, year

    if month >= 12:
        next_month, next_year = 1, year + 1
    else:
        next_month, next_year = month + 1, year

    # Отримуємо всі опубліковані завдання для підрахунку на календарі за датою УРОКУ
    upcoming_qs, rest_qs = get_visible_assignments(class_group_id, request=request)
    # Для календаря порядок неважливий — об'єднуємо
    from itertools import chain as _chain
    visible_all = list(_chain(
        upcoming_qs.prefetch_related('schedule_targets__class_group', 'classes'),
        rest_qs.prefetch_related('schedule_targets__class_group', 'classes')
    ))
    if subject_id:
        visible_all = [a for a in visible_all if a.subject_id == int(subject_id)]

    task_counts = Counter()
    for a in visible_all:
        for td in a.get_target_dates(for_class=class_group_id):
            task_counts[td.isoformat()] += 1

    cal = calendar.Calendar(firstweekday=0)  # Понеділок (0)
    month_weeks = cal.monthdatescalendar(year, month)

    fourteen_days_ago = today - timedelta(days=14)

    weeks_data = []
    for week in month_weeks:
        week_days = []
        for d in week:
            d_str = d.isoformat()
            c = task_counts.get(d_str, 0)
            week_days.append({
                'date': d,
                'day_num': d.day,
                'date_str': d_str,
                'is_current_month': (d.month == month),
                'is_today': (d == today),
                'is_selected': (d_str == selected_date_str),
                'is_in_14_days': (fourteen_days_ago <= d <= today),
                'tasks_count': c,
                'has_tasks': c > 0,
            })
        weeks_data.append(week_days)

    selected_date_display = ""
    if selected_date_str:
        try:
            dt = datetime.strptime(selected_date_str, '%Y-%m-%d').date()
            uk_weekdays = ['Понеділок', 'Вівторок', 'Середа', 'Четвер', 'Пʼятниця', 'Субота', 'Неділя']
            w_name = uk_weekdays[dt.weekday()]
            selected_date_display = f"{w_name}, {dt.strftime('%d.%m.%Y')}"
        except Exception:
            pass

    return {
        'year': year,
        'month': month,
        'month_name': uk_months[month],
        'prev_year': prev_year,
        'prev_month': prev_month,
        'next_year': next_year,
        'next_month': next_month,
        'weeks': weeks_data,
        'selected_date': selected_date_str,
        'selected_date_display': selected_date_display,
        'today_str': today.isoformat(),
    }


def _parse_filter_params(request):
    """Допоміжна функція: парсить та очищує параметри фільтрації класу, предмета, дати та пошуку."""
    class_group_id = None
    if 'class' in request.GET:
        c_val = str(request.GET.get('class', '')).strip()
        if c_val in ('', 'all', '0', 'none', 'None'):
            class_group_id = None
            if 'selected_class' in request.session:
                del request.session['selected_class']
        else:
            try:
                class_group_id = int(c_val)
                request.session['selected_class'] = class_group_id
            except (ValueError, TypeError):
                class_group_id = None
                if 'selected_class' in request.session:
                    del request.session['selected_class']
    elif 'clear' in request.GET:
        class_group_id = None
        if 'selected_class' in request.session:
            del request.session['selected_class']
    else:
        class_group_id = request.session.get('selected_class')

    subject_id = None
    if 'subject' in request.GET:
        s_val = str(request.GET.get('subject', '')).strip()
        if s_val not in ('', 'all', '0', 'none', 'None'):
            try:
                subject_id = int(s_val)
            except (ValueError, TypeError):
                subject_id = None

    date_str = None
    if 'date' in request.GET:
        d_val = str(request.GET.get('date', '')).strip()
        if d_val not in ('', 'all', '0', 'none', 'None'):
            try:
                from datetime import datetime
                datetime.strptime(d_val, '%Y-%m-%d')
                date_str = d_val
            except (ValueError, TypeError):
                date_str = None

    link = link_for(request)
    if link and link.restricted_class_id:
        class_group_id = link.restricted_class_id
    query = request.GET.get('q', '').strip()
    return class_group_id, subject_id, date_str, query


def _filter_assignments_by_lesson_date(assignments, dt_val, class_group_id=None):
    """
    Фільтрує завдання за датою УРОКУ (на яку призначено завдання), гармонізовано з календарем.
    Гарантує 100% відповідність між бейджами календаря та результатами видачі завдань:
    якщо в календарі день показує наявність завдання, при переході на цей день завдання завжди відображається.
    """
    from datetime import datetime, date as _date
    if isinstance(dt_val, str):
        try:
            dt_val = datetime.strptime(dt_val, '%Y-%m-%d').date()
        except Exception:
            return assignments.none()
    elif hasattr(dt_val, 'date') and not isinstance(dt_val, _date):
        dt_val = dt_val.date()

    matching_ids = []
    for a in assignments.prefetch_related('schedule_targets', 'classes'):
        if dt_val in a.get_target_dates(for_class=class_group_id):
            matching_ids.append(a.id)
    return assignments.filter(id__in=matching_ids)


def index(request):
    """
    Головна сторінка — стрічка завдань.
    Підтримує фільтрацію по класу, предмету, даті (календар) та нечіткий пошук.
    """
    class_group_id, subject_id, date_str, query = _parse_filter_params(request)

    upcoming_qs, rest_qs = get_visible_assignments(class_group_id, request=request)

    if subject_id:
        upcoming_qs = upcoming_qs.filter(subject__id=subject_id)
        rest_qs = rest_qs.filter(subject__id=subject_id)

    if date_str:
        from datetime import datetime
        dt_val = datetime.strptime(date_str, '%Y-%m-%d').date()
        upcoming_qs = _filter_assignments_by_lesson_date(upcoming_qs, dt_val, class_group_id)
        rest_qs = _filter_assignments_by_lesson_date(rest_qs, dt_val, class_group_id)

    if query:
        upcoming_qs = search_assignments(upcoming_qs, query)
        rest_qs = search_assignments(rest_qs, query)

    from itertools import chain as _ichain
    assignments = AssignmentChain(upcoming_qs, rest_qs)

    # Пагінація (10 завдань на сторінку)
    paginator = Paginator(assignments, 10)
    page_number = request.GET.get('page', 1)
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    # Дані для UI
    all_classes = scope_classes(request, ClassGroup.objects.filter(teacher__isnull=False).distinct()).order_by('grade', 'letter')
    all_subjects = Subject.objects.filter(teacher__isnull=False).distinct()
    has_multiple_subjects = all_subjects.count() > 1
    selected_class = None
    if class_group_id:
        selected_class = ClassGroup.objects.filter(id=class_group_id).first()

    cal_year = request.GET.get('cal_year')
    cal_month = request.GET.get('cal_month')
    calendar_ctx = get_calendar_context(
        request=request,
        year=cal_year,
        month=cal_month,
        selected_date_str=date_str,
        class_group_id=class_group_id,
        subject_id=subject_id
    )

    if class_group_id:
        for a in page_obj.object_list:
            a._for_class_id = class_group_id

    context = {
        'assignments': page_obj.object_list,
        'page_obj': page_obj,
        'all_classes': all_classes,
        'all_subjects': all_subjects,
        'has_multiple_subjects': has_multiple_subjects,
        'selected_class': selected_class,
        'selected_class_id': class_group_id,
        'selected_subject_id': subject_id,
        'selected_date': date_str,
        'selected_date_display': calendar_ctx.get('selected_date_display', ''),
        'calendar': calendar_ctx,
        'query': query,
        'form': ClassSelectForm(initial={'class_group': class_group_id}),
    }
    return render(request, 'feed/index.html', context)



def assignment_detail(request, pk):
    """
    Детальний перегляд завдання.
    Якщо AJAX — повертає JSON для модального вікна.
    Інакше — повна сторінка.
    Підтримує перегляд заархівованих завдань (> 14 днів) зі спеціальним інфо-банером.
    """
    assignment = Assignment.objects.select_related(
        'teacher', 'subject'
    ).prefetch_related(
        'classes', 'files', 'additional_links', 'youtube_links'
    ).filter(pk=pk).first()

    if not assignment:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'error': 'Завдання вилучено або не існує'}, status=404)
        return render(request, 'feed/assignment_not_found.html', {
            'message': 'Дане завдання було вилучено або переміщено вчителем.'
        }, status=404)

    is_teacher = bool(
        request.user.is_authenticated and
        (hasattr(request.user, 'teacher_profile') or request.user.is_superuser)
    )

    # Якщо чернетка або заплановане у майбутньому — доступ тільки для вчителя/адміністратора
    if assignment.status == Assignment.STATUS_DRAFT and not is_teacher:
        raise Http404("Завдання знаходиться у режимі чернетки")
    if assignment.status == Assignment.STATUS_SCHEDULED and not is_teacher:
        raise Http404("Завдання ще не опубліковане")

    require_assignment_access(request, assignment)
    is_archived = (assignment.status == Assignment.STATUS_ARCHIVED)

    # Фіксація перегляду завдання (1 раз на годину з 1 комп'ютера, перегляди вчителя не рахуються)
    assignment.record_view(request)

    can_edit = bool(
        is_teacher and
        (request.user.is_superuser or (hasattr(request.user, 'teacher_profile') and request.user.teacher_profile == assignment.teacher))
    )

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        # AJAX-відповідь для модального вікна
        files_data = []
        for f in assignment.files.all():
            files_data.append({
                'id': f.id,
                'name': f.original_name,
                'url': f.file.url,
                'download_url': f'/assignment/file/{f.id}/download/',
                'type': f.get_file_type(),
                'icon': f.get_file_icon(),
                'size': f.get_size_display(),
                'viewable': f.is_browser_viewable(),
                'extension': f.get_extension(),
            })

        # Формуємо рядок класів
        classes_str = ', '.join(
            str(c) for c in assignment.classes.all()
        )

        # Додаткові посилання
        extra_links = [
            {'url': lnk.url, 'label': lnk.label or lnk.url}
            for lnk in assignment.additional_links.all()
        ]

        data = {
            'id': assignment.id,
            'title': assignment.title,
            'description': assignment.description,
            'teacher': assignment.teacher.full_name,
            'teacher_avatar_url': assignment.teacher.avatar_image.url if assignment.teacher.avatar_image else '',
            'teacher_avatar_color': assignment.teacher.avatar_color,
            'subject': str(assignment.subject) if assignment.subject else '',
            'subject_color': assignment.subject.color if assignment.subject else '#6366f1',
            'classes': classes_str,
            'is_individual': assignment.is_individual,
            'student_name': assignment.student_name,
            'student_display': assignment.student_display,
            'views_count': assignment.views_count,
            'is_teacher': is_teacher,
            'published_at': timezone.localtime(assignment.published_at).strftime('%d.%m.%Y %H:%M') if assignment.published_at else '',
            'relative_published_at': assignment.relative_published_display,
            'is_today': assignment.is_published_today,
            'is_yesterday': assignment.is_published_yesterday,
            'days_ago': assignment.days_ago,
            'unarchived_at': timezone.localtime(assignment.unarchived_at).strftime('%d.%m.%Y %H:%M') if assignment.unarchived_at else '',
            'unarchived_display': assignment.unarchived_display,
            'due_date': assignment.due_date.strftime('%d.%m.%Y') if assignment.due_date else '',
            'link_url': assignment.link_url,
            'link_label': assignment.link_label or assignment.link_url,
            'youtube_url': assignment.youtube_embed_url,
            'youtube_watch_url': assignment.youtube_watch_url,
            'youtube_videos': assignment.all_youtube_videos,
            'extra_links': extra_links,
            'files': files_data,
            'is_archived': is_archived,
            'status': assignment.status,
            'can_edit': bool(
                is_teacher and
                (request.user.is_superuser or (hasattr(request.user, 'teacher_profile') and request.user.teacher_profile == assignment.teacher))
            ),
        }
        return JsonResponse(data)

    # Інші завдання цього класу або вчителя для сайдбару
    related_assignments = scope_assignments(request, Assignment.objects.all()).filter(
        status=Assignment.STATUS_PUBLISHED
    ).exclude(pk=assignment.pk).filter(
        Q(classes__in=assignment.classes.all()) | Q(teacher=assignment.teacher)
    ).distinct().select_related('teacher', 'subject')[:5]

    submissions_count = scope_submissions(request, Submission.objects.filter(assignment=assignment)).count()

    # Підготовка матеріалів для вбудованого перегляду у тій же вкладці
    files_with_preview = []
    archive_files = ['.zip', '.rar', '.7z', '.tar', '.gz', '.tgz']
    office_preview = ['.docx', '.doc', '.xlsx', '.xls', '.pptx', '.ppt', '.odt', '.ods', '.odp']
    text_files = ['.txt', '.text', '.log', '.csv', '.md', '.py', '.js', '.html', '.css', '.json', '.sh', '.cpp', '.c', '.java', '.xml', '.sql', '.pas', '.cs', '.php', '.rb', '.go', '.rs', '.kt', '.swift', '.ts']

    for af in assignment.files.all():
        ext = af.get_extension()
        file_path = af.file.path if af.file else None
        preview_type = 'download_only'
        html_preview = None
        text_preview = None
        error_preview = None
        archive_items = None
        slide_urls = None
        pdf_preview_url = None

        if file_path and os.path.exists(file_path):
            if ext in ['.docx', '.doc', '.xlsx', '.xls', '.pptx', '.ppt', '.odt', '.ods', '.odp']:
                preview_type = 'office'
            elif ext == '.sb3':
                preview_type = 'scratch'
            elif ext == '.hex':
                preview_type = 'microbit'
            elif ext == '.pdf':
                preview_type = 'pdf'
            elif ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp']:
                preview_type = 'image'
            elif ext in ['.mp3', '.wav', '.ogg', '.flac', '.aac']:
                preview_type = 'audio'
            elif ext in ['.mp4', '.webm', '.ogv', '.mov', '.m4v', '.mkv', '.avi', '.3gp']:
                preview_type = 'video'
            elif ext in archive_files:
                preview_type = 'archive'
            elif ext in text_files:
                preview_type = 'text' if ext in ['.txt', '.text', '.log', '.csv'] else 'code'

        files_with_preview.append({
            'obj': af,
            'id': af.id,
            'original_name': af.original_name or os.path.basename(af.file.name),
            'url': af.file.url if af.file else '',
            'size_display': af.get_size_display(),
            'icon': af.get_file_icon(),
            'extension': ext,
            'preview_type': preview_type,
            'html_preview': html_preview,
            'text_preview': text_preview,
            'archive_items': archive_items,
            'error_preview': error_preview,
            'slide_urls': slide_urls,
            'slide_count': len(slide_urls) if slide_urls else 0,
            'pdf_preview_url': pdf_preview_url,
        })

    assigned_classes = list(scope_classes(request, assignment.classes.all()))
    selected_class = next((group for group in assigned_classes if str(group.pk) == request.GET.get('class')), None)
    if selected_class is None and len(assigned_classes) == 1:
        selected_class = assigned_classes[0]
    assignment_submit_url = reverse('submit_assignment', args=[assignment.pk])
    if selected_class:
        assignment_submit_url += f'?class={selected_class.pk}'

    context = {
        'assignment': assignment,
        'is_archived': is_archived,
        'is_teacher': is_teacher,
        'can_edit': can_edit,
        'related_assignments': related_assignments,
        'submissions_count': submissions_count,
        'all_classes': scope_classes(request, teaching_classes(ClassGroup.objects.all())).order_by('grade', 'letter'),
        'files_with_preview': files_with_preview,
        'has_assignment_materials': bool(files_with_preview or assignment.link_url or assignment.additional_links.all() or assignment.all_youtube_videos),
        'assignment_submit_url': assignment_submit_url,
        'selected_submission_class_id': selected_class.pk if selected_class else '',
    }
    return render(request, 'feed/assignment_detail.html', context)



def student_submissions_portal(request):
    """
    Публічний розділ для учнів «Здані роботи»:
    - Учні можуть знайти свої здані роботи за прізвищем/іменем або класом.
    - Переглянути статус (Очікує перевірки / Оцінено).
    - Прочитати коментарі та зауваження вчителя.
    """
    class_groups = scope_classes(request, teaching_classes(ClassGroup.objects.all())).order_by('grade', 'letter', 'name')
    selected_class_id = request.GET.get('class')
    search_query = request.GET.get('search', '').strip()

    show_all = request.GET.get('all_attempts') == '1'

    submissions_qs = Submission.objects.all().select_related(
        'assignment', 'class_group', 'teacher', 'assignment__subject', 'previous_submission'
    ).prefetch_related('comments', 'comments__author', 'files').order_by('-submitted_at')

    submissions_qs = scope_submissions(request, submissions_qs)
    if not show_all:
        submissions_qs = submissions_qs.filter(is_latest_attempt=True)

    if selected_class_id:
        try:
            cid = int(selected_class_id)
            submissions_qs = submissions_qs.filter(class_group_id=cid)
        except (ValueError, TypeError):
            pass

    if search_query:
        submissions_qs = fuzzy_search_submissions(submissions_qs, search_query)

    paginator = Paginator(submissions_qs, 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'feed/student_submissions_portal.html', {
        'page_obj': page_obj,
        'class_groups': class_groups,
        'selected_class_id': selected_class_id,
        'search_query': search_query,
    })



def clear_class_filter(request):
    """Скидає фільтр класу з сесії."""
    if 'selected_class' in request.session:
        del request.session['selected_class']
    return redirect('index')


def feed_fragment(request):
    """
    AJAX: повертає лише HTML фрагмент стрічки завдань (картки + пагінація).
    Використовується при клінці на фільтр класу/предмету/дати без перезавантаження сторінки.
    """
    class_group_id, subject_id, date_str, query = _parse_filter_params(request)
    page_number = request.GET.get('page', 1)

    upcoming_qs, rest_qs = get_visible_assignments(class_group_id, request=request)

    # Застосовуємо додаткові фільтри до обох частин
    if subject_id:
        upcoming_qs = upcoming_qs.filter(subject__id=subject_id)
        rest_qs = rest_qs.filter(subject__id=subject_id)

    if date_str:
        from datetime import datetime
        dt_val = datetime.strptime(date_str, '%Y-%m-%d').date()
        upcoming_qs = _filter_assignments_by_lesson_date(upcoming_qs, dt_val, class_group_id)
        rest_qs = _filter_assignments_by_lesson_date(rest_qs, dt_val, class_group_id)

    if query:
        upcoming_qs = search_assignments(upcoming_qs, query)
        rest_qs = search_assignments(rest_qs, query)

    from itertools import chain
    combined = AssignmentChain(upcoming_qs, rest_qs)

    paginator = Paginator(combined, 10)
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    all_subjects = Subject.objects.filter(teacher__isnull=False).distinct()
    has_multiple_subjects = all_subjects.count() > 1
    selected_class = ClassGroup.objects.filter(id=class_group_id).first() if class_group_id else None

    selected_date_display = ""
    if date_str:
        try:
            from datetime import datetime
            dt = datetime.strptime(date_str, '%Y-%m-%d').date()
            uk_weekdays = ['Понеділок', 'Вівторок', 'Середа', 'Четвер', 'Пʼятниця', 'Субота', 'Неділя']
            w_name = uk_weekdays[dt.weekday()]
            selected_date_display = f"{w_name}, {dt.strftime('%d.%m.%Y')}"
        except Exception:
            pass

    if class_group_id:
        for a in page_obj.object_list:
            a._for_class_id = class_group_id

    context = {
        'assignments': page_obj.object_list,
        'page_obj': page_obj,
        'selected_class': selected_class,
        'selected_class_id': class_group_id,
        'selected_subject_id': subject_id,
        'selected_date': date_str,
        'selected_date_display': selected_date_display,
        'has_multiple_subjects': has_multiple_subjects,
        'query': query,
    }
    return render(request, 'feed/feed_fragment.html', context)


def calendar_fragment(request):
    """
    AJAX: повертає HTML-фрагмент календаря при зміні місяця або фільтрів.
    """
    class_group_id, subject_id, date_str, _ = _parse_filter_params(request)
    cal_year = request.GET.get('cal_year')
    cal_month = request.GET.get('cal_month')

    calendar_ctx = get_calendar_context(
        request=request,
        year=cal_year,
        month=cal_month,
        selected_date_str=date_str,
        class_group_id=class_group_id,
        subject_id=subject_id
    )
    return render(request, 'feed/calendar_widget.html', {'calendar': calendar_ctx})


def feed_check_updates(request):
    """
    Надлегка перевірка наявності нових або змінених завдань для стрічки.
    Виконує 1 швидкий запит агрегації в БД (<1 мс), не навантажуючи сервер.
    """
    class_group_id, subject_id, date_str, query = _parse_filter_params(request)

    # Для перевірки оновлень не потрібне сортування — робимо прямий запит
    from django.db.models import Max, Count
    qs = scope_assignments(request, Assignment.objects.filter(status=Assignment.STATUS_PUBLISHED))
    if class_group_id:
        qs = qs.filter(classes__id=class_group_id)
    if subject_id:
        qs = qs.filter(subject__id=subject_id)
    if date_str:
        from datetime import datetime
        dt_val = datetime.strptime(date_str, '%Y-%m-%d').date()
        qs = _filter_assignments_by_lesson_date(qs, dt_val, class_group_id)
    if query:
        qs = qs.filter(
            Q(title__icontains=query) |
            Q(description__icontains=query) |
            Q(teacher__full_name__icontains=query)
        )
    agg = qs.aggregate(
        total_count=Count('id'),
        max_id=Max('id'),
        max_pub=Max('published_at')
    )


    pub_ts = int(agg['max_pub'].timestamp()) if agg['max_pub'] else 0
    fingerprint = f"{agg['total_count']}-{agg['max_id'] or 0}-{pub_ts}"

    return JsonResponse({
        'fingerprint': fingerprint,
        'count': agg['total_count'] or 0,
    })


# ═══════════════════════════════════════════════════════════════════════════════
# МАЙСТЕР ПЕРШОГО ЗАПУСКУ (FIRST-RUN SETUP WIZARD)
# ═══════════════════════════════════════════════════════════════════════════════

def first_run_setup(request):
    """
    Майстер первинного налаштування системи.
    Доступний ТІЛЬКИ якщо в системі немає жодного суперкористувача.
    Створює першого адміністратора, прив'язує профіль вчителя та,
    за вибором користувача, ініціалізує стандартні предмети, класи та критерії НУШ.
    """
    from .middleware import set_has_admin, check_has_admin

    # Безпека: якщо суперкористувач уже є в системі — не дозволяємо доступ
    if check_has_admin():
        if get_teacher_or_none(request):
            return redirect('teacher_dashboard')
        messages.info(request, 'Систему вже налаштовано. Будь ласка, увійдіть зі своїм логіном та паролем.')
        return redirect('teacher_login')

    form = FirstRunSetupForm()

    if request.method == 'POST':
        form = FirstRunSetupForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            full_name = form.cleaned_data['full_name']
            email = form.cleaned_data.get('email', '')
            password = form.cleaned_data['password']
            seed_default_data = form.cleaned_data.get('seed_default_data', True)

            # 1. Створюємо суперкористувача Django
            user = User.objects.create_superuser(
                username=username,
                email=email,
                password=password
            )
            name_parts = full_name.strip().split()
            if len(name_parts) >= 2:
                user.last_name = name_parts[0]
                user.first_name = " ".join(name_parts[1:])
            else:
                user.first_name = full_name
            user.save()

            # 2. Створюємо профіль Teacher
            teacher = Teacher.objects.create(
                user=user,
                full_name=full_name,
                avatar_color='#6366f1'
            )

            # 3. Прив'язуємо або створюємо установу (School)
            try:
                school, created_s = School.objects.get_or_create(id=1, defaults={'name': 'Школа', 'admin': user})
                if not school.admin:
                    school.admin = user
                    school.save(update_fields=['admin'])
            except Exception:
                pass

            # 4. Якщо увімкнено — створюємо стандартні предмети, класи та критерії НУШ
            if seed_default_data:
                default_subjects = [
                    {'name': 'Інформатика', 'icon': '💻', 'color': '#6366f1'},
                    {'name': 'Математика', 'icon': '📐', 'color': '#3b82f6'},
                    {'name': 'Фізика', 'icon': '⚡', 'color': '#8b5cf6'},
                    {'name': 'Хімія', 'icon': '🧪', 'color': '#10b981'},
                    {'name': 'Біологія', 'icon': '🧬', 'color': '#06b6d4'},
                    {'name': 'Українська мова', 'icon': '📖', 'color': '#f59e0b'},
                    {'name': 'Українська література', 'icon': '📚', 'color': '#ef4444'},
                    {'name': 'Англійська мова', 'icon': '🌍', 'color': '#ec4899'},
                    {'name': 'Географія', 'icon': '🗺️', 'color': '#84cc16'},
                    {'name': 'Історія', 'icon': '🏛️', 'color': '#f97316'},
                    {'name': 'Мистецтво', 'icon': '🎨', 'color': '#e879f9'},
                    {'name': 'Фізична культура', 'icon': '⚽', 'color': '#14b8a6'},
                ]
                created_subs = []
                for sub_info in default_subjects:
                    s, _ = Subject.objects.get_or_create(
                        name=sub_info['name'],
                        defaults={
                            'icon': sub_info['icon'],
                            'color': sub_info['color'],
                            'created_by': teacher
                        }
                    )
                    created_subs.append(s)

                default_classes = [
                    {'name': '5А', 'grade': 5, 'letter': 'А'},
                    {'name': '6А', 'grade': 6, 'letter': 'А'},
                    {'name': '7А', 'grade': 7, 'letter': 'А'},
                    {'name': '8А', 'grade': 8, 'letter': 'А'},
                    {'name': '9А', 'grade': 9, 'letter': 'А'},
                    {'name': '9Б', 'grade': 9, 'letter': 'Б'},
                    {'name': '10А', 'grade': 10, 'letter': 'А'},
                    {'name': '11А', 'grade': 11, 'letter': 'А'},
                ]
                created_classes = []
                for cls_info in default_classes:
                    c, _ = ClassGroup.objects.get_or_create(
                        name=cls_info['name'],
                        defaults={
                            'grade': cls_info['grade'],
                            'letter': cls_info['letter'],
                            'created_by': teacher
                        }
                    )
                    created_classes.append(c)

                # Пов'язуємо вчителя з усіма створеними предметами та класами
                teacher.subjects.set(created_subs)
                teacher.classes.set(created_classes)

                # Ініціалізуємо пресети критеріїв НУШ
                try:
                    AICriteriaPreset.ensure_default_presets()
                except Exception:
                    pass

                # Ініціалізуємо базові налаштування ШІ
                try:
                    from .models import AISettings
                    AISettings.get_settings()
                except Exception:
                    pass

            # 5. Оновлюємо прапорець наявності адміністратора в пам'яті
            set_has_admin(True)

            # 6. Виконуємо автоматичний вхід під новим обліковим записом
            login(request, user)
            log_submission_activity(user, 'setup', f"Перший запуск: створено адміністратора {full_name}")

            messages.success(
                request,
                f'🎉 Вітаємо, {full_name}! Систему SchoolNet успішно ініціалізовано. '
                f'Ваш обліковий запис адміністратора активовано!'
            )
            return redirect('teacher_dashboard')

    return render(request, 'feed/first_run_setup.html', {'form': form})


# ═══════════════════════════════════════════════════════════════════════════════
# АВТОРИЗАЦІЯ ВЧИТЕЛЯ
# ═══════════════════════════════════════════════════════════════════════════════

def teacher_login(request):
    """Сторінка входу для вчителя."""
    if get_teacher_or_none(request):
        return redirect('teacher_dashboard')

    form = TeacherLoginForm()

    if request.method == 'POST':
        form = TeacherLoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)

            if user is not None:
                # Перевіряємо що є профіль вчителя
                try:
                    teacher = user.teacher_profile
                    login(request, user)
                    log_submission_activity(user, 'login', f"Вчитель {teacher.full_name} увійшов в систему")
                    messages.success(request, f'Вітаємо, {teacher.full_name}! 👋')
                    return redirect('teacher_dashboard')
                except Teacher.DoesNotExist:
                    messages.error(request, 'Профіль вчителя не знайдено для цього облікового запису.')
            else:
                messages.error(request, 'Неправильний логін або пароль.')

    return render(request, 'feed/teacher_login.html', {'form': form})


def teacher_logout(request):
    """Вихід вчителя."""
    log_submission_activity(request.user, 'logout', f"Вчитель {request.user.get_full_name() or request.user.username} вийшов із системи")
    logout(request)
    messages.info(request, 'Ви вийшли з системи.')
    return redirect('index')


# ═══════════════════════════════════════════════════════════════════════════════
# ПАНЕЛЬ ВЧИТЕЛЯ (захищена)
# ═══════════════════════════════════════════════════════════════════════════════

@teacher_required
def teacher_dashboard(request):
    """
    Головна панель вчителя.
    Відображає всі завдання, згруповані за статусом.
    Підтримує AJAX-запити для плавної анімації вкладок.
    """
    teacher = request.user.teacher_profile

    # Автоматично архівуємо завдання, опубліковані понад 14 днів тому
    auto_archive_expired_assignments()

    # Автоматично оновлюємо відкладені публікації
    Assignment.objects.filter(
        teacher=teacher,
        status=Assignment.STATUS_SCHEDULED,
        scheduled_at__lte=timezone.now()
    ).update(
        status=Assignment.STATUS_PUBLISHED,
        published_at=timezone.now()
    )

    # Фільтр по вкладці
    tab = request.GET.get('tab', 'published')
    status_map = {
        'published': Assignment.STATUS_PUBLISHED,
        'draft': Assignment.STATUS_DRAFT,
        'scheduled': Assignment.STATUS_SCHEDULED,
        'archived': Assignment.STATUS_ARCHIVED,
    }
    status_filter = status_map.get(tab, Assignment.STATUS_PUBLISHED)

    from django.db.models import Count, Q as DbQ, Min
    from datetime import datetime, timedelta

    # ── Параметри фільтрації (класи, предмети, дати, пошуковий запит) ─────────
    class_id = request.GET.get('class') or request.GET.get('class_id') or ''
    subject_id = request.GET.get('subject') or request.GET.get('subject_id') or ''
    q = request.GET.get('q', '').strip()
    date_preset = request.GET.get('date_preset', '').strip()
    single_date = request.GET.get('date', '').strip()

    base_qs = Assignment.objects.filter(
        teacher=teacher,
        status=status_filter
    ).prefetch_related('classes', 'files').select_related('subject').annotate(
        submissions_count=Count('submissions', filter=DbQ(submissions__is_latest_attempt=True), distinct=True),
        ungraded_count=Count(
            'submissions',
            filter=(DbQ(submissions__grade__isnull=True) | DbQ(submissions__grade='')) & DbQ(submissions__is_latest_attempt=True),
            distinct=True
        )
    )

    # 1. Фільтр за класом
    if class_id and class_id != 'all':
        try:
            base_qs = base_qs.filter(classes__id=int(class_id))
        except (ValueError, TypeError):
            class_id = ''

    # 2. Фільтр за предметом / темою
    if subject_id and subject_id != 'all':
        try:
            base_qs = base_qs.filter(subject_id=int(subject_id))
        except (ValueError, TypeError):
            subject_id = ''

    # 3. Текстовий пошук за назвою або описом теми
    if q:
        base_qs = base_qs.filter(DbQ(title__icontains=q) | DbQ(description__icontains=q))

    # 4. Фільтр за датою (день уроку, дата створення або дедлайн)
    today = timezone.localtime(timezone.now()).date()
    if date_preset == 'today':
        base_qs = base_qs.filter(
            DbQ(schedule_targets__target_date=today) |
            DbQ(created_at__date=today) |
            DbQ(due_date=today)
        )
    elif date_preset == 'week':
        start_of_week = today - timedelta(days=today.weekday())
        end_of_week = start_of_week + timedelta(days=6)
        base_qs = base_qs.filter(
            DbQ(schedule_targets__target_date__range=[start_of_week, end_of_week]) |
            DbQ(created_at__date__range=[start_of_week, end_of_week]) |
            DbQ(due_date__range=[start_of_week, end_of_week])
        )
    elif date_preset == 'month':
        base_qs = base_qs.filter(
            DbQ(schedule_targets__target_date__year=today.year, schedule_targets__target_date__month=today.month) |
            DbQ(created_at__year=today.year, created_at__month=today.month) |
            DbQ(due_date__year=today.year, due_date__month=today.month)
        )
    elif single_date:
        try:
            dt_val = datetime.strptime(single_date, '%Y-%m-%d').date()
            base_qs = base_qs.filter(
                DbQ(schedule_targets__target_date=dt_val) |
                DbQ(created_at__date=dt_val) |
                DbQ(due_date=dt_val)
            )
        except (ValueError, TypeError):
            single_date = ''

    base_qs = base_qs.distinct()

    # Складання querystring для пагінації та вкладок
    filter_params = []
    if class_id and class_id != 'all':
        filter_params.append(f'class={class_id}')
    if subject_id and subject_id != 'all':
        filter_params.append(f'subject={subject_id}')
    if q:
        from urllib.parse import quote
        filter_params.append(f'q={quote(q)}')
    if date_preset and date_preset != 'all':
        filter_params.append(f'date_preset={date_preset}')
    if single_date:
        filter_params.append(f'date={single_date}')
    filter_querystring = '&'.join(filter_params)

    has_active_filter = bool(
        (class_id and class_id != 'all') or
        (subject_id and subject_id != 'all') or
        q or
        (date_preset and date_preset != 'all') or
        single_date
    )

    # Для вкладки published — сортуємо за актуальністю (target_date >= сьогодні — першими)
    if status_filter == Assignment.STATUS_PUBLISHED:
        base_qs = base_qs.annotate(earliest_target=Min('schedule_targets__target_date'))
        upcoming = base_qs.filter(earliest_target__gte=today).order_by('earliest_target')
        rest = base_qs.filter(DbQ(earliest_target__lt=today) | DbQ(earliest_target__isnull=True)).order_by('-created_at')
        from itertools import chain
        assignments = AssignmentChain(upcoming, rest)
    else:
        assignments = base_qs.order_by('-created_at')

    # Пагінація: не більше 20 завдань на одній сторінці
    paginator = Paginator(assignments, 20)
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)

    # Підраховуємо кількість у кожній вкладці
    counts = {
        'published': Assignment.objects.filter(teacher=teacher, status=Assignment.STATUS_PUBLISHED).count(),
        'draft': Assignment.objects.filter(teacher=teacher, status=Assignment.STATUS_DRAFT).count(),
        'scheduled': Assignment.objects.filter(teacher=teacher, status=Assignment.STATUS_SCHEDULED).count(),
        'archived': Assignment.objects.filter(teacher=teacher, status=Assignment.STATUS_ARCHIVED).count(),
    }

    # Загальна кількість неоцінених здач для значку
    total_ungraded = Submission.objects.filter(
        assignment__teacher=teacher,
        is_latest_attempt=True
    ).filter(Q(grade__isnull=True) | Q(grade='')).count()

    context = {
        'teacher': teacher,
        'assignments': page_obj,
        'page_obj': page_obj,
        'tab': tab,
        'counts': counts,
        'total_ungraded': total_ungraded,
        'all_classes': ClassGroup.objects.exclude(letter='ПК', name__endswith=' (Позакласні)').order_by('grade', 'letter', 'name'),
        'all_subjects': Subject.objects.all().order_by('name'),
        'selected_class_id': str(class_id) if class_id and class_id != 'all' else '',
        'selected_subject_id': str(subject_id) if subject_id and subject_id != 'all' else '',
        'search_query': q,
        'selected_date': single_date,
        'selected_date_preset': date_preset,
        'has_active_filter': has_active_filter,
        'filter_querystring': filter_querystring,
    }

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.GET.get('fragment') == '1':
        return render(request, 'feed/teacher_dashboard_fragment.html', context)

    return render(request, 'feed/teacher_dashboard.html', context)


@teacher_required
def teacher_live_status(request):
    """
    AJAX endpoint для динамічного фонового оновлення інтерфейсу вчителя без F5:
    - Поточний стан уроку за розкладом та зворотний відлік до дзвінка
    - Центр сповіщень (наявність нових здач робіт або уроків без завдань)
    - Лічильники завдань на панелі вчителя (опубліковані, чернетки, заплановані, архів)
    - Лічильник проведених уроків
    """
    teacher = getattr(request.user, 'teacher_profile', None)
    if not teacher and (request.user.is_superuser or request.session.get('superadmin_mode')):
        teacher = Teacher.objects.first()

    if not teacher:
        return JsonResponse({'status': 'error', 'message': 'Профіль вчителя не знайдено'}, status=404)

    now_dt = timezone.localtime(timezone.now())

    from .utils import get_teacher_live_lesson_status, get_teacher_upcoming_notifications
    live_status = get_teacher_live_lesson_status(teacher, now_dt=now_dt)
    notifs = get_teacher_upcoming_notifications(teacher, now_dt=now_dt)
    conducted_info = teacher.get_conducted_lessons_info()

    assignments_qs = Assignment.objects.filter(teacher=teacher)
    counts = {
        'published': assignments_qs.filter(status=Assignment.STATUS_PUBLISHED).count(),
        'draft': assignments_qs.filter(status=Assignment.STATUS_DRAFT).count(),
        'scheduled': assignments_qs.filter(status=Assignment.STATUS_SCHEDULED).count(),
        'archived': assignments_qs.filter(status=Assignment.STATUS_ARCHIVED).count(),
    }

    if request.user.is_superuser or request.session.get('superadmin_mode'):
        pending_count = Submission.objects.filter(is_latest_attempt=True).filter(Q(grade__isnull=True) | Q(grade='')).count()
    else:
        pending_count = Submission.objects.filter(
            assignment__teacher=teacher,
            is_latest_attempt=True
        ).filter(
            Q(grade__isnull=True) | Q(grade='')
        ).count()

    unread_count = len([n for n in notifs if n.get('type') == 'missing_task'])

    notif_list = []
    for n in notifs:
        notif_list.append({
            'id': n.get('id', ''),
            'type': n.get('type', ''),
            'icon': n.get('icon', '🔔'),
            'title': n.get('title', ''),
            'message': n.get('message', ''),
            'action_url': n.get('action_url', ''),
            'action_label': n.get('action_label', ''),
            'badge': n.get('badge', ''),
            'badge_class': n.get('badge_class', ''),
            'time_str': n.get('time_str', ''),
        })

    live_data = {
        'has_schedule': live_status.get('has_schedule', False),
        'status_type': live_status.get('status_type', 'no_schedule'),
        'badge_text': live_status.get('badge_text', ''),
        'badge_class': live_status.get('badge_class', ''),
        'title': live_status.get('title', ''),
        'time_info': live_status.get('time_info', ''),
        'remaining_minutes': live_status.get('remaining_minutes', 0),
        'elapsed_minutes': live_status.get('elapsed_minutes', 0),
        'duration_minutes': live_status.get('duration_minutes', 0),
        'progress_percent': live_status.get('progress_percent', 0),
        'current_lesson_class_id': live_status.get('current_lesson').class_group_id if live_status.get('current_lesson') else None,
        'current_lesson_class_name': live_status.get('current_lesson').class_group.name if live_status.get('current_lesson') else '',
        'next_lesson_class_id': live_status.get('next_lesson').class_group_id if live_status.get('next_lesson') else None,
        'next_lesson_class_name': live_status.get('next_lesson').class_group.name if live_status.get('next_lesson') else '',
        'current_lesson_task': live_status.get('current_lesson_task'),
        'next_lesson_task': live_status.get('next_lesson_task'),
    }

    return JsonResponse({
        'status': 'success',
        'timestamp': now_dt.isoformat(),
        'time_str': now_dt.strftime('%H:%M'),
        'live_status': live_data,
        'notifications': notif_list,
        'notifications_count': len(notifs),
        'unread_notifications_count': unread_count,
        'pending_submissions_count': pending_count,
        'counts': counts,
        'conducted_lessons': conducted_info,
    })



from .cloud_imports import material_transaction


@teacher_required
@material_transaction
def assignment_create(request):
    """Створення нового завдання."""
    teacher = request.user.teacher_profile
    form = AssignmentForm(teacher=teacher)

    if request.method == 'GET':
        class_id = request.GET.get('class') or request.GET.get('class_group')
        subject_id = request.GET.get('subject')

        # ── 1. Автоматичний вибір предмету ──────────────────────────────────────
        chosen_subject_id = None
        if subject_id and str(subject_id).isdigit() and form.fields['subject'].queryset.filter(pk=subject_id).exists():
            chosen_subject_id = int(subject_id)
        else:
            # Спробувати взяти попередньо обраний предмет:
            # а) з поточної сесії
            session_subj = request.session.get('last_created_subject_id')
            if session_subj and form.fields['subject'].queryset.filter(pk=session_subj).exists():
                chosen_subject_id = int(session_subj)
            else:
                # б) з останнього створеного завдання вчителя
                last_asgn = Assignment.objects.filter(teacher=teacher, subject__isnull=False).order_by('-id').first()
                if last_asgn and last_asgn.subject_id and form.fields['subject'].queryset.filter(pk=last_asgn.subject_id).exists():
                    chosen_subject_id = last_asgn.subject_id
                else:
                    # в) предмет, який вчитель викладає найбільше (за розкладом/завданнями)
                    most_taught = teacher.get_most_taught_subject()
                    if most_taught and form.fields['subject'].queryset.filter(pk=most_taught.pk).exists():
                        chosen_subject_id = most_taught.pk

        if chosen_subject_id:
            form.initial['subject'] = chosen_subject_id

        # Classes are selected afresh; an explicit link from a lesson can
        # still provide its class. Previous assignments/session choices do not.
        if class_id and str(class_id).isdigit() and form.fields['classes'].queryset.filter(pk=class_id).exists():
            form.initial['classes'] = [int(class_id)]

    if request.method == 'POST':
        form = AssignmentForm(teacher=teacher, data=request.POST, files=request.FILES)
        if form.is_valid():
            assignment = form.save_with_status(teacher=teacher)

            # Remember the subject; classes are selected explicitly for each new task.
            if assignment.subject_id:
                request.session['last_created_subject_id'] = assignment.subject_id
            request.session.pop('last_created_class_ids', None)

            # ── Зберігаємо дефолтні налаштування ШІ для завдання
            ai_preset_id = request.POST.get('default_ai_preset')
            if ai_preset_id:
                request.session['last_ai_preset_id'] = ai_preset_id
                from .models import AICriteriaPreset
                try:
                    assignment.default_ai_preset = AICriteriaPreset.objects.get(pk=ai_preset_id)
                except AICriteriaPreset.DoesNotExist:
                    pass
            import json as _json
            grs_raw = request.POST.getlist('default_ai_grs')
            assignment.default_ai_grs = _json.dumps(grs_raw) if grs_raw else ''
            assignment.allow_student_ai_check = bool(request.POST.get('allow_student_ai_check'))
            assignment.allow_ai_usage = bool(request.POST.get('allow_ai_usage'))
            assignment.save(update_fields=['default_ai_preset', 'default_ai_grs', 'allow_student_ai_check', 'allow_ai_usage'])

            # Зберігаємо всі прикріплені файли
            ai_task_file = request.POST.get('ai_task_file', '').strip()
            for f in request.FILES.getlist('files'):
                is_task = bool(ai_task_file and (ai_task_file == f"new:{f.name}" or ai_task_file == f.name))
                AssignmentFile.objects.create(
                    assignment=assignment,
                    file=f,
                    original_name=f.name,
                    is_task_source_for_ai=is_task,
                )

            from .cloud_imports import attach
            attach(form.cloud_jobs, assignment, teacher, ai_task_file)

            # Фоновий розігрів попереднього перегляду для прикріплених файлів
            prewarm_assignment_files_preview(assignment)

            # Зберігаємо додаткові посилання
            for url, label in zip(request.POST.getlist('extra_link_url'), request.POST.getlist('extra_link_label')):
                if url.strip():
                    AssignmentLink.objects.create(
                        assignment=assignment,
                        url=url.strip(),
                        label=label.strip()
                    )

            # Зберігаємо додаткові YouTube відео
            for yurl, ytitle in zip(request.POST.getlist('extra_youtube_url'), request.POST.getlist('extra_youtube_title')):
                if yurl.strip():
                    AssignmentYouTubeLink.objects.create(
                        assignment=assignment,
                        url=yurl.strip(),
                        title=ytitle.strip()
                    )

            # ── Санітизація опису завдання від XSS
            from .utils import sanitize_html
            if assignment.description:
                assignment.description = sanitize_html(assignment.description)
                assignment.save(update_fields=['description'])

            # ── Зберігаємо прив'язку до розкладу уроків для класів
            teacher_lesson_schedules = TeacherLessonSchedule.objects.filter(teacher=teacher).select_related('bell_slot', 'class_group')
            base_date = timezone.localtime(assignment.published_at or assignment.scheduled_at or timezone.now()).date()
            curr_dow = base_date.weekday() + 1

            for class_obj in assignment.classes.all():
                target_val = request.POST.get(f"class_schedule_target_{class_obj.id}", 'auto')
                target_date_val = request.POST.get(f"class_schedule_target_date_{class_obj.id}", '').strip()

                day_num = None
                slot_id = None
                computed_target_date = None

                if target_val and target_val.startswith('slot_'):
                    parts = target_val.split('_')
                    if len(parts) == 3:
                        day_num = int(parts[1])
                        slot_id = int(parts[2])
                elif target_val == 'auto':
                    from .lesson_schedule import next_lesson
                    reference = assignment.published_at or assignment.scheduled_at or timezone.now()
                    if target_date_val:
                        try:
                            from datetime import date, datetime, time
                            reference = timezone.make_aware(datetime.combine(date.fromisoformat(target_date_val), time.min))
                        except ValueError:
                            pass
                    cls_sch, computed_target_date = next_lesson(
                        teacher_lesson_schedules.filter(class_group=class_obj), reference, assignment.subject_id)
                    if cls_sch:
                        day_num = cls_sch.day_of_week
                        slot_id = cls_sch.bell_slot_id
                elif target_val == 'none':
                    AssignmentScheduleTarget.objects.filter(assignment=assignment, class_group=class_obj).delete()
                    continue

                if target_date_val:
                    try:
                        import datetime
                        computed_target_date = datetime.datetime.strptime(target_date_val, '%Y-%m-%d').date()
                    except Exception:
                        pass
                elif day_num and computed_target_date is None:
                    import datetime
                    diff = (day_num - curr_dow) % 7
                    computed_target_date = base_date + datetime.timedelta(days=diff)

                if day_num or slot_id or computed_target_date:
                    AssignmentScheduleTarget.objects.update_or_create(
                        assignment=assignment,
                        class_group=class_obj,
                        defaults={
                            'target_day_of_week': day_num,
                            'bell_slot_id': slot_id,
                            'target_date': computed_target_date,
                        }
                    )

            status_labels = {
                Assignment.STATUS_PUBLISHED: 'опубліковано',
                Assignment.STATUS_DRAFT: 'збережено як чернетку',
                Assignment.STATUS_SCHEDULED: 'заплановано до публікації',
            }
            label = status_labels.get(assignment.status, 'збережено')
            from .ai_preparation import queue_after_commit
            queue_after_commit('assignment', assignment.pk)
            messages.success(request, f'Завдання "{assignment.title}" — {label}! ✅')
            if assignment.status == Assignment.STATUS_PUBLISHED and assignment.allow_student_ai_understanding:
                _async_trigger_ai_task_understanding(assignment.pk)
            return redirect('teacher_dashboard')

    from .models import AICriteriaPreset
    AICriteriaPreset.ensure_default_presets()
    criteria_presets = AICriteriaPreset.objects.all()

    teacher_lesson_schedules = list(TeacherLessonSchedule.objects.filter(teacher=teacher).select_related('bell_slot', 'class_group').order_by('day_of_week', 'bell_slot__lesson_number'))
    initial_target_dates = {}
    if request.method == 'GET' and form.initial.get('classes') and request.GET.get('lesson_date'):
        try:
            from datetime import date
            lesson_date = date.fromisoformat(request.GET['lesson_date'])
        except ValueError:
            lesson_date = None
        if lesson_date:
            for schedule in teacher_lesson_schedules:
                if (schedule.class_group_id in form.initial['classes'] and
                        str(schedule.bell_slot_id) == request.GET.get('bell_slot') and
                        schedule.day_of_week == lesson_date.isoweekday() and
                        (not form.initial.get('subject') or schedule.subject_id == form.initial['subject'])):
                    schedule.is_selected_for_assignment = True
                    initial_target_dates[schedule.class_group_id] = lesson_date.isoformat()

    last_preset_id = request.session.get('last_ai_preset_id')
    last_grs_json = '[]'
    if not last_preset_id:
        last_asg = Assignment.objects.filter(teacher=teacher, default_ai_preset__isnull=False).order_by('-created_at').first()
        if last_asg:
            last_preset_id = str(last_asg.default_ai_preset_id)
            last_grs_json = last_asg.default_ai_grs or '[]'
    else:
        last_asg = Assignment.objects.filter(teacher=teacher, default_ai_preset_id=last_preset_id).order_by('-created_at').first()
        if last_asg and last_asg.default_ai_grs:
            last_grs_json = last_asg.default_ai_grs

    context = {
        'teacher': teacher,
        'form': form,
        'is_edit': False,
        'criteria_presets': criteria_presets,
        'last_ai_preset_id': int(last_preset_id) if last_preset_id and str(last_preset_id).isdigit() else None,
        'last_ai_grs': last_grs_json,
        'submitted_ai_grs': request.POST.getlist('default_ai_grs'),
        'teacher_lesson_schedules': teacher_lesson_schedules,
        'existing_target_dates': initial_target_dates,
        'has_cloud_storage': teacher.has_cloud_storage,
        'cloud_storage': teacher.get_cloud_storage(),
    }
    return render(request, 'feed/assignment_form.html', context)


@teacher_required
@material_transaction
def assignment_edit(request, pk):
    """Редагування існуючого завдання."""
    teacher = request.user.teacher_profile
    # Суперадмін може редагувати будь-яке завдання, звичайний вчитель — лише власні
    if request.user.is_superuser or request.session.get('superadmin_mode'):
        assignment = get_object_or_404(Assignment, pk=pk)
    else:
        assignment = get_object_or_404(Assignment, pk=pk, teacher=teacher)


    form = AssignmentForm(teacher=teacher, instance=assignment)
    existing_files = assignment.files.all()
    existing_links = assignment.additional_links.all()
    existing_youtube_links = assignment.youtube_links.all()

    if request.method == 'POST':
        form = AssignmentForm(
            teacher=teacher,
            data=request.POST,
            files=request.FILES,
            instance=assignment
        )

        if form.is_valid():
            # Видаляємо файли, відмічені для видалення
            files_to_delete = request.POST.getlist('delete_files')
            if files_to_delete:
                AssignmentFile.objects.filter(
                    id__in=files_to_delete,
                    assignment=assignment
                ).delete()

            # Зберігаємо оновлене завдання
            assignment = form.save_with_status(teacher=teacher)

            # Remember the subject; classes are selected explicitly for each new task.
            if assignment.subject_id:
                request.session['last_created_subject_id'] = assignment.subject_id
            request.session.pop('last_created_class_ids', None)
            from .utils import sanitize_html
            if assignment.description:
                assignment.description = sanitize_html(assignment.description)
                assignment.save(update_fields=['description'])

            # ── Зберігаємо дефолтні налаштування ШІ
            ai_preset_id = request.POST.get('default_ai_preset')
            if ai_preset_id:
                request.session['last_ai_preset_id'] = ai_preset_id
                try:
                    assignment.default_ai_preset = AICriteriaPreset.objects.get(pk=ai_preset_id)
                except AICriteriaPreset.DoesNotExist:
                    assignment.default_ai_preset = None
            else:
                assignment.default_ai_preset = None
            import json as _json
            grs_raw = request.POST.getlist('default_ai_grs')
            assignment.default_ai_grs = _json.dumps(grs_raw) if grs_raw else ''
            assignment.allow_student_ai_check = bool(request.POST.get('allow_student_ai_check'))
            assignment.allow_ai_usage = bool(request.POST.get('allow_ai_usage'))
            assignment.save(update_fields=['default_ai_preset', 'default_ai_grs', 'allow_student_ai_check', 'allow_ai_usage'])

            # Оновлюємо позначку головного файлу для ШІ
            ai_task_file = request.POST.get('ai_task_file', '').strip()
            AssignmentFile.objects.filter(assignment=assignment).update(is_task_source_for_ai=False)
            if ai_task_file.startswith('existing:'):
                try:
                    exist_id = int(ai_task_file.split(':', 1)[1])
                    AssignmentFile.objects.filter(assignment=assignment, id=exist_id).update(is_task_source_for_ai=True)
                except (ValueError, IndexError):
                    pass

            if ai_task_file.startswith('cloud:'):
                from .models import CloudImport
                import uuid as _uuid
                try:
                    previous_import = CloudImport.objects.filter(pk=_uuid.UUID(ai_task_file[6:]), teacher=teacher,
                        status='attached', assignment_file__assignment=assignment).first()
                    if previous_import:
                        AssignmentFile.objects.filter(pk=previous_import.assignment_file_id).update(is_task_source_for_ai=True)
                except ValueError:
                    pass

            # Додаємо нові файли
            for f in request.FILES.getlist('files'):
                is_task = bool(ai_task_file and (ai_task_file == f"new:{f.name}" or ai_task_file == f.name))
                AssignmentFile.objects.create(
                    assignment=assignment,
                    file=f,
                    original_name=f.name,
                    is_task_source_for_ai=is_task,
                )

            from .cloud_imports import attach
            attach(form.cloud_jobs, assignment, teacher, ai_task_file)

            # Фоновий розігрів попереднього перегляду для нових файлів
            prewarm_assignment_files_preview(assignment)

            # Оновлюємо додаткові посилання (перезаписуємо)
            assignment.additional_links.all().delete()
            for url, label in zip(request.POST.getlist('extra_link_url'), request.POST.getlist('extra_link_label')):
                if url.strip():
                    AssignmentLink.objects.create(
                        assignment=assignment,
                        url=url.strip(),
                        label=label.strip()
                    )

            # Оновлюємо додаткові YouTube відео (перезаписуємо)
            assignment.youtube_links.all().delete()
            for yurl, ytitle in zip(request.POST.getlist('extra_youtube_url'), request.POST.getlist('extra_youtube_title')):
                if yurl.strip():
                    AssignmentYouTubeLink.objects.create(
                        assignment=assignment,
                        url=yurl.strip(),
                        title=ytitle.strip()
                    )

            # ── Оновлюємо прив'язку до розкладу уроків
            teacher_lesson_schedules_all = TeacherLessonSchedule.objects.filter(teacher=teacher).select_related('bell_slot', 'class_group')
            base_date = timezone.localtime(assignment.published_at or assignment.scheduled_at or timezone.now()).date()
            curr_dow = base_date.weekday() + 1

            for class_obj in assignment.classes.all():
                target_val = request.POST.get(f"class_schedule_target_{class_obj.id}", 'auto')
                target_date_val = request.POST.get(f"class_schedule_target_date_{class_obj.id}", '').strip()

                day_num = None
                slot_id = None
                computed_target_date = None

                if target_val and target_val.startswith('slot_'):
                    parts = target_val.split('_')
                    if len(parts) == 3:
                        day_num = int(parts[1])
                        slot_id = int(parts[2])
                elif target_val == 'auto':
                    from .lesson_schedule import next_lesson
                    reference = assignment.published_at or assignment.scheduled_at or timezone.now()
                    if target_date_val:
                        try:
                            from datetime import date, datetime, time
                            reference = timezone.make_aware(datetime.combine(date.fromisoformat(target_date_val), time.min))
                        except ValueError:
                            pass
                    cls_sch, computed_target_date = next_lesson(
                        teacher_lesson_schedules_all.filter(class_group=class_obj), reference, assignment.subject_id)
                    if cls_sch:
                        day_num = cls_sch.day_of_week
                        slot_id = cls_sch.bell_slot_id
                elif target_val == 'none':
                    AssignmentScheduleTarget.objects.filter(assignment=assignment, class_group=class_obj).delete()
                    continue

                if target_date_val:
                    try:
                        import datetime
                        computed_target_date = datetime.datetime.strptime(target_date_val, '%Y-%m-%d').date()
                    except Exception:
                        pass
                elif day_num and computed_target_date is None:
                    import datetime
                    diff = (day_num - curr_dow) % 7
                    computed_target_date = base_date + datetime.timedelta(days=diff)

                if day_num or slot_id or computed_target_date:
                    AssignmentScheduleTarget.objects.update_or_create(
                        assignment=assignment,
                        class_group=class_obj,
                        defaults={
                            'target_day_of_week': day_num,
                            'bell_slot_id': slot_id,
                            'target_date': computed_target_date,
                        }
                    )

            messages.success(request, f'Завдання "{assignment.title}" оновлено! ✅')
            from .ai_preparation import queue_after_commit
            queue_after_commit('assignment', assignment.pk)
            if assignment.status == Assignment.STATUS_PUBLISHED and assignment.allow_student_ai_understanding:
                _async_trigger_ai_task_understanding(assignment.pk, force_refresh=True)
            return redirect('teacher_dashboard')

    AICriteriaPreset.ensure_default_presets()
    criteria_presets = AICriteriaPreset.objects.all()

    teacher_lesson_schedules = list(TeacherLessonSchedule.objects.filter(teacher=teacher).select_related('bell_slot', 'class_group').order_by('day_of_week', 'bell_slot__lesson_number'))
    existing_targets = {t.class_group_id: (t.target_day_of_week, t.bell_slot_id) for t in assignment.schedule_targets.all()}
    existing_target_dates = {t.class_group_id: (t.target_date.strftime('%Y-%m-%d') if t.target_date else '') for t in assignment.schedule_targets.all()}
    for sch in teacher_lesson_schedules:
        sch.is_selected_for_assignment = (existing_targets.get(sch.class_group_id) == (sch.day_of_week, sch.bell_slot_id))

    context = {
        'teacher': teacher,
        'form': form,
        'assignment': assignment,
        'existing_files': existing_files,
        'existing_links': existing_links,
        'existing_youtube_links': existing_youtube_links,
        'is_edit': True,
        'criteria_presets': criteria_presets,
        'teacher_lesson_schedules': teacher_lesson_schedules,
        'existing_target_dates': existing_target_dates,
        'submitted_ai_grs': request.POST.getlist('default_ai_grs'),
        'has_cloud_storage': teacher.has_cloud_storage,
        'cloud_storage': teacher.get_cloud_storage(),
    }
    return render(request, 'feed/assignment_form.html', context)


@teacher_required
def assignment_delete(request, pk):
    """Видалення завдання (POST-запит)."""
    teacher = request.user.teacher_profile
    if request.user.is_superuser or request.session.get('superadmin_mode'):
        assignment = get_object_or_404(Assignment, pk=pk)
    else:
        assignment = get_object_or_404(Assignment, pk=pk, teacher=teacher)

    if request.method == 'POST':
        title = assignment.title
        assignment.delete()
        messages.success(request, f'Завдання "{title}" видалено.')

    referer = request.META.get('HTTP_REFERER')
    if referer and request.get_host() in referer:
        return redirect(referer)
    return redirect('teacher_dashboard')


@teacher_required
def assignment_unarchive(request, pk):
    """
    Розархівація завдання з архіву (POST-запит).
    Повертає статус 'published', зберігаючи первинну дату публікації 'published_at',
    та встановлює час розархівації у полі 'unarchived_at'.
    """
    teacher = request.user.teacher_profile
    assignment = get_object_or_404(Assignment, pk=pk)

    if not (request.user.is_superuser or assignment.teacher == teacher):
        messages.error(request, 'У вас немає прав для розархівації цього завдання.')
        return redirect('teacher_dashboard')

    if request.method == 'POST':
        assignment.status = Assignment.STATUS_PUBLISHED
        assignment.unarchived_at = timezone.now()
        # Первинна дата published_at залишається незмінною!
        assignment.save(update_fields=['status', 'unarchived_at', 'updated_at'])
        messages.success(request, f'Завдання «{assignment.title}» успішно розархівовано (первинну дату збережено)! ♻️')

    referer = request.META.get('HTTP_REFERER')
    if referer and request.get_host() in referer:
        return redirect(referer)
    return redirect(f"{reverse('teacher_dashboard')}?tab=published")


@teacher_required
def assignment_duplicate(request, pk):
    """
    Дублювання завдання.
    Створює повноцінне нове завдання-копію в БД:
    - Копіює назву, опис (з форматуванням), предмети, вкладені файли, посилання, YouTube відео, налаштування ШІ.
    - НЕ копіює ID, дату створення, здачі учнів, оцінки, коментарі учнів, логи активності.
    - Дозволяє вказати новий цільовий клас, урок та дату для копії.
    - Створює відповідний AssignmentScheduleTarget, щоб новий урок відображався в розкладі та календарі.
    - Не змінює оригінальне завдання.
    """
    teacher = request.user.teacher_profile
    if request.user.is_superuser or request.session.get('superadmin_mode'):
        original = get_object_or_404(Assignment, pk=pk)
    else:
        original = get_object_or_404(Assignment, pk=pk, teacher=teacher)

    clean_title = original.title
    if clean_title.startswith('[Копія] '):
        clean_title = clean_title[len('[Копія] '):]
    elif clean_title.startswith('Копія '):
        clean_title = clean_title[len('Копія '):]

    # Дозволяємо вказати нову власну назву для копії
    custom_title = request.POST.get('duplicate_title', '').strip()
    if custom_title:
        clean_title = custom_title

    # Визначаємо класи для копії: якщо передано у POST — беремо їх, інакше класи оригіналу
    selected_class_ids = request.POST.getlist('duplicate_classes') or request.POST.getlist('duplicate_classes[]')
    if not selected_class_ids and request.POST.get('duplicate_class'):
        selected_class_ids = [request.POST.get('duplicate_class')]

    if not selected_class_ids:
        target_classes = list(original.classes.all())
    else:
        target_classes = list(ClassGroup.objects.filter(id__in=selected_class_ids))

    publish_now = (request.POST.get('publish_now') == '1' or request.POST.get('action') == 'publish')
    new_status = Assignment.STATUS_PUBLISHED if publish_now else Assignment.STATUS_DRAFT
    now = timezone.now()

    # Створюємо дублікат
    duplicate = Assignment.objects.create(
        teacher=teacher,
        subject=original.subject,
        title=clean_title,
        description=original.description,
        is_individual=original.is_individual,
        student_name=original.student_name,
        link_url=original.link_url,
        link_label=original.link_label,
        due_date=original.due_date,
        status=new_status,
        duplicated_from=original,
        published_at=now if publish_now else None,
        default_ai_preset=original.default_ai_preset,
        default_ai_grs=original.default_ai_grs,
        class_ai_overrides={str(c.pk): original.class_ai_overrides[str(c.pk)] for c in target_classes if str(c.pk) in original.class_ai_overrides},
        allow_student_ai_check=original.allow_student_ai_check,
        allow_student_ai_understanding=original.allow_student_ai_understanding,
        allow_ai_usage=original.allow_ai_usage,
        custom_criteria=original.custom_criteria,
        teacher_ai_instructions=getattr(original, 'teacher_ai_instructions', ''),
        no_submission_required=original.no_submission_required,
    )
    duplicate.classes.set(target_classes)

    # Копіюємо файли (посилання на ті самі файли, без фізичного копіювання)
    for f in original.files.all():
        new_f = AssignmentFile.objects.create(
            assignment=duplicate,
            file=f.file,
            original_name=f.original_name,
            is_task_source_for_ai=f.is_task_source_for_ai,
        )
        _copy_preview_cache(f.id, new_f.id)

    # Розігріваємо будь-які відсутні прев'ю у фоновому режимі
    prewarm_assignment_files_preview(duplicate)

    # Копіюємо додаткові посилання
    for lnk in original.additional_links.all():
        AssignmentLink.objects.create(
            assignment=duplicate,
            url=lnk.url,
            label=lnk.label,
        )

    # Копіюємо відео YouTube
    for ytb in original.youtube_links.all():
        AssignmentYouTubeLink.objects.create(
            assignment=duplicate,
            url=ytb.url,
            title=ytb.title,
        )

    # Зберігаємо прив'язку до уроку(ів) для нового завдання
    base_date = timezone.localtime(now).date()
    curr_dow = base_date.weekday() + 1
    teacher_lesson_schedules = TeacherLessonSchedule.objects.filter(teacher=teacher).select_related('bell_slot')

    for class_obj in target_classes:
        target_slot_val = request.POST.get(f"duplicate_target_slot_{class_obj.id}") or request.POST.get("duplicate_target_slot")
        target_date_val = request.POST.get(f"duplicate_target_date_{class_obj.id}") or request.POST.get("duplicate_target_date")

        day_num = None
        slot_id = None
        target_date = None

        if target_slot_val:
            if target_slot_val.startswith('slot_'):
                parts = target_slot_val.split('_')
                if len(parts) == 3:
                    day_num = int(parts[1])
                    slot_id = int(parts[2])
                elif len(parts) == 2:
                    slot_id = int(parts[1])
            elif target_slot_val.isdigit():
                slot_id = int(target_slot_val)

        if not slot_id and not day_num:
            orig_target = original.schedule_targets.filter(class_group=class_obj).first()
            if orig_target:
                day_num = orig_target.target_day_of_week
                slot_id = orig_target.bell_slot_id
            else:
                cls_sch = teacher_lesson_schedules.filter(class_group=class_obj).first()
                if cls_sch:
                    day_num = cls_sch.day_of_week
                    slot_id = cls_sch.bell_slot_id

        if target_date_val:
            try:
                import datetime
                target_date = datetime.datetime.strptime(target_date_val.strip(), '%Y-%m-%d').date()
            except Exception:
                pass
        elif day_num:
            import datetime
            diff = (day_num - curr_dow) % 7
            target_date = base_date + datetime.timedelta(days=diff)

        if target_date:
            day_num = target_date.weekday() + 1

        if day_num or slot_id or target_date:
            AssignmentScheduleTarget.objects.create(
                assignment=duplicate,
                class_group=class_obj,
                target_day_of_week=day_num,
                bell_slot_id=slot_id,
                target_date=target_date
            )

    if publish_now and duplicate.allow_student_ai_understanding:
        _async_trigger_ai_task_understanding(duplicate.pk)

    is_ajax = request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.GET.get('format') == 'json'
    if is_ajax:
        return JsonResponse({
            'status': 'success',
            'duplicate_id': duplicate.pk,
            'title': duplicate.title,
            'status_label': 'Опубліковано' if publish_now else 'Чернетка',
            'message': f'Створено копію завдання «{duplicate.title}»! ✅',
            'redirect_url': reverse('teacher_dashboard') if publish_now else reverse('assignment_edit', args=[duplicate.pk])
        })

    if publish_now:
        messages.success(request, f'Створено та опубліковано копію завдання «{duplicate.title}»! ✅')
        return redirect('teacher_dashboard')
    else:
        messages.success(request, f'Створено копію завдання «{duplicate.title}». Можна відредагувати та опублікувати.')
        return redirect('assignment_edit', pk=duplicate.pk)


@teacher_required
def assignment_archive(request, pk):
    """Переміщення завдання до архіву."""
    teacher = request.user.teacher_profile
    if request.user.is_superuser or request.session.get('superadmin_mode'):
        assignment = get_object_or_404(Assignment, pk=pk)
    else:
        assignment = get_object_or_404(Assignment, pk=pk, teacher=teacher)

    if request.method == 'POST':
        assignment.status = Assignment.STATUS_ARCHIVED
        assignment.save()
        messages.info(request, f'Завдання "{assignment.title}" переміщено до архіву.')

    referer = request.META.get('HTTP_REFERER')
    if referer and request.get_host() in referer:
        return redirect(referer)
    return redirect('teacher_dashboard')


@teacher_required
def assignment_publish(request, pk):
    """Миттєва публікація чернетки або відкладеного завдання."""
    teacher = request.user.teacher_profile
    if request.user.is_superuser or request.session.get('superadmin_mode'):
        assignment = get_object_or_404(Assignment, pk=pk)
    else:
        assignment = get_object_or_404(Assignment, pk=pk, teacher=teacher)

    if request.method == 'POST':
        assignment.status = Assignment.STATUS_PUBLISHED
        if not assignment.published_at or assignment.duplicated_from_id is not None:
            assignment.published_at = timezone.now()
        assignment.save()
        messages.success(request, f'Завдання "{assignment.title}" опубліковано! ✅')

    referer = request.META.get('HTTP_REFERER')
    if referer and request.get_host() in referer:
        return redirect(referer)
    return redirect('teacher_dashboard')


@teacher_required
def teacher_profile(request):
    """
    Редагування профілю вчителя:
    - Персональні предмети та класи вчителя (додавання/видалення з власного профілю).
    - Створення нових предметів та класів.
    - Функції Супер-Адміністратора: створення нових вчителів та скидання їхніх паролів.
    """
    teacher = request.user.teacher_profile
    profile_form = TeacherProfileForm(instance=teacher)
    subject_form = SubjectForm()
    class_form = ClassGroupForm()
    teacher_create_form = TeacherCreateForm()
    password_reset_form = PasswordResetForm()

    if request.method == 'POST':
        action = request.POST.get('action')

        # ── Оновлення основних даних (ПІБ, колір, фото аватара) ──────────────
        if action == 'update_profile':
            profile_form = TeacherProfileForm(request.POST, request.FILES, instance=teacher)
            if profile_form.is_valid():
                profile_form.save()
                messages.success(request, 'Профіль та аватар успішно збережено! ✅')
                return redirect('teacher_profile')
            else:
                for field, errors in profile_form.errors.items():
                    for err in errors:
                        messages.error(request, f'{err}')

        elif action == 'remove_avatar':
            if teacher.avatar_image:
                try:
                    import os
                    if os.path.exists(teacher.avatar_image.path):
                        os.remove(teacher.avatar_image.path)
                except Exception:
                    pass
                teacher.avatar_image = None
                teacher.save(update_fields=['avatar_image'])
                messages.info(request, 'Фото аватара видалено. Використовуються кольорові ініціали.')
            return redirect('teacher_profile')

        # ── Персональні предмети вчителя ─────────────────────────────────────
        elif action == 'add_teacher_subject':
            subject_id = request.POST.get('subject_id')
            if subject_id:
                subject = get_object_or_404(Subject, pk=subject_id)
                teacher.subjects.add(subject)
                messages.success(request, f'Предмет «{subject.name}» додано до вашого профілю! 📚')
            return redirect('teacher_profile')

        elif action == 'remove_teacher_subject':
            subject_id = request.POST.get('subject_id')
            if subject_id:
                subject = get_object_or_404(Subject, pk=subject_id)
                teacher.subjects.remove(subject)
                messages.info(request, f'Предмет «{subject.name}» видалено з вашого профілю.')
            return redirect('teacher_profile')

        # ── Персональні класи вчителя ─────────────────────────────────────────
        elif action == 'add_teacher_class':
            class_id = request.POST.get('class_id')
            if class_id:
                cgroup = get_object_or_404(ClassGroup, pk=class_id)
                teacher.classes.add(cgroup)
                messages.success(request, f'Клас «{cgroup.name}» додано до вашого профілю! 🏫')
            return redirect('teacher_profile')

        elif action == 'remove_teacher_class':
            class_id = request.POST.get('class_id')
            if class_id:
                cgroup = get_object_or_404(ClassGroup, pk=class_id)
                teacher.classes.remove(cgroup)
                messages.info(request, f'Клас «{cgroup.name}» видалено з вашого профілю.')
            return redirect('teacher_profile')

        # ── Створення нового предмету (і авто-додавання вчителю) ──────────────
        elif action == 'create_subject':
            subject_form = SubjectForm(request.POST)
            if subject_form.is_valid():
                subject = subject_form.save(commit=False)
                subject.created_by = teacher
                subject.save()
                teacher.subjects.add(subject)
                messages.success(request, f'Новий предмет «{subject.name}» створено та додано до профілю! 📚')
                return redirect('teacher_profile')
            else:
                messages.error(request, 'Помилка при створенні предмету.')

        # ── Створення нового класу (і авто-додавання вчителю) ─────────────────
        elif action == 'create_class':
            class_form = ClassGroupForm(request.POST)
            if class_form.is_valid():
                cgroup = class_form.save(commit=False)
                cgroup.created_by = teacher
                cgroup.save()
                teacher.classes.add(cgroup)
                messages.success(request, f'Новий клас «{cgroup.name}» створено та додано до профілю! 🏫')
                return redirect('teacher_profile')
            else:
                messages.error(request, 'Помилка при створенні класу.')

        # ── Функції Супер-Адміністратора: Створення акаунта вчителя ─────────
        elif action == 'create_teacher_account':
            if not request.user.is_superuser:
                messages.error(request, 'Тільки Супер-Адміністратор може створювати акаунти.')
                return redirect('teacher_profile')

            teacher_create_form = TeacherCreateForm(request.POST)
            if teacher_create_form.is_valid():
                username = teacher_create_form.cleaned_data['username']
                password = teacher_create_form.cleaned_data['password']
                full_name = teacher_create_form.cleaned_data['full_name']
                is_super = teacher_create_form.cleaned_data['is_superuser']

                new_user = User.objects.create_user(username=username, password=password)
                new_user.is_superuser = is_super
                new_user.is_staff = is_super
                new_user.save()

                Teacher.objects.create(user=new_user, full_name=full_name)
                role = "Супер-Адміністратор" if is_super else "Вчитель"
                messages.success(request, f'Акаунт ({role}) «{full_name}» ({username}) створено! 👤')
                return redirect('teacher_profile')
            else:
                for field, errors in teacher_create_form.errors.items():
                    for err in errors:
                        messages.error(request, f'{err}')

        # ── Функції Супер-Адміністратора: Скидання пароля ────────────────────
        elif action == 'reset_teacher_password':
            if not request.user.is_superuser:
                messages.error(request, 'Тільки Супер-Адміністратор може скидати паролі.')
                return redirect('teacher_profile')

            target_user_id = request.POST.get('user_id')
            new_pass = request.POST.get('new_password', '').strip()

            if target_user_id and new_pass:
                target_user = get_object_or_404(User, pk=target_user_id)
                target_user.set_password(new_pass)
                target_user.save()
                messages.success(request, f'Пароль для користувача {target_user.username} змінено! 🔑')
            else:
                messages.error(request, 'Вкажіть новий пароль.')
            return redirect('teacher_profile')

        # ── Функції Супер-Адміністратора: Видалення вчителя та матеріалів ─────
        elif action == 'delete_teacher':
            if not request.user.is_superuser:
                messages.error(request, 'Тільки Супер-Адміністратор може видаляти вчителів.')
                return redirect('teacher_profile')

            target_teacher_id = request.POST.get('teacher_id')
            if target_teacher_id:
                target_teacher = get_object_or_404(Teacher, pk=target_teacher_id)
                
                # Запобігаємо видаленню самого себе
                if target_teacher.user == request.user:
                    messages.error(request, 'Ви не можете видалити власний акаунт.')
                    return redirect('teacher_profile')

                # Видаляємо фізичні файли завдань вчителя з диска
                import os
                for assignment in target_teacher.assignments.all():
                    for file_obj in assignment.files.all():
                        if file_obj.file and os.path.exists(file_obj.file.path):
                            try:
                                os.remove(file_obj.file.path)
                            except Exception:
                                pass

                # Видаляємо користувача (і пов'язаного вчителя cascade)
                user_to_delete = target_teacher.user
                full_name_deleted = target_teacher.full_name
                username_deleted = user_to_delete.username
                user_to_delete.delete()

                messages.success(request, f'Вчителя «{full_name_deleted}» ({username_deleted}) та всі його матеріали успішно видалено! 🗑️')
            else:
                messages.error(request, 'Вкажіть вчителя для видалення.')
            return redirect('teacher_profile')


    # Отримуємо дані для сторінки (тільки предмети та класи, створені вчителями)
    teacher_subjects = teacher.subjects.all()
    teacher_classes = teaching_classes(teacher.classes.all()).order_by('grade', 'letter')

    other_subjects = Subject.objects.filter(created_by__isnull=False).exclude(id__in=teacher_subjects.values_list('id', flat=True))
    other_classes = teaching_classes(ClassGroup.objects.filter(created_by__isnull=False).exclude(id__in=teacher_classes.values_list('id', flat=True))).order_by('grade', 'letter')


    all_teachers = Teacher.objects.select_related('user').all() if request.user.is_superuser else []

    context = {
        'teacher': teacher,
        'form': profile_form,
        'subject_form': subject_form,
        'class_form': class_form,
        'teacher_create_form': teacher_create_form,
        'password_reset_form': password_reset_form,
        'teacher_subjects': teacher_subjects,
        'teacher_classes': teacher_classes,
        'other_subjects': other_subjects,
        'other_classes': other_classes,
        'all_teachers': all_teachers,
        'cloud_storage': teacher.get_cloud_storage(),
    }
    return render(request, 'feed/teacher_profile.html', context)


from django.views.decorators.clickjacking import xframe_options_exempt, xframe_options_sameorigin


def _run_libreoffice_convert(input_path, out_dir, convert_to='pdf', timeout=40):
    """
    Safely runs headless LibreOffice conversion with an isolated user profile
    to prevent profile locks, collisions, and exit code 81.
    """
    lo_bin = shutil.which('libreoffice') or shutil.which('soffice')
    if not lo_bin:
        return False
        
    temp_profile_dir = tempfile.mkdtemp(prefix='lo_profile_')
    try:
        cmd = [
            lo_bin,
            '--headless',
            f'-env:UserInstallation=file://{temp_profile_dir}',
            '--convert-to', convert_to,
            '--outdir', out_dir,
            input_path
        ]
        res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=timeout)
        return res.returncode == 0
    except Exception as e:
        print(f"LibreOffice conversion error for {input_path}: {e}")
        return False
    finally:
        shutil.rmtree(temp_profile_dir, ignore_errors=True)


def _copy_preview_cache(old_file_id, new_file_id):
    """
    Copies or hardlinks already rendered preview files (PDF and slides) from old_file_id to new_file_id.
    Makes assignment duplication instantaneous with 0 conversion overhead.
    """
    try:
        from django.conf import settings
        previews_root = os.path.join(settings.MEDIA_ROOT, 'previews')
        
        # 1. Direct PDF
        old_pdf = os.path.join(previews_root, f"{old_file_id}.pdf")
        new_pdf = os.path.join(previews_root, f"{new_file_id}.pdf")
        if os.path.exists(old_pdf) and not os.path.exists(new_pdf):
            try:
                os.link(old_pdf, new_pdf)
            except Exception:
                try:
                    shutil.copyfile(old_pdf, new_pdf)
                except Exception:
                    pass

        # 2. Slide images dir
        old_dir = os.path.join(previews_root, str(old_file_id))
        new_dir = os.path.join(previews_root, str(new_file_id))
        if os.path.isdir(old_dir) and not os.path.exists(new_dir):
            try:
                shutil.copytree(old_dir, new_dir)
            except Exception:
                pass
    except Exception as e:
        print(f"Error copying preview cache from {old_file_id} to {new_file_id}: {e}")


def _do_generate_file_preview(file_id, file_path=None):
    """
    Performs the heavy conversion of an attached file to PDF and slide JPEGs.
    Ensures safe, isolated execution and writes results to MEDIA_ROOT/previews/.
    """
    from django.conf import settings

    if not file_path:
        from .models import AssignmentFile
        af = AssignmentFile.objects.filter(id=file_id).first()
        if not af or not af.file:
            return
        try:
            file_path = af.file.path
        except Exception:
            return

    if not file_path or not os.path.exists(file_path):
        return

    ext = os.path.splitext(file_path)[1].lower()
    previews_dir = os.path.join(settings.MEDIA_ROOT, 'previews')
    os.makedirs(previews_dir, exist_ok=True)

    if ext in ['.pptx', '.ppt', '.odp']:
        cache_dir = os.path.join(previews_dir, str(file_id))
        os.makedirs(cache_dir, exist_ok=True)
        pdf_path = os.path.join(cache_dir, 'presentation.pdf')
        
        # 1. Convert to PDF if not present
        if not os.path.exists(pdf_path):
            success = _run_libreoffice_convert(file_path, cache_dir, convert_to='pdf', timeout=40)
            if success:
                base_name = os.path.splitext(os.path.basename(file_path))[0]
                gen_pdf = os.path.join(cache_dir, base_name + '.pdf')
                if os.path.exists(gen_pdf) and gen_pdf != pdf_path:
                    try:
                        os.rename(gen_pdf, pdf_path)
                    except Exception:
                        pass
                elif not os.path.exists(pdf_path):
                    pdfs = [p for p in glob.glob(os.path.join(cache_dir, '*.pdf')) if p != pdf_path]
                    if pdfs:
                        try:
                            os.rename(pdfs[0], pdf_path)
                        except Exception:
                            pass

        # Also copy/link presentation.pdf to previews/<file_id>.pdf
        if os.path.exists(pdf_path):
            direct_pdf = os.path.join(previews_dir, f"{file_id}.pdf")
            if not os.path.exists(direct_pdf):
                try:
                    os.link(pdf_path, direct_pdf)
                except Exception:
                    try:
                        shutil.copyfile(pdf_path, direct_pdf)
                    except Exception:
                        pass

            # 2. Generate slide JPEGs if pdftoppm is available
            slide_files = sorted(glob.glob(os.path.join(cache_dir, 'slide-*.jpg')))
            if not slide_files and shutil.which('pdftoppm'):
                prefix = os.path.join(cache_dir, 'slide')
                cmd = ['pdftoppm', '-jpeg', '-r', '130', pdf_path, prefix]
                try:
                    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=40)
                except Exception:
                    pass

    elif ext in ['.docx', '.doc', '.odt', '.xlsx', '.xls']:
        pdf_path = os.path.join(previews_dir, f"{file_id}.pdf")
        if not os.path.exists(pdf_path):
            try:
                with tempfile.TemporaryDirectory(dir=previews_dir, prefix=f"conv_{file_id}_") as conv_tmp:
                    success = _run_libreoffice_convert(file_path, conv_tmp, convert_to='pdf', timeout=35)
                    if success:
                        gen_pdfs = glob.glob(os.path.join(conv_tmp, '*.pdf'))
                        if gen_pdfs:
                            try:
                                shutil.move(gen_pdfs[0], pdf_path)
                            except Exception:
                                pass
            except Exception:
                pass


def prewarm_single_file_preview(file_id, file_path=None):
    """
    Pre-generates PDF and presentation slide previews in a background daemon thread.
    Thread-safe, avoids duplicate concurrent work for the same file_id.
    """
    if not file_id:
        return

    with _PREVIEW_EVENTS_LOCK:
        if file_id in _PREVIEW_EVENTS:
            return  # Already queued or running
        evt = threading.Event()
        _PREVIEW_EVENTS[file_id] = evt

    def _worker():
        try:
            with _PREVIEW_SEMAPHORE:
                _do_generate_file_preview(file_id, file_path)
        except Exception as e:
            print(f"Error in preview prewarm for file {file_id}: {e}")
        finally:
            evt.set()
            with _PREVIEW_EVENTS_LOCK:
                _PREVIEW_EVENTS.pop(file_id, None)

    t = threading.Thread(target=_worker, name=f"prewarm_preview_{file_id}", daemon=True)
    t.start()


def prewarm_assignment_files_preview(assignment):
    """
    Pre-warms previews for all eligible attached files in an assignment in background threads.
    Eligible files: .pptx, .ppt, .odp, .docx, .doc, .odt, .xlsx, .xls
    """
    if not assignment:
        return
    try:
        files = list(assignment.files.all())
    except Exception:
        files = []

    for af in files:
        if not af.file:
            continue
        ext = af.get_extension()
        if ext in ['.pptx', '.ppt', '.odp', '.docx', '.doc', '.odt', '.xlsx', '.xls']:
            try:
                fpath = af.file.path
                if os.path.exists(fpath):
                    prewarm_single_file_preview(af.id, fpath)
            except Exception:
                pass


def _wait_for_preview(file_id, timeout=30):
    """If a background prewarm job is currently running for file_id, wait for it."""
    evt = None
    with _PREVIEW_EVENTS_LOCK:
        evt = _PREVIEW_EVENTS.get(file_id)
    if evt:
        evt.wait(timeout=timeout)


def get_presentation_slides(file_id, file_path, wait_if_missing=True):
    """
    Генерує або дістає з кешу високоякісні зображення слайдів презентації (.pptx, .ppt, .odp)
    та PDF версію через headless LibreOffice + pdftoppm.
    Повертає (slide_urls, pdf_url).
    """
    from django.conf import settings

    cache_dir = os.path.join(settings.MEDIA_ROOT, 'previews', str(file_id))
    pdf_path = os.path.join(cache_dir, 'presentation.pdf')
    slide_files = sorted(glob.glob(os.path.join(cache_dir, 'slide-*.jpg')))

    # Якщо слайди вже скомпільовані і є на диску -> миттєво віддаємо
    if slide_files and os.path.exists(pdf_path):
        media_url = settings.MEDIA_URL.rstrip('/')
        slide_urls = [f'{media_url}/previews/{file_id}/{os.path.basename(p)}' for p in slide_files]
        pdf_url = f'{media_url}/previews/{file_id}/presentation.pdf'
        return slide_urls, pdf_url

    # Якщо відкладений режим (наприклад під час першого рендеру сторінки завдання учню):
    if not wait_if_missing:
        prewarm_single_file_preview(file_id, file_path)
        return [], None

    # Якщо викликано з очікуванням (AJAX запит за слайдами або тест):
    _wait_for_preview(file_id, timeout=35)

    slide_files = sorted(glob.glob(os.path.join(cache_dir, 'slide-*.jpg')))
    if not (slide_files and os.path.exists(pdf_path)):
        with _PREVIEW_SEMAPHORE:
            _do_generate_file_preview(file_id, file_path)

    slide_files = sorted(glob.glob(os.path.join(cache_dir, 'slide-*.jpg')))
    if not os.path.exists(pdf_path):
        return [], None

    media_url = settings.MEDIA_URL.rstrip('/')
    slide_urls = [f'{media_url}/previews/{file_id}/{os.path.basename(p)}' for p in slide_files]
    pdf_url = f'{media_url}/previews/{file_id}/presentation.pdf'
    return slide_urls, pdf_url


def get_pdf_preview_url(file_obj, wait_if_missing=True):
    """
    Конвертує pptx, docx, або xlsx у PDF за допомогою headless LibreOffice, якщо його ще немає в кеші.
    Повертає URL до PDF файлу або None у разі помилки чи асинхронного режиму.
    """
    from django.conf import settings
    from django.urls import reverse

    previews_dir = os.path.join(settings.MEDIA_ROOT, 'previews')
    pdf_filename = f"{file_obj.id}.pdf"
    pdf_path = os.path.join(previews_dir, pdf_filename)

    if os.path.exists(pdf_path):
        return reverse('file_view', args=[file_obj.id]) + "?preview_pdf=1"

    if not wait_if_missing:
        prewarm_single_file_preview(file_obj.id, file_obj.file.path if file_obj.file else None)
        return None

    # Очікуємо фоновий процес або генеруємо
    _wait_for_preview(file_obj.id, timeout=30)
    if not os.path.exists(pdf_path):
        with _PREVIEW_SEMAPHORE:
            _do_generate_file_preview(file_obj.id, file_obj.file.path if file_obj.file else None)

    if os.path.exists(pdf_path):
        return reverse('file_view', args=[file_obj.id]) + "?preview_pdf=1"

    return None


@xframe_options_exempt
def file_view(request, file_id):
    """Служить файл безпосередньо у браузері з інлайновим Content-Disposition та правильним MIME-типом (зокрема для PDF)."""
    file_obj = get_object_or_404(AssignmentFile.objects.select_related("assignment"), pk=file_id)
    require_assignment_access(request, file_obj.assignment)
    try:
        import mimetypes
        import os
        from django.conf import settings
        
        path = file_obj.file.path
        ext = os.path.splitext(path)[1].lower()

        # Якщо запит йде на PDF прев'ю АБО це документ Office (.docx, .doc, .pptx, .odt), який браузер не показує нативно
        if request.GET.get('preview_pdf') == '1' or ext in ['.docx', '.doc', '.pptx', '.ppt', '.odt']:
            get_pdf_preview_url(file_obj)
            pdf_path = os.path.join(settings.MEDIA_ROOT, 'previews', f"{file_obj.id}.pdf")
            if os.path.exists(pdf_path):
                path = pdf_path
                mime_type = 'application/pdf'
            else:
                mime_type, _ = mimetypes.guess_type(path)
                if not mime_type:
                    mime_type = 'application/octet-stream'
        else:
            if ext == '.pdf':
                mime_type = 'application/pdf'
            elif ext in ['.jpg', '.jpeg']:
                mime_type = 'image/jpeg'
            elif ext == '.png':
                mime_type = 'image/png'
            elif ext == '.webp':
                mime_type = 'image/webp'
            elif ext == '.svg':
                mime_type = 'image/svg+xml'
            elif ext in ['.mp4', '.m4v']:
                mime_type = 'video/mp4'
            elif ext == '.webm':
                mime_type = 'video/webm'
            elif ext == '.ogv':
                mime_type = 'video/ogg'
            elif ext == '.mov':
                mime_type = 'video/quicktime'
            elif ext == '.mkv':
                mime_type = 'video/x-matroska'
            elif ext == '.avi':
                mime_type = 'video/x-msvideo'
            elif ext == '.3gp':
                mime_type = 'video/3gpp'
            elif ext == '.mp3':
                mime_type = 'audio/mpeg'
            elif ext == '.wav':
                mime_type = 'audio/wav'
            elif ext == '.ogg':
                mime_type = 'audio/ogg'
            elif ext == '.sb3':
                mime_type = 'application/x.scratch.sb3'
            elif ext == '.hex':
                mime_type = 'text/plain; charset=utf-8'
            else:
                mime_type, _ = mimetypes.guess_type(path)
                if not mime_type:
                    mime_type = 'application/octet-stream'
                
        return file_response(request, path, content_type=mime_type)
    except Http404:
        raise
    except Exception as e:
        return HttpResponse(f"Помилка завантаження файлу: {str(e)}", status=500)
    return HttpResponse("Файл не знайдено", status=404)


def file_download(request, file_id):
    """Завантажує файл завдання (матеріали вчителя) з правильним ім'ям та розширенням.
    Завжди повертає Content-Disposition: attachment, щоб браузер пропонував зберегти файл.
    """
    import mimetypes
    import os
    from django.http import FileResponse

    file_obj = get_object_or_404(AssignmentFile.objects.select_related("assignment"), pk=file_id)
    require_assignment_access(request, file_obj.assignment)
    try:
        path = file_obj.file.path
        if not os.path.exists(path):
            return HttpResponse("Файл не знайдено на сервері", status=404)

        original_name = file_obj.original_name or os.path.basename(path)
        mime_type, _ = mimetypes.guess_type(path)
        if not mime_type:
            mime_type = 'application/octet-stream'

        response = FileResponse(
            open(path, 'rb'),
            content_type=mime_type,
            as_attachment=True,
            filename=original_name,
        )
        return response
    except Exception as e:
        return HttpResponse(f"Помилка завантаження: {str(e)}", status=500)


@xframe_options_sameorigin
def file_preview(request, file_id):
    """Служба для генерації інлайнового прев'ю файлу (docx, xlsx, pptx, python та інших код-файлів)."""
    file_obj = get_object_or_404(AssignmentFile.objects.select_related("assignment"), pk=file_id)
    require_assignment_access(request, file_obj.assignment)
    ext = file_obj.get_extension()

    # These viewers include their own player/copy controls. Give them a real
    # document lifecycle instead of inserting scripts into the parent dialog.
    if ext in {'.sb3', '.hex'}:
        if request.GET.get('embedded') != '1':
            return JsonResponse({
                'type': 'url', 'file_type': 'embedded',
                'url': reverse('file_preview', args=[file_obj.pk]) + '?embedded=1',
            })
        content, error = '', None
        try:
            raw_url = request.build_absolute_uri(reverse('file_view', args=[file_obj.pk]))
            if ext == '.sb3':
                from .scratch_utils import parse_scratch_sb3
                content, _, error = parse_scratch_sb3(file_obj.file.path, raw_file_url=raw_url)
            else:
                from .microbit_utils import parse_microbit_hex
                content, _, error = parse_microbit_hex(file_obj.file.path, raw_file_url=raw_url)
        except Exception:
            error = 'Не вдалося відкрити матеріал. Завантажте оригінальний файл.'
        return render(request, 'feed/material_embedded.html', {
            'material': file_obj, 'content': content, 'error': error,
            'theme': 'dark' if request.GET.get('theme') == 'dark' else 'light',
        })

    # The reading mode is independent of PDF/slide preparation and keeps the
    # same assignment access checks as the graphical preview.
    reading_converters = {
        '.docx': convert_docx_to_html, '.doc': convert_docx_to_html,
        '.xlsx': convert_xlsx_to_html, '.xls': convert_xlsx_to_html,
        '.pptx': convert_pptx_to_html, '.ppt': convert_pptx_to_html,
        '.odt': convert_odt_to_html, '.ods': convert_ods_to_html,
        '.odp': convert_odp_to_html,
    }
    if request.GET.get('mode') == 'text' and ext in reading_converters:
        try:
            content, error = reading_converters[ext](file_obj.file.path, reading_mode=True)
            if content:
                from .document_html import safe_document_html
                return JsonResponse({'type': 'html', 'content': safe_document_html(content)})
            return JsonResponse({'type': 'error', 'message': error or 'Текстовий вміст відсутній.'})
        except Exception:
            return JsonResponse({'type': 'error', 'message': 'Не вдалося підготувати текстовий вигляд. Завантажте оригінальний файл.'})

    # Для презентацій: спочатку перевіряємо наявність слайдів (JPEG), потім PDF
    if ext in {'.pptx', '.ppt', '.odp'}:
        slide_urls, pdf_url = get_presentation_slides(file_obj.id, file_obj.file.path if file_obj.file else None, wait_if_missing=False)
        if slide_urls:
            return JsonResponse({
                'type': 'slides',
                'slides': slide_urls,
                'count': len(slide_urls),
                'pdf_url': pdf_url
            })
        # Слайди ще не готові — перевіряємо PDF як fallback
        pdf_url_direct = get_pdf_preview_url(file_obj, wait_if_missing=False)
        if pdf_url_direct:
            return JsonResponse({
                'type': 'url',
                'url': request.build_absolute_uri(pdf_url_direct),
                'file_type': 'pdf'
            })
        # Нічого не готово ще — повертаємо порожню відповідь щоб polling продовжувався
        return JsonResponse({'type': 'pending'})

    # Для Word/Excel — спочатку пробуємо PDF через LibreOffice
    if ext in {'.docx', '.doc', '.xlsx', '.xls', '.odt', '.ods'}:
        pdf_url = get_pdf_preview_url(file_obj)
        if pdf_url:
            return JsonResponse({
                'type': 'url',
                'url': request.build_absolute_uri(pdf_url),
                'file_type': 'pdf'
            })

    
    # Резервна обробка (fallback), якщо LibreOffice не зміг згенерувати PDF
    if ext == '.docx':
        try:
            import mammoth
            with open(file_obj.file.path, 'rb') as docx_file:
                result = mammoth.convert_to_html(docx_file)
                from .document_html import safe_document_html
                html = safe_document_html(result.value)
                styled_html = f"<div class='docx-preview-content' style='text-align:left; width:100%; color:var(--color-text-primary); line-height:1.6;'>{html}</div>"
                return JsonResponse({
                    'type': 'html',
                    'content': styled_html
                })
        except Exception as e:
            return JsonResponse({
                'type': 'error',
                'message': f'Помилка конвертації файлу Word: {str(e)}'
            })

    elif ext in ['.xlsx', '.xls', '.doc', '.odt', '.ods']:
        try:
            html_content, err_msg = reading_converters[ext](file_obj.file.path)
            if html_content:
                return JsonResponse({
                    'type': 'html',
                    'content': html_content
                })
            return JsonResponse({
                'type': 'error',
                'message': err_msg or 'Не вдалося підготувати перегляд документа.'
            })
        except Exception as e:
            return JsonResponse({
                'type': 'error',
                'message': 'Не вдалося підготувати перегляд документа. Завантажте оригінальний файл.'
            })

    # Примітка: .pptx, .ppt, .odp вже оброблені на початку функції (ранній return)

    # 6. Обробка текстових файлів та код-файлів (включаючи .py, .js, .css, .json, .sh тощо)
    elif file_obj.get_file_type() == 'text' or ext in {'.py', '.js', '.css', '.json', '.sh', '.cpp', '.h', '.c', '.java', '.pas', '.sql', '.html', '.htm', '.xml', '.ts', '.php', '.md', '.txt', '.log', '.csv', '.cs', '.rb', '.go', '.rs', '.kt', '.swift'}:
        try:
            import os
            if os.path.exists(file_obj.file.path):
                encs = ['utf-8-sig', 'utf-8', 'cp1251', 'windows-1251', 'cp866', 'iso-8859-5']
                content = None
                for enc in encs:
                    try:
                        with open(file_obj.file.path, 'r', encoding=enc) as f:
                            content = f.read(1024 * 1024)
                            break
                    except Exception:
                        continue
                if content is None:
                    with open(file_obj.file.path, 'r', encoding='utf-8', errors='replace') as f:
                        content = f.read(1024 * 1024)

                if len(content) >= 1024 * 1024:
                    content += '\n\n[Показано початок файлу. Завантажте файл для повного перегляду.]'
                lang = ext[1:].lower() if ext.startswith('.') else ext.lower()
                if ext == '.py':
                    lang = 'python'
                elif ext == '.js':
                    lang = 'javascript'
                elif ext in ['.html', '.htm', '.xml']:
                    lang = 'markup'
                elif ext in ['.cpp', '.c', '.h', '.java', '.cs', '.pas']:
                    lang = 'clike'
                elif ext == '.css':
                    lang = 'css'
                elif ext == '.json':
                    lang = 'json'

                is_code = ext in {'.py', '.js', '.css', '.json', '.sh', '.cpp', '.h', '.c', '.java', '.pas', '.sql', '.html', '.htm', '.xml', '.ts', '.php', '.cs', '.rb', '.go', '.rs', '.kt', '.swift'}

                return JsonResponse({
                    'type': 'code' if is_code else 'text',
                    'content': content,
                    'lang': lang,
                    'file_name': file_obj.original_name,
                    'extension': ext
                })
        except Exception as e:
            return JsonResponse({
                'type': 'error',
                'message': f'Не вдалося прочитати файл: {str(e)}'
            })
            
    elif ext in {'.zip', '.rar', '.7z', '.tar', '.gz', '.tgz'}:
        items, error = get_archive_content(file_obj.file.path, ext)
        if error:
            return JsonResponse({'type': 'error', 'message': error})
        return JsonResponse({'type': 'archive', 'items': items})

    # 7. Дефолтна обробка для інших типів (зображення, pdf, відео, аудіо) -> перенаправляємо на inline-view
    inline_view_url = reverse('file_view', args=[file_obj.id])
    return JsonResponse({
        'type': 'url',
        'url': inline_view_url,
        'file_type': file_obj.get_file_type()
    })


def server_stats(request):
    """
    API ендпоінт для PyQt6 лаунчера та моніторингу:
    Повертає статистику сервера та кількість підключених онлайн-клієнтів.
    """
    from .middleware import get_online_stats
    stats = get_online_stats()
    stats['status'] = 'running'
    stats['total_assignments'] = Assignment.objects.filter(status=Assignment.STATUS_PUBLISHED).count()
    return JsonResponse(stats)


from django.views.decorators.csrf import csrf_exempt


def client_heartbeat(request):
    """
    Періодичний heartbeat від браузера на всіх сторінках сайту.
    Оновлює активність та поточну сторінку клієнта.
    """
    import time
    from datetime import datetime
    from .middleware import get_client_ip, _active_clients, _lock
    
    ip = get_client_ip(request)
    current_path = request.GET.get('path', '/')
    now = time.time()
    with _lock:
        _active_clients[ip] = {
            'timestamp': now,
            'last_path': current_path,
            'last_time_str': timezone.localtime(timezone.now()).strftime('%H:%M:%S')
        }
    return HttpResponse("OK")


@csrf_exempt
def client_disconnect(request):
    """
    Викликається браузером через navigator.sendBeacon при закритті вкладки/сайту,
    щоб миттєво відняти клієнта з лічильника онлайн.
    """
    from .middleware import get_client_ip, remove_client_ip
    ip = get_client_ip(request)
    remove_client_ip(ip)
    return HttpResponse("OK")





# ═══════════════════════════════════════════════════════════════════════════════
# ЗДАЧА РОБОТИ УЧНЕМ
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# ЗДАЧА РОБОТИ УЧНЕМ ТА ПУБЛІЧНИЙ ПЕРЕГЛЯД
# ═══════════════════════════════════════════════════════════════════════════════

def _submission_form_context(assignment, form):
    selected_class = str(form['class_group'].value() or '')
    selected_class_name = next(
        (str(group) for group in form.fields['class_group'].queryset if str(group.pk) == selected_class),
        'Клас не обрано',
    )
    if selected_class_name == 'Клас не обрано':
        # Keep the rendered select consistent with the summary after an invalid choice.
        form.fields['class_group'].empty_label = '— Оберіть клас —'
    return {
        'assignment': assignment,
        'form': form,
        'selected_submission_class_name': selected_class_name,
        'selected_submission_class_id': selected_class,
    }


def submit_assignment(request, pk):
    """
    Публічна сторінка для здачі роботи учнем.
    Відображає завдання та форму здачі.
    """
    assignment = Assignment.objects.select_related('teacher', 'subject').prefetch_related('classes', 'files').filter(pk=pk).first()

    if not assignment:
        return render(request, 'feed/assignment_not_found.html', {
            'message': 'Дане завдання було вилучено або не існує.'
        }, status=404)

    if assignment.is_archived or assignment.status == Assignment.STATUS_ARCHIVED:
        messages.warning(request, "🔒 Прийом робіт до цього завдання закрито, оскільки воно перебуває в архіві.")
        return redirect('assignment_detail', pk=assignment.pk)

    if assignment.status != Assignment.STATUS_PUBLISHED:
        return render(request, 'feed/assignment_not_found.html', {
            'message': 'Дане завдання ще не опубліковане або недоступне для здачі.'
        }, status=404)

    if assignment.no_submission_required:
        messages.info(request, "Це завдання не вимагає здачі робіт на сайті (призначене для усного або самостійного опрацювання).")
        return redirect('assignment_detail', pk=assignment.pk)

    initial_data = {}
    if assignment.is_individual and assignment.student_name:
        initial_data['full_name'] = assignment.student_name

    class_param = request.GET.get('class')
    if class_param:
        try:
            available_classes = teaching_classes(assignment.classes.all()) if assignment.classes.exists() else teaching_classes(ClassGroup.objects.all())
            initial_data['class_group'] = available_classes.get(id=class_param)
        except (ClassGroup.DoesNotExist, ValueError):
            pass
    elif assignment.classes.exists():
        initial_data['class_group'] = assignment.classes.all().order_by('grade', 'letter', 'name').first()

    form = bind_submission_form(request, SubmissionForm(assignment=assignment, initial=initial_data))

    if request.method == 'POST':
        form = bind_submission_form(request, SubmissionForm(request.POST, request.FILES, assignment=assignment))
        if form.is_valid():
            if form.cleaned_data.get('other_student'):
                from .outside_students import browser_identity
                form.outside_student_id = browser_identity(request, assignment.teacher_id, form.cleaned_data['full_name'])
            try:
                submission = form.save(assignment=assignment)
            except ValidationError as exc:
                form.add_error(None, exc)
                return render(request, 'feed/submit_assignment.html', _submission_form_context(assignment, form))
            except (PermissionError, OSError, IOError):
                form.add_error(
                    None,
                    "Помилка при читанні або збереженні файлу (файл заблокований іншою програмою або системою). "
                    "Будь ласка, збережіть та закрийте програму (наприклад, Word або Excel), де відкрито цей файл, та спробуйте ще раз."
                )
                return render(request, 'feed/submit_assignment.html', _submission_form_context(assignment, form))

            dup_info = scope_duplicate_info(request, check_submission_duplicates(submission))
            if dup_info['is_duplicate']:
                request.session['submission_duplicate_warning'] = dup_info['warning_message']
                request.session['submission_duplicate_type'] = dup_info['type']

            # Зберігаємо ID останньої здачі для кнопки самоперевірки учня (ШІ)
            request.session['last_submission_id'] = submission.id
            from .ai_preparation import queue_after_commit
            queue_after_commit('submission', submission.pk)
            # Зберігаємо ID здачі в сесії поточного користувача, щоб не надсилати сповіщення автору роботи
            my_subs = request.session.get('my_submission_ids', [])
            if submission.id not in my_subs:
                my_subs.append(submission.id)
                request.session['my_submission_ids'] = my_subs[-100:]

            log_submission_activity(
                None,
                'submission',
                f"Учень {submission.last_name} {submission.first_name} ({submission.class_group}) здав роботу: «{assignment.title}»",
                submission=submission
            )
            return redirect('submit_success', pk=assignment.pk)


    return render(request, 'feed/submit_assignment.html', _submission_form_context(assignment, form))



def submit_success(request, pk):
    """Сторінка підтвердження успішної здачі роботи."""
    assignment = get_object_or_404(Assignment, pk=pk, status__in=[Assignment.STATUS_PUBLISHED, Assignment.STATUS_ARCHIVED])
    # Відображаємо тільки актуальні (останні) здачі учнів без дублювання записів та співавторів
    submissions = scope_submissions(request, Submission.objects.filter(assignment=assignment, is_latest_attempt=True, primary_submission__isnull=True)).order_by('-submitted_at').select_related('class_group')
    
    search_query = request.GET.get('search', '').strip()
    if search_query:
        submissions = fuzzy_search_submissions(submissions, search_query)
        
    paginator = Paginator(submissions, 10)
    page_obj = paginator.get_page(request.GET.get('page'))

    duplicate_warning = request.session.pop('submission_duplicate_warning', None)
    duplicate_type = request.session.pop('submission_duplicate_type', None)

    # Визначаємо останню здачу для кнопки самоперевірки учня
    scoped_submissions = scope_submissions(request, Submission.objects.filter(assignment=assignment))
    latest_submission_id = request.session.get('last_submission_id', None)
    latest_submission = None
    can_student_ai_check = False
    ai_check_already_used = False

    if not latest_submission_id and request.user.is_authenticated and hasattr(request.user, 'student_profile'):
        sub = scoped_submissions.filter(student=request.user.student_profile, is_latest_attempt=True).order_by('-submitted_at').first()
        if sub:
            latest_submission_id = sub.id

    if not latest_submission_id:
        recent_sub = scoped_submissions.filter(is_latest_attempt=True).order_by('-submitted_at').first()
        if recent_sub and (timezone.now() - recent_sub.submitted_at).total_seconds() < 600:
            latest_submission_id = recent_sub.id

    dup_info = None
    if latest_submission_id:
        try:
            latest_submission = scoped_submissions.get(pk=latest_submission_id)
            if latest_submission.has_used_student_ai_check_for_assignment():
                can_student_ai_check = False
                ai_check_already_used = True
            elif assignment.allow_student_ai_check:
                can_student_ai_check = True

            dup_info = scope_duplicate_info(request, check_submission_duplicates(latest_submission))
            if dup_info and dup_info.get('is_duplicate') and not duplicate_warning:
                duplicate_warning = dup_info.get('warning_message')
                duplicate_type = dup_info.get('type')
        except Submission.DoesNotExist:
            pass
    
    return render(request, 'feed/submit_success.html', {
        'assignment': assignment,
        'page_obj': page_obj,
        'search_query': search_query,
        'duplicate_warning': duplicate_warning,
        'duplicate_type': duplicate_type,
        'dup_info': dup_info,
        'latest_submission': latest_submission,
        'can_student_ai_check': can_student_ai_check,
        'ai_check_already_used': ai_check_already_used,
    })


# ═══════════════════════════════════════════════════════════════════════════════
# САМОПЕРЕВІРКА УЧНЕМ (Student AI Self-Check — одноразова перевірка ШІ)
# ═══════════════════════════════════════════════════════════════════════════════

@require_POST
def student_ai_self_check(request, submission_id):
    """Public self-check: reserve one successful result across all attempts."""
    from .ai_jobs import enqueue_submission_job, job_response, SelfCheckUnavailable
    submission = get_object_or_404(Submission.objects.select_related('assignment', 'class_group'), pk=submission_id)
    if not submission.assignment or not submission.assignment.allow_student_ai_check:
        return JsonResponse({'error': 'Самоперевірка не дозволена для цього завдання'}, status=403)
    try:
        job = enqueue_submission_job(submission, 'student_check')
    except SelfCheckUnavailable as exc:
        return JsonResponse({'error': str(exc)}, status=exc.http_status)
    return job_response(job, request=request)


def _evaluate_student_submission(submission):
    assignment = submission.assignment
    from .gemini_service import evaluate_submission_with_gemini
    from .models import AISettings, AICriteriaPreset
    ai_settings = AISettings.objects.first()

    # Визначаємо preset та ГР завдання
    preset, selected_gr_codes = assignment.get_ai_policy(submission.class_group)

    return evaluate_submission_with_gemini(
        submission,
        ai_settings=ai_settings,
        criteria_preset=preset,
        selected_gr_codes=selected_gr_codes or [],
    )


def _perform_student_ai_check(submission, result):
    assignment = submission.assignment
    if not result or result.get('status') not in ('success', 'ok'):
        message = result.get('error') if result and result.get('privacy_blocked') else None
        return JsonResponse({'error': message or 'ШІ не зміг завершити перевірку. Спробуйте ще раз; спробу не використано.'}, status=503)

    # Зберігаємо чернову оцінку
    import json as _json
    preset, _ = assignment.get_ai_policy(submission.class_group)
    is_traditional = bool(result.get('is_traditional') or (preset and preset.evaluation_type == 'traditional'))
    gr_results = [] if is_traditional else result.get('gr_results', [])
    unclear_task = bool(result.get('unclear_task'))
    format_warning = result.get('format_warning', '')

    submission.student_ai_checked = True
    submission.student_ai_checked_at = timezone.now()
    submission.student_ai_grade = str(result.get('suggested_grade', ''))
    submission.student_ai_level = result.get('level', '')
    summary_text = result.get('summary', '')
    if unclear_task and not summary_text:
        summary_text = "Не зрозуміло, яке завдання виконане. Будь ласка, вкажіть номер завдання у коментарі до здачі."
    submission.student_ai_summary = summary_text
    strengths = result.get('strengths') or []
    weaknesses = result.get('weaknesses') or []

    from .ai_student_feedback import compact_student_feedback, student_feedback_parts, get_student_feedback_sections
    clean_fb = compact_student_feedback(result=result)
    submission.student_ai_feedback = clean_fb
    submission.student_ai_gr_results = _json.dumps(gr_results, ensure_ascii=False) if (gr_results and not is_traditional) else ''

    if 'ai_generated_detected' in result:
        submission.ai_generated_detected = bool(result.get('ai_generated_detected'))
    if 'ai_generated_percent' in result:
        submission.ai_generated_percent = result.get('ai_generated_percent')
    if 'ai_generated_confidence' in result:
        submission.ai_generated_confidence = result.get('ai_generated_confidence') or 'none'
    if 'ai_generated_details' in result:
        submission.ai_generated_details = result.get('ai_generated_details') or ''

    teacher_fb = result.get('feedback') or result.get('feedback_comment') or clean_fb
    submission.ai_suggested_grade = submission.student_ai_grade
    submission.ai_score_level = submission.student_ai_level
    submission.ai_feedback = teacher_fb
    submission.ai_gr_results = submission.student_ai_gr_results
    submission.ai_status = 'success'
    submission.ai_error_reason = ''
    submission.ai_reviewed_at = submission.student_ai_checked_at
    submission.ai_model_used = result.get('model_used') or 'Google Gemini AI'
    metadata = result.get('request_metadata') or {}
    submission.ai_provider_used = metadata.get('provider') or ''
    submission.ai_request_model = metadata.get('model') or ''
    submission.ai_prompt_tokens = metadata.get('prompt_tokens')
    submission.ai_completion_tokens = metadata.get('completion_tokens')
    submission.ai_total_tokens = metadata.get('total_tokens')

    submission.save(update_fields=[
        'student_ai_checked', 'student_ai_checked_at',
        'student_ai_grade', 'student_ai_level', 'student_ai_summary',
        'student_ai_feedback', 'student_ai_gr_results',
        'ai_generated_detected', 'ai_generated_percent',
        'ai_generated_confidence', 'ai_generated_details',
        'ai_suggested_grade', 'ai_score_level', 'ai_feedback', 'ai_gr_results',
        'ai_status', 'ai_error_reason', 'ai_reviewed_at', 'ai_model_used',
        'ai_provider_used', 'ai_request_model', 'ai_prompt_tokens', 'ai_completion_tokens', 'ai_total_tokens'
    ])

    # Детектор дублікатів та плагіату для учня
    dup_info = check_submission_duplicates(submission)

    # Якщо це колективна робота — синхронізуємо оцінку та аналіз ШІ для всіх зв'язаних співавторів
    if submission.is_group_work:
        from django.db.models import Q
        root_pk = submission.primary_submission_id or submission.pk
        Submission.objects.filter(
            Q(primary_submission_id=root_pk) | Q(pk=root_pk)
        ).exclude(pk=submission.pk).update(
            student_ai_checked=True,
            student_ai_checked_at=submission.student_ai_checked_at,
            student_ai_grade=submission.student_ai_grade,
            student_ai_level=submission.student_ai_level,
            student_ai_summary=submission.student_ai_summary,
            student_ai_feedback=submission.student_ai_feedback,
            student_ai_gr_results=submission.student_ai_gr_results,
            ai_generated_detected=submission.ai_generated_detected,
            ai_generated_percent=submission.ai_generated_percent,
            ai_generated_confidence=submission.ai_generated_confidence,
            ai_generated_details=submission.ai_generated_details,
            ai_suggested_grade=submission.ai_suggested_grade,
            ai_score_level=submission.ai_score_level,
            ai_feedback=submission.ai_feedback,
            ai_gr_results=submission.ai_gr_results,
            ai_status='success',
            ai_error_reason='',
            ai_reviewed_at=submission.ai_reviewed_at,
            ai_model_used=submission.ai_model_used,
            ai_provider_used=submission.ai_provider_used, ai_request_model=submission.ai_request_model,
            ai_prompt_tokens=submission.ai_prompt_tokens, ai_completion_tokens=submission.ai_completion_tokens,
            ai_total_tokens=submission.ai_total_tokens,
        )

    # Готуємо відповідь для учня (без технічних полів)
    student_gr_view = []
    if not is_traditional:
        for gr in gr_results:
            student_gr_view.append({
                'code': gr.get('code', ''),
                'name': gr.get('name', ''),
                'grade': gr.get('grade', ''),
                'comment': gr.get('comment', ''),
            })

    public_parts = student_feedback_parts(result=result)
    strengths = public_parts['strengths']
    weaknesses = public_parts['weaknesses']
    feedback_text = clean_fb
    sections = get_student_feedback_sections(
        result=result,
        grade=submission.student_ai_grade,
        level=submission.student_ai_level
    )

    return JsonResponse({
        'ok': True,
        'grade': submission.student_ai_grade,
        'level': submission.student_ai_level,
        'grade_group': submission.get_ai_grade_group_info(),
        'summary': public_parts['summary'],
        'feedback': feedback_text,
        'sections': sections,
        'praise': sections['praise'],
        'grade_reason': sections['grade_reason'],
        'recommendation': sections['recommendation'],
        'improvement': sections['improvement'],
        'revision_advice': weaknesses,
        'strengths': strengths,
        'weaknesses': weaknesses,
        'unclear_task': unclear_task,
        'format_warning': format_warning,
        'is_traditional': is_traditional,
        'gr_results': [],
        'ai_generated_detected': bool(result.get('ai_generated_detected', submission.ai_generated_detected)),
        'ai_generated_percent': None,
        'ai_generated_confidence': submission.ai_generated_confidence,
        'ai_generated_details': submission.ai_generated_details,
        'allow_ai_usage': bool(assignment.allow_ai_usage),
        'duplicate_info': {
            'is_duplicate': bool(dup_info.get('is_duplicate')),
            'type': dup_info.get('type', 'none'),
            'warning_message': dup_info.get('warning_message', ''),
            'teacher_file_name': dup_info.get('teacher_file_name', ''),
            'duplicate_student_name': dup_info.get('duplicate_student_name', ''),
            'duplicate_class': dup_info.get('duplicate_class', ''),
        },
    })


@teacher_required
@transaction.atomic
def accept_student_ai_grade(request, sub_id):
    """
    Вчитель приймає чернову оцінку, виставлену ШІ за самоперевіркою учня.
    POST-запит (AJAX) → повертає JSON ok=True.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Метод не підтримується'}, status=405)

    submission = get_object_or_404(Submission, id=sub_id)
    teacher = request.user.teacher_profile
    if not (request.user.is_superuser or submission.teacher == teacher or
            (submission.assignment and submission.assignment.teacher == teacher)):
        return JsonResponse({'error': 'Немає доступу'}, status=403)

    if not submission.student_ai_checked or not submission.student_ai_grade:
        return JsonResponse({'error': 'Чернова оцінка відсутня'}, status=400)

    # Копіюємо чернову оцінку учня до основних полів
    try:
        submission.grade = validate_grade(submission.student_ai_grade)
    except ValidationError as exc:
        return JsonResponse({'error': exc.messages[0]}, status=400)
    submission.teacher_comment = submission.student_ai_feedback
    submission.ai_suggested_grade = submission.student_ai_grade
    submission.ai_score_level = submission.student_ai_level
    submission.ai_feedback = submission.student_ai_feedback
    submission.ai_gr_results = submission.student_ai_gr_results
    submission.ai_status = 'success'
    submission.graded_by = request.user
    submission.graded_at = timezone.now()
    submission.student_ai_accepted = True
    submission.save(update_fields=[
        'grade', 'teacher_comment',
        'ai_suggested_grade', 'ai_score_level', 'ai_feedback',
        'ai_gr_results', 'ai_status',
        'graded_by', 'graded_at', 'student_ai_accepted',
    ])

    # Синхронізуємо оцінку зі співавторами колективної роботи
    coauthors_graded = sync_grades_to_coauthors(submission, submission.grade, request.user)

    log_msg = f"Вчитель прийняв оцінку учнівської самоперевірки ШІ: «{submission.assignment.title if submission.assignment else ''}» — {submission.grade}"
    if coauthors_graded:
        log_msg += f" (також виставлено оцінку співавторам: {', '.join(coauthors_graded)})"

    log_submission_activity(
        request.user,
        'grade',
        log_msg,
        submission=submission
    )

    return JsonResponse({'ok': True, 'grade': submission.grade, 'coauthors_graded': coauthors_graded})




def submission_detail(request, submission_id):
    """
    Публічний або учнівський перегляд статусу здачі роботи (з історією коментарів вчителя).
    """
    submission = get_object_or_404(
        Submission.objects.select_related('assignment', 'class_group', 'teacher'),
        id=submission_id
    )
    comments = submission.comments.all().select_related('author').order_by('created_at')

    can_student_ai_check = False
    ai_check_already_used = False
    if submission.assignment and submission.assignment.allow_student_ai_check and not submission.grade:
        if submission.has_used_student_ai_check_for_assignment():
            ai_check_already_used = True
        else:
            can_student_ai_check = True

    dup_info = scope_duplicate_info(request, check_submission_duplicates(submission))

    is_teacher = request.user.is_authenticated and can_manage_submission(request, submission)

    return render(request, 'feed/submission_detail.html', {
        'submission': submission,
        'comments': comments,
        'can_student_ai_check': can_student_ai_check,
        'ai_check_already_used': ai_check_already_used,
        'dup_info': dup_info,
        'is_teacher': is_teacher,
    })


# ═══════════════════════════════════════════════════════════════════════════════
# ПЕРЕГЛЯД ТА ОЦІНЮВАННЯ РОБІТ (ФЛАГМАНСЬКИЙ FILE VIEWER)
# ═══════════════════════════════════════════════════════════════════════════════

@teacher_required
@transaction.atomic
def view_file(request, submission_id):
    """
    Головний двоколонковий інтерактивний переглядач робіт:
    - Повний рендеринг будь-яких файлів (Word, Excel з рядком fx, PPTX, PDF, Code, Архіви, YouTube/Google Docs)
    - Швидка навігація («Попередня» / «Наступна») для потокової перевірки
    - Бокова панель оцінювання та діалогу з учнем через AJAX
    """
    submission = get_object_or_404(
        Submission.objects.select_related('assignment', 'class_group', 'teacher', 'assignment__teacher', 'assignment__subject').prefetch_related('assignment__classes', 'assignment__files', 'assignment__additional_links', 'assignment__youtube_links'),
        id=submission_id
    )

    teacher = request.user.teacher_profile
    from django.conf import settings
    review_async = settings.REVIEW_ASYNC and request.GET.get('review_sync') != '1'

    # Перевірка прав доступу
    if not (request.user.is_superuser or (submission.teacher == teacher) or (submission.assignment and submission.assignment.teacher == teacher)):
        messages.error(request, "У вас немає доступу до цієї роботи.")
        return redirect('teacher_dashboard')

    # Обробка AJAX/POST запитів (оцінювання та коментарі)
    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'comment':
            comment_text = request.POST.get('comment', '').strip()
            if comment_text:
                comment = SubmissionComment.objects.create(
                    submission=submission,
                    author=request.user,
                    text=comment_text
                )
                log_submission_activity(
                    request.user,
                    'comment',
                    f"Вчитель {teacher.full_name} додав коментар до роботи {submission.get_student_full_name()}",
                    submission=submission
                )

                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({
                        'status': 'success',
                        'comment': {
                            'id': comment.id,
                            'text': comment.text,
                            'author': comment.get_author_name(),
                            'created_at': timezone.localtime(comment.created_at).strftime("%d.%m.%Y %H:%M")
                        }
                    })
                messages.success(request, 'Коментар додано!')
                redirect_url = reverse('view_file', kwargs={'submission_id': submission_id})
                if request.GET:
                    redirect_url = f"{redirect_url}?{request.GET.urlencode()}"
                return redirect(redirect_url)

        elif action == 'grade':
            grade = request.POST.get('grade', '').strip()
            group_members = submission.get_all_group_submissions() if (submission.is_group_work or submission.primary_submission_id or submission.coauthor_submissions.exists()) else [submission]
            graded_members = []
            try:
                validated_grades = member_grades(request.POST, group_members, grade)
            except ValidationError as exc:
                return JsonResponse({'status': 'error', 'message': exc.messages[0]}, status=400)

            for m in group_members:
                m_grade = validated_grades[m.id]
                if not m_grade and grade:
                    m_grade = grade

                m.grade = m_grade or None
                m.graded_by = request.user
                if m_grade:
                    m.graded_at = timezone.now()
                    graded_members.append(f"{m.get_student_full_name()} ({m_grade})")

                update_f = ['grade', 'graded_by']
                if m_grade:
                    update_f.append('graded_at')
                if submission.teacher_comment and m.id != submission.id:
                    m.teacher_comment = submission.teacher_comment
                    update_f.append('teacher_comment')
                m.save(update_fields=update_f)

            submission.refresh_from_db()

            coauthors_graded = [
                m.get_student_full_name() for m in group_members if m.id != submission.id and m.grade
            ]

            # Фолбек для синхронізації якщо є нестворені зв'язані роботи
            if grade and len(group_members) <= 1:
                synced = sync_grades_to_coauthors(submission, grade, request.user)
                for c_name in synced:
                    if c_name not in coauthors_graded:
                        coauthors_graded.append(c_name)
                for c_name in coauthors_graded:
                    if not any(c_name in gm for gm in graded_members):
                        graded_members.append(f"{c_name} ({grade})")

            log_msg = f"Вчитель {teacher.full_name} оцінив роботу: {', '.join(graded_members) if graded_members else (grade or 'знято')}"
            log_submission_activity(
                request.user,
                'grading',
                log_msg,
                submission=submission
            )

            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'success',
                    'grade': submission.grade or grade,
                    'graded_members': graded_members,
                    'coauthors_graded': coauthors_graded,
                })

            succ_msg = f"Оцінку успішно збережено: {', '.join(graded_members)}!" if graded_members else f"Оцінку {grade} успішно збережено!"
            messages.success(request, succ_msg)
            redirect_url = reverse('view_file', kwargs={'submission_id': submission_id})
            if request.GET:
                redirect_url = f"{redirect_url}?{request.GET.urlencode()}"
            return redirect(redirect_url)

    # ── Логіка черги та навігації (Попередня / Наступна робота) ───────────────
    # Зчитуємо фільтри: клас, завдання, статус оцінювання, дата, пошук, режим, сортування
    class_filter = request.GET.get('class')
    explicit_assignment_param = request.GET.get('assignment')
    date_filter = request.GET.get('date', '').strip()
    grade_filter = request.GET.get('grade_filter', 'all')
    search_query = request.GET.get('search', '').strip()
    show_mode = request.GET.get('mode')
    sort_by = request.GET.get('sort', 'date')
    sort_order = request.GET.get('order', 'desc')

    selected_class_id = None
    if class_filter:
        try:
            selected_class_id = int(class_filter)
        except (ValueError, TypeError):
            selected_class_id = None

    assignment_id = None
    if explicit_assignment_param:
        try:
            assignment_id = int(explicit_assignment_param)
        except (ValueError, TypeError):
            assignment_id = None

    # Базовий queryset робіт вчителя
    if request.user.is_superuser:
        nav_qs = Submission.objects.all()
    else:
        nav_qs = Submission.objects.filter(
            Q(assignment__teacher=teacher) | Q(teacher=teacher)
        )

    nav_qs = nav_qs.select_related('assignment', 'class_group', 'teacher')

    filter_desc_parts = []

    if selected_class_id:
        nav_qs = nav_qs.filter(class_group_id=selected_class_id)
        cls_obj = ClassGroup.objects.filter(id=selected_class_id).first()
        if cls_obj:
            filter_desc_parts.append(f"Клас {cls_obj.name}")

    if assignment_id:
        nav_qs = nav_qs.filter(assignment_id=assignment_id)
        asgn_obj = Assignment.objects.filter(id=assignment_id).first()
        if asgn_obj and request.GET.get('from') != 'assignment_submissions':
            filter_desc_parts.append(f"«{asgn_obj.title[:25]}»")

    if date_filter:
        try:
            from datetime import datetime as dt
            filter_date = dt.strptime(date_filter, '%Y-%m-%d').date()
            nav_qs = nav_qs.filter(submitted_at__date=filter_date)
            filter_desc_parts.append(f"Дата {filter_date.strftime('%d.%m.%Y')}")
        except (ValueError, TypeError):
            date_filter = ''

    if grade_filter == 'ungraded':
        # Включаємо поточну роботу, щоб виставлення оцінки не викидало вчителя з черги під час перегляду
        nav_qs = nav_qs.filter((Q(is_latest_attempt=True) & (Q(grade__isnull=True) | Q(grade=''))) | Q(id=submission.id))
        filter_desc_parts.append("Без оцінки")
    elif grade_filter == 'graded':
        nav_qs = nav_qs.filter((~Q(grade__isnull=True) & ~Q(grade='')) | Q(id=submission.id))
        filter_desc_parts.append("Оцінені")

    if search_query:
        nav_qs = fuzzy_search_submissions(nav_qs, search_query)
        filter_desc_parts.append(f"«{search_query}»")

    if show_mode == 'grouped':
        nav_qs = nav_qs.filter(Q(is_latest_attempt=True) | Q(id=submission.id))

    # Виключаємо дублювання співавторських робіт у черзі навігації
    nav_qs = nav_qs.filter(Q(primary_submission__isnull=True) | Q(id=submission.id))

    # Сортування
    if sort_by == 'student':
        order = ['-last_name', '-first_name'] if sort_order == 'desc' else ['last_name', 'first_name']
    elif sort_by == 'class':
        order = ['-class_group__name'] if sort_order == 'desc' else ['class_group__name']
    elif sort_by == 'assignment':
        order = ['-assignment__title'] if sort_order == 'desc' else ['assignment__title']
    elif sort_by == 'grade':
        order = ['-grade'] if sort_order == 'desc' else ['grade']
    else:
        order = ['-submitted_at'] if sort_order == 'desc' else ['submitted_at']

    nav_qs = nav_qs.order_by(*order)

    # Визначаємо, чи активна фільтрація вибірки
    is_filtered = bool(selected_class_id or date_filter or (grade_filter and grade_filter != 'all') or search_query or assignment_id or show_mode)

    # Keep the exact filter/order semantics without loading every submission's
    # feedback, AI JSON, assignment descriptions and teacher profile.
    submission_ids = list(nav_qs.values_list('pk', flat=True))
    try:
        current_index = submission_ids.index(submission.id)
        prev_id = submission_ids[current_index - 1] if current_index > 0 else None
        next_id = submission_ids[current_index + 1] if current_index < len(submission_ids) - 1 else None
        neighbors = Submission.objects.select_related('assignment', 'class_group', 'teacher').in_bulk(
            [pk for pk in (prev_id, next_id) if pk is not None])
        prev_submission = neighbors.get(prev_id)
        next_submission = neighbors.get(next_id)
        queue_pos = current_index + 1
    except ValueError:
        prev_submission = None
        next_submission = None
        queue_pos = None

    queue_total = len(submission_ids)
    queue_filter_desc = " • ".join(filter_desc_parts) if filter_desc_parts else ""

    # Параметри для посилань вперед/назад та кнопки повернення
    nav_params = request.GET.copy()
    nav_params.pop('file_id', None)
    nav_query_string = nav_params.urlencode()

    back_from = request.GET.get('from')
    back_params = request.GET.copy()
    back_params.pop('file_id', None)
    back_params.pop('from', None)
    back_querystring = back_params.urlencode()

    if back_from == 'all_submissions' or not submission.assignment:
        back_url = reverse('all_submissions_dashboard')
        back_label = "← До всіх здач"
    elif back_from == 'assignment_submissions' or submission.assignment:
        back_url = reverse('assignment_submissions', args=[submission.assignment.id])
        back_label = "← До здач завдання"
    else:
        back_url = reverse('all_submissions_dashboard')
        back_label = "← До списку здач"

    if back_querystring:
        back_url = f"{back_url}?{back_querystring}"

    # Додатковий фолбек для переходу до робіт/завдань:
    # ТІЛЬКИ якщо НЕ встановлено жодних фільтрів вибірки, шукаємо наступну роботу в загальному потоці
    next_submission_fallback = None
    prev_submission_fallback = None
    prev_assignment = None
    next_assignment = None
    next_assignment_first_sub = None
    prev_assignment_first_sub = None

    if not is_filtered:
        fallback_base = (
            Submission.objects.all() if request.user.is_superuser
            else Submission.objects.filter(Q(assignment__teacher=teacher) | Q(teacher=teacher))
        )
        if not next_submission and submission.submitted_at:
            next_submission_fallback = fallback_base.filter(
                submitted_at__lt=submission.submitted_at
            ).order_by('-submitted_at').select_related('assignment', 'class_group', 'teacher').first()
        if not prev_submission and submission.submitted_at:
            prev_submission_fallback = fallback_base.filter(
                submitted_at__gt=submission.submitted_at
            ).order_by('submitted_at').select_related('assignment', 'class_group', 'teacher').first()

        # Навігація між завданнями (Попереднє / Наступне завдання)
        if submission.assignment and submission.assignment.created_at:
            asgn_base = Assignment.objects.all() if request.user.is_superuser else Assignment.objects.filter(teacher=teacher)
            next_assignment = asgn_base.filter(created_at__lt=submission.assignment.created_at).order_by('-created_at').first()
            if next_assignment:
                next_assignment_first_sub = Submission.objects.filter(assignment=next_assignment).order_by('-submitted_at').first()

            prev_assignment = asgn_base.filter(created_at__gt=submission.assignment.created_at).order_by('created_at').first()
            if prev_assignment:
                prev_assignment_first_sub = Submission.objects.filter(assignment=prev_assignment).order_by('-submitted_at').first()

    # Отримуємо всі прикріплені файли здачі
    submission_files = list(submission.files.all())
    selected_file_obj = None
    file_id_param = request.GET.get('file_id')

    is_link_selected = (file_id_param == 'link' and submission.link)

    if file_id_param and file_id_param != 'link' and submission_files:
        try:
            fid = int(file_id_param)
            for sf in submission_files:
                if sf.id == fid:
                    selected_file_obj = sf
                    break
        except (ValueError, TypeError):
            pass

    if not is_link_selected and not selected_file_obj and submission_files:
        selected_file_obj = submission_files[0]
    elif not selected_file_obj and not is_link_selected and submission.link:
        is_link_selected = True

    # Визначаємо порядковий номер, попередній та наступний файли
    total_items_count = len(submission_files) + (1 if submission.link else 0)
    active_file_num = 1
    prev_file_id = None
    next_file_id = None

    if is_link_selected:
        active_file_id = 'link'
        active_file_num = total_items_count
        if submission_files:
            prev_file_id = submission_files[-1].id
    elif selected_file_obj and submission_files:
        active_file_id = selected_file_obj.id
        try:
            cur_idx = [sf.id for sf in submission_files].index(selected_file_obj.id)
            active_file_num = cur_idx + 1
            if cur_idx > 0:
                prev_file_id = submission_files[cur_idx - 1].id
            if cur_idx < len(submission_files) - 1:
                next_file_id = submission_files[cur_idx + 1].id
            elif submission.link:
                next_file_id = 'link'
        except ValueError:
            pass
    else:
        active_file_id = 'link' if submission.link else None

    all_image_files = [sf for sf in submission_files if sf.get_file_type() == 'image']

    # Визначення типу файлу та контенту
    file_type = 'unknown'
    content = None
    html_content = None
    html_raw_url = None
    archive_content = None
    error_message = None
    file_ext = ''
    embed_info = None

    active_file = None
    preview_pending = False
    if is_link_selected:
        file_name = submission.link
        file_type = 'link'
        embed_info = parse_embed_url(submission.link)
        active_file = None
        selected_file_obj = None
    elif selected_file_obj:
        active_file = selected_file_obj.file
        file_name = selected_file_obj.original_name or os.path.basename(selected_file_obj.file.name)
        file_ext = selected_file_obj.get_extension()
    elif submission.file:
        active_file = submission.file
        file_name = os.path.basename(submission.file.name)
        file_ext = submission.get_file_extension() or ''
    elif submission.link:
        file_name = submission.link
        file_type = 'link'
        embed_info = parse_embed_url(submission.link)
    else:
        file_name = 'Текстова відповідь учня'

    archive_files = ['.zip', '.rar', '.7z', '.tar', '.gz', '.tgz']
    office_preview = ['.docx', '.doc', '.xlsx', '.xls', '.pptx', '.ppt', '.odt', '.ods', '.odp', '.rtf']
    access_files = ['.mdb', '.accdb']
    image_files = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg', '.tiff', '.tif', '.heic']
    video_files = ['.mp4', '.webm', '.ogv', '.mov', '.m4v', '.mkv', '.avi', '.3gp']
    audio_files = ['.mp3', '.wav', '.ogg', '.flac', '.aac']
    scratch_files = ['.sb3']
    microbit_files = ['.hex']
    text_files = [
        '.txt', '.text', '.log', '.csv', '.tsv', '.md', '.markdown', '.rst',
        '.py', '.pyw', '.ipynb', '.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx', '.vue', '.svelte',
        '.html', '.htm', '.css', '.scss', '.sass', '.less', '.json', '.json5', '.sh', '.bash', '.zsh',
        '.cpp', '.c', '.cc', '.cxx', '.h', '.hpp', '.cs', '.java', '.kt', '.scala', '.groovy',
        '.xml', '.sql', '.pas', '.pp', '.dpr', '.php', '.rb', '.go', '.rs', '.swift', '.lua',
        '.ini', '.yaml', '.yml', '.toml', '.cfg', '.conf', '.env', '.tex', '.properties', '.gradle', '.bat', '.cmd', '.ps1'
    ]

    if active_file and hasattr(active_file, 'path') and os.path.exists(active_file.path):
        file_path = active_file.path
        from .gemini_service import is_text_file

        is_text = (file_ext in text_files) or (not file_ext and is_text_file(file_path)) or (
            file_ext not in (archive_files + office_preview + access_files + image_files + video_files + audio_files + scratch_files + microbit_files + ['.pdf']) and is_text_file(file_path)
        )

        if file_ext in ['.html', '.htm']:
            file_type = 'html'
            from django.core import signing
            token = signing.dumps({'submission': submission.pk, 'teacher': teacher.pk}, salt='submission-html-preview')
            asset_name = selected_file_obj.original_name if selected_file_obj else os.path.basename(active_file.name)
            html_raw_url = reverse('submission_html_asset', args=[submission.pk, token, asset_name])

            encodings = ['utf-8-sig', 'utf-8', 'cp1251', 'windows-1251', 'cp866', 'iso-8859-5', 'latin-1']
            read_success = False
            for enc in encodings:
                try:
                    with open(file_path, 'r', encoding=enc) as f:
                        content = f.read(1024 * 1024)
                        read_success = True
                        break
                except (UnicodeDecodeError, UnicodeError):
                    continue
                except Exception as e:
                    content = f"Помилка при читанні файлу: {str(e)}"
                    read_success = True
                    break

            if not read_success:
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                        content = f.read(1024 * 1024)
                except Exception as e:
                    content = f"Помилка відкриття файлу: {str(e)}"

            if content and len(content) >= 1024 * 1024:
                content += "\n\n[Показано початок файлу. Завантажте файл для повного перегляду.]"

        elif is_text:
            file_type = 'code' if file_ext and file_ext not in ['.txt', '.text', '.log'] else 'text'
            encodings = ['utf-8-sig', 'utf-8', 'cp1251', 'windows-1251', 'cp866', 'iso-8859-5', 'latin-1']
            read_success = False
            for enc in encodings:
                try:
                    with open(file_path, 'r', encoding=enc) as f:
                        content = f.read(1024 * 1024)
                        read_success = True
                        break
                except (UnicodeDecodeError, UnicodeError):
                    continue
                except Exception as e:
                    content = f"Помилка при читанні файлу: {str(e)}"
                    read_success = True
                    break
            
            if not read_success:
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                        content = f.read(1024 * 1024)
                except Exception as e:
                    content = f"Помилка відкриття файлу: {str(e)}"

            if content and len(content) >= 1024 * 1024:
                content += "\n\n[Показано початок файлу. Завантажте файл для повного перегляду.]"

        elif file_ext in office_preview:
            file_type = 'office_preview'
            try:
                if review_async:
                    preview_pending = True
                elif file_ext in ['.docx', '.doc']:
                    html_content, error_message = convert_docx_to_html(file_path)
                elif file_ext in ['.xlsx', '.xls']:
                    html_content, error_message = convert_xlsx_to_html(file_path)
                elif file_ext in ['.pptx', '.ppt']:
                    html_content, error_message = convert_pptx_to_html(file_path)
                elif file_ext == '.odt':
                    html_content, error_message = convert_odt_to_html(file_path)
                elif file_ext == '.ods':
                    html_content, error_message = convert_ods_to_html(file_path)
                elif file_ext == '.odp':
                    html_content, error_message = convert_odp_to_html(file_path)
            except Exception as e:
                error_message = f"Помилка конвертації документа: {str(e)}"

        elif file_ext in archive_files:
            file_type = 'archive'
            archive_content, error_message = get_archive_content(file_path, file_ext)

        elif file_ext in access_files:
            file_type = 'access_db'
            try:
                html_content, error_message = convert_access_to_html(file_path)
            except Exception as e:
                error_message = f"Помилка обробки Access бази даних: {str(e)}"

        elif file_ext in scratch_files:
            file_type = 'scratch'
            try:
                from .scratch_utils import parse_scratch_sb3
                raw_url = request.build_absolute_uri(reverse('view_submission_raw_file', args=[submission.id]))
                if selected_file_obj:
                    raw_url += f"?file_id={selected_file_obj.id}"
                html_content, content, error_message = parse_scratch_sb3(file_path, raw_file_url=raw_url)
            except Exception as e:
                error_message = f"Помилка розбору Scratch проєкту: {str(e)}"

        elif file_ext in microbit_files:
            file_type = 'microbit'
            try:
                from .microbit_utils import parse_microbit_hex
                raw_url = request.build_absolute_uri(reverse('view_submission_raw_file', args=[submission.id]))
                if selected_file_obj:
                    raw_url += f"?file_id={selected_file_obj.id}"
                html_content, content, error_message = parse_microbit_hex(file_path, raw_file_url=raw_url)
            except Exception as e:
                error_message = f"Помилка розбору micro:bit файлу: {str(e)}"

        elif file_ext in video_files:
            file_type = 'video'

        elif file_ext in audio_files:
            file_type = 'audio'

        elif file_ext in image_files:
            file_type = 'image'

        elif file_ext in ['.pdf']:
            file_type = 'pdf'

        else:
            file_type = 'office'

    comments = submission.comments.all().select_related('author').order_by('created_at')

    AICriteriaPreset.ensure_default_presets()
    criteria_presets = AICriteriaPreset.objects.all()
    default_preset, default_gr_codes = submission.assignment.get_ai_policy(submission.class_group) if submission.assignment else (None, [])
    default_preset = default_preset or AICriteriaPreset.objects.filter(is_default=True).first() or criteria_presets.first()
    viewer_preset = default_preset
    viewer_gr_codes = default_gr_codes
    viewer_thinking_mode = bool((submission.assignment and submission.assignment.ai_thinking_mode) or AISettings.get_solo().default_thinking_mode)
    from .models import AIJob
    last_check = AIJob.objects.filter(submission=submission, kind='teacher_check', status='succeeded').order_by('-finished_at').first()
    if last_check and default_preset:
        parameters = last_check.parameters or {}
        preset_id = parameters.get('preset_id')
        if preset_id and str(preset_id).isdigit():
            viewer_preset = criteria_presets.filter(pk=preset_id).first() or default_preset
        codes = parameters.get('selected_gr_codes')
        valid_codes = {gr.get('code') for gr in viewer_preset.get_gr_list()}
        if isinstance(codes, list) and codes and all(isinstance(code, str) and code in valid_codes for code in codes):
            viewer_gr_codes = codes
        elif viewer_preset != default_preset:
            viewer_gr_codes = []
        if isinstance(parameters.get('force_thinking'), bool):
            viewer_thinking_mode = parameters['force_thinking']
    last_evaluated_gr_codes = [gr.get('code') for gr in submission.get_ai_gr_results_list() if gr.get('code')]

    duplicates_pending = bool(review_async and submission.file and submission.assignment)
    dup_info = {} if duplicates_pending else check_submission_duplicates(submission)

    group_members = []
    if submission.is_collective_work() or submission.is_group_work or submission.primary_submission_id:
        group_members = submission.get_all_group_submissions()

    sync_params = request.GET.copy()
    sync_params['review_sync'] = '1'
    web_proxy_url = None
    if submission.link:
        web_proxy_url = reverse('view_submission_web_proxy', args=[submission.id])

    prefetch_submission = next_submission or next_submission_fallback or next_assignment_first_sub
    context = {
        'submission': submission,
        'group_members': group_members,
        'submission_files': submission_files,
        'selected_file_obj': selected_file_obj,
        'active_file_id': active_file_id,
        'active_file_num': active_file_num,
        'prev_file_id': prev_file_id,
        'next_file_id': next_file_id,
        'total_files_count': len(submission_files),
        'total_items_count': total_items_count,
        'has_submission_link': bool(submission.link),
        'html_raw_url': html_raw_url,
        'web_proxy_url': web_proxy_url,
        'all_image_files': all_image_files,
        'active_file': active_file,
        'file_name': file_name,
        'file_ext': file_ext,
        'file_type': file_type,
        'content': content,
        'html_content': html_content,
        'archive_content': archive_content,
        'error_message': error_message,
        'embed_info': embed_info,
        'prev_submission': prev_submission,
        'next_submission': next_submission,
        'next_submission_fallback': next_submission_fallback,
        'prev_submission_fallback': prev_submission_fallback,
        'prev_assignment': prev_assignment,
        'next_assignment': next_assignment,
        'next_assignment_first_sub': next_assignment_first_sub,
        'prev_assignment_first_sub': prev_assignment_first_sub,
        'comments': comments,
        'assignment': submission.assignment,
        'assignment_id': assignment_id,
        'teacher': teacher,
        'criteria_presets': criteria_presets,
        'default_preset': default_preset,
        'default_gr_codes': default_gr_codes,
        'viewer_gr_codes': viewer_gr_codes,
        'viewer_preset': viewer_preset,
        'viewer_thinking_mode': viewer_thinking_mode,
        'last_evaluated_gr_codes': last_evaluated_gr_codes,
        'dup_info': dup_info,
        'review_async': review_async,
        'preview_pending': preview_pending,
        'duplicates_pending': duplicates_pending,
        'review_sync_url': reverse('view_file', args=[submission.pk]) + '?' + sync_params.urlencode(),
        'next_preview_url': reverse('review_document_preview', args=[prefetch_submission.pk]) if prefetch_submission else '',
        'is_filtered': is_filtered,
        'queue_pos': queue_pos,
        'queue_total': queue_total,
        'queue_filter_desc': queue_filter_desc,
        'nav_query_string': nav_query_string,
        'back_url': back_url,
        'back_label': back_label,
        'class_students': list(Student.objects.filter(class_group=submission.class_group).order_by('last_name', 'first_name')) if submission.class_group else [],
    }
    return render(request, 'feed/file_viewer.html', context)


def _review_submission(request, submission_id):
    from .permissions import teacher_submissions
    return get_object_or_404(teacher_submissions(request, Submission.objects.select_related(
        'assignment', 'class_group', 'teacher').prefetch_related('assignment__files')), pk=submission_id)


def _review_active_file(request, submission):
    files = list(submission.files.all())
    selected = next((f for f in files if str(f.pk) == request.GET.get('file_id')), None)
    selected = selected or (files[0] if files else None)
    active = selected.file if selected else submission.file
    if not active or not os.path.isfile(active.path):
        raise Http404('Файл не знайдено')
    extension = selected.get_extension() if selected else submission.get_file_extension()
    return active, selected, extension


@teacher_required
def review_document_preview(request, submission_id):
    """Conversion is a separate read-only request, never blocking the review controls."""
    if request.method != 'GET':
        return HttpResponse(status=405)
    from django.template.loader import render_to_string
    from .review_preview import convert_office, ASSET_PATTERN
    from .ai_context import file_cache_key
    submission = _review_submission(request, submission_id)
    active, selected, extension = _review_active_file(request, submission)
    version = file_cache_key(active.path, 'review-assets-v1')
    try:
        content, error = convert_office(active.path, extension)
        # Resolve markers only after access checks; converters remain reusable.
        def asset_url(match):
            url = reverse('review_preview_asset', args=[submission.pk, match[1]])
            url += f'?v={version}'
            if selected:
                url += f'&amp;file_id={selected.pk}'
            return url
        content = ASSET_PATTERN.sub(asset_url, content)
    except Exception:
        logging.getLogger(__name__).exception('Review preview failed for submission %s', submission.pk)
        return JsonResponse({'error': 'Не вдалося підготувати перегляд. Спробуйте ще раз або завантажте файл.'}, status=503)
    response = JsonResponse({'html': render_to_string('feed/components/viewer_office_content.html', {
        'html_content': content, 'error_message': error,
    })})
    response['Cache-Control'] = 'private, no-store'
    return response


@teacher_required
def review_preview_asset(request, submission_id, asset_name):
    if request.method not in ('GET', 'HEAD'):
        return HttpResponse(status=405)
    from .review_preview import asset_directory
    from .ai_context import file_cache_key
    if not re.fullmatch(r'[a-f0-9]{64}\.(png|jpeg|gif|webp|bmp)', asset_name):
        raise Http404('Зображення не знайдено')
    submission = _review_submission(request, submission_id)
    active, selected, extension = _review_active_file(request, submission)
    if request.GET.get('v') != file_cache_key(active.path, 'review-assets-v1'):
        raise Http404('Перегляд файла змінився')
    response = file_response(request, str(asset_directory(active.path) / asset_name),
                             content_type='image/' + asset_name.rsplit('.', 1)[1])
    response['Cache-Control'] = 'private, max-age=604800, immutable'
    response['Vary'] = 'Cookie'
    return response


@teacher_required
def review_duplicates(request, submission_id):
    if request.method != 'GET':
        return HttpResponse(status=405)
    from django.template.loader import render_to_string
    submission = _review_submission(request, submission_id)
    info = check_submission_duplicates(submission)
    context = {'submission': submission, 'dup_info': info,
               'group_members': submission.get_all_group_submissions() if submission.is_collective_work() else []}
    response = JsonResponse({
        'html': render_to_string('feed/components/viewer_duplicate_details.html', context),
        'chip': render_to_string('feed/components/viewer_duplicate_chip.html', context),
        'group_chip': render_to_string('feed/components/viewer_group_chip.html', context),
    })
    response['Cache-Control'] = 'private, no-store'
    return response



@teacher_required
@xframe_options_exempt
def view_submission_raw_file(request, submission_id, sub_path=None):
    """Служить сирий файл здачі учня безпосередньо у браузері."""
    submission = get_object_or_404(Submission, id=submission_id)
    teacher = request.user.teacher_profile

    if not (request.user.is_superuser or (submission.teacher == teacher) or (submission.assignment and submission.assignment.teacher == teacher)):
        return HttpResponse('Немає доступу', status=403)

    return _submission_raw_response(request, submission, sub_path)


def submission_html_asset(request, submission_id, token, sub_path):
    """Read-only, short-lived access for an opaque HTML sandbox without cookies."""
    from django.core import signing
    if request.method not in ('GET', 'HEAD'):
        return HttpResponse(status=405)
    try:
        grant = signing.loads(token, salt='submission-html-preview', max_age=1800)
    except signing.BadSignature:
        raise Http404('Посилання перегляду недійсне або застаріле') from None
    if grant.get('submission') != submission_id:
        raise Http404('Файл не знайдено')
    teacher = get_object_or_404(Teacher.objects.select_related('user'), pk=grant.get('teacher'), user__is_active=True)
    submission = get_object_or_404(Submission, pk=submission_id)
    if not (teacher.user.is_superuser or submission.teacher_id == teacher.pk or
            (submission.assignment and submission.assignment.teacher_id == teacher.pk)):
        raise Http404('Файл не знайдено')
    # Only attached files, never other works sharing the same storage directory.
    response = _submission_raw_response(request, submission, sub_path, allow_directory=False)
    response['Cache-Control'] = 'private, no-store'
    response['Referrer-Policy'] = 'no-referrer'
    return response


def _submission_raw_response(request, submission, sub_path=None, allow_directory=True):
    target_file = None
    file_path = None

    if sub_path:
        sf = submission.files.filter(Q(original_name=sub_path) | Q(original_name__endswith=f"/{sub_path}") | Q(file__endswith=sub_path)).first()
        if sf and sf.file and hasattr(sf.file, 'path') and os.path.exists(sf.file.path):
            target_file = sf.file
            file_path = sf.file.path
        elif allow_directory:
            first_sf = submission.files.first()
            base_ref = first_sf.file if (first_sf and first_sf.file) else submission.file
            if base_ref and hasattr(base_ref, 'path') and os.path.exists(base_ref.path):
                base_dir = Path(base_ref.path).resolve().parent
                candidate = (base_dir / sub_path).resolve()
                if candidate.is_relative_to(base_dir) and candidate.is_file():
                    file_path = str(candidate)
        if not file_path:
            raise Http404('Файл не знайдено')

    if not target_file and not file_path:
        file_id = request.GET.get('file_id')
        if file_id and file_id != 'link':
            try:
                sf = submission.files.filter(id=int(file_id)).first()
                if sf and sf.file:
                    target_file = sf.file
            except (ValueError, TypeError):
                pass

        if not target_file:
            first_sf = submission.files.first()
            if first_sf and first_sf.file:
                target_file = first_sf.file
            elif submission.file:
                target_file = submission.file

        if target_file and hasattr(target_file, 'path'):
            file_path = target_file.path

    if not file_path or not os.path.exists(file_path):
        return HttpResponse('Файл не знайдено', status=404)

    try:
        import mimetypes
        path = file_path
        ext = os.path.splitext(path)[1].lower()
        if ext == '.pdf':
            mime_type = 'application/pdf'
        elif ext in ['.html', '.htm']:
            mime_type = 'text/html; charset=utf-8'
        elif ext == '.css':
            mime_type = 'text/css; charset=utf-8'
        elif ext in ['.js', '.mjs']:
            mime_type = 'application/javascript; charset=utf-8'
        elif ext in ['.jpg', '.jpeg']:
            mime_type = 'image/jpeg'
        elif ext == '.png':
            mime_type = 'image/png'
        elif ext == '.webp':
            mime_type = 'image/webp'
        elif ext == '.svg':
            mime_type = 'image/svg+xml'
        elif ext in ['.mp4', '.m4v']:
            mime_type = 'video/mp4'
        elif ext == '.webm':
            mime_type = 'video/webm'
        elif ext == '.ogv':
            mime_type = 'video/ogg'
        elif ext == '.mov':
            mime_type = 'video/quicktime'
        elif ext == '.mkv':
            mime_type = 'video/x-matroska'
        elif ext == '.avi':
            mime_type = 'video/x-msvideo'
        elif ext == '.3gp':
            mime_type = 'video/3gpp'
        elif ext == '.mp3':
            mime_type = 'audio/mpeg'
        elif ext == '.wav':
            mime_type = 'audio/wav'
        elif ext == '.ogg':
            mime_type = 'audio/ogg'
        elif ext == '.sb3':
            mime_type = 'application/x.scratch.sb3'
        elif ext == '.hex':
            mime_type = 'text/plain; charset=utf-8'
        else:
            mime_type, _ = mimetypes.guess_type(path)
            if not mime_type:
                from .gemini_service import is_text_file
                if is_text_file(path):
                    mime_type = 'text/plain; charset=utf-8'
                else:
                    mime_type = 'application/octet-stream'

        is_inline_request = (request.GET.get('inline') == '1') or (sub_path is not None)
        return file_response(request, path, content_type=mime_type, inline=is_inline_request,
                             interactive_html=is_inline_request and ext in ('.html', '.htm'))
    except Http404:
        raise
    except Exception as e:
        return HttpResponse(f'Помилка завантаження: {str(e)}', status=500)


def _rewrite_html_resources_to_absolute(html_content, base_url):
    """
    Перетворює відносні посилання на ресурси (стилі CSS, скрипти JS, зображення, медіа)
    на абсолютні URL відповідно до оригінального або ефективного base_url сайту.
    Це усуває проблеми завантаження CSS та асетів при роботі всередині iframe проксі.
    """
    import re
    from urllib.parse import urljoin, urlsplit

    # 1. Визначаємо оригінальний base href, якщо він присутній у HTML (наприклад, у OpenCart як compx.ua)
    orig_base_match = re.search(r'<base\s+[^>]*href=(?:([\'"])(.*?)\1|([^\s>]+))', html_content, flags=re.I)
    if orig_base_match:
        effective_base = orig_base_match.group(2) if orig_base_match.group(1) else orig_base_match.group(3)
        effective_base = effective_base.strip()
        if not effective_base.startswith(('http://', 'https://', '//')):
            effective_base = urljoin(base_url, effective_base)
        elif effective_base.startswith('//'):
            scheme = urlsplit(base_url).scheme or 'https'
            effective_base = f"{scheme}:{effective_base}"
    else:
        effective_base = base_url

    # Видаляємо всі існуючі теги <base>, щоб сформувати єдиний чистий <base>
    html_content = re.sub(r'<base\b[^>]*>', '', html_content, flags=re.I)

    def make_abs(rel_url):
        rel = (rel_url or '').strip()
        if not rel or rel.startswith(('data:', 'blob:', 'javascript:', '#', 'mailto:', 'tel:')):
            return rel
        return urljoin(effective_base, rel)

    # 2. Перетворення атрибутів посилань на ресурси:
    # <link ... href="...">
    def rewrite_link(match):
        tag = match.group(0)
        pattern = r'\bhref=(?:([\'"])(.*?)\1|([^\s>]+))'
        def repl(m):
            delim = m.group(1) or '"'
            val = m.group(2) if m.group(1) else m.group(3)
            return f'href={delim}{make_abs(val)}{delim}'
        return re.sub(pattern, repl, tag, flags=re.I)

    html_content = re.sub(r'<link\b[^>]+>', rewrite_link, html_content, flags=re.I)

    # 3. Перетворення тегів з атрибутом src / data-src / poster:
    # <script>, <img>, <source>, <video>, <audio>, <iframe>, <embed>, <input>
    def rewrite_media_tag(match):
        tag = match.group(0)
        for attr in ('src', 'data-src', 'data-original', 'data-lazy-src', 'poster'):
            pattern = rf'\b{attr}=(?:([\'"])(.*?)\1|([^\s>]+))'
            def repl(m, a=attr):
                delim = m.group(1) or '"'
                val = m.group(2) if m.group(1) else m.group(3)
                return f'{a}={delim}{make_abs(val)}{delim}'
            tag = re.sub(pattern, repl, tag, flags=re.I)
        return tag

    html_content = re.sub(r'<(script|img|source|video|audio|iframe|embed|input)\b[^>]+>', rewrite_media_tag, html_content, flags=re.I)

    # 4. Перетворення srcset та data-srcset
    def rewrite_srcset(match):
        attr = match.group(1)
        delim = match.group(2) or '"'
        srcset_val = match.group(3) if match.group(2) else match.group(4)
        parts = srcset_val.split(',')
        new_parts = []
        for p in parts:
            p_strip = p.strip()
            if not p_strip:
                continue
            tokens = p_strip.split(None, 1)
            url_part = tokens[0]
            rest = f' {tokens[1]}' if len(tokens) > 1 else ''
            new_parts.append(f'{make_abs(url_part)}{rest}')
        return f'{attr}={delim}{", ".join(new_parts)}{delim}'

    html_content = re.sub(r'\b(srcset|data-srcset)=(?:([\'"])(.*?)\2|([^\s>]+))', rewrite_srcset, html_content, flags=re.I)

    # 5. Перетворення <a ... href="..."> на абсолютні та target="_blank"
    def rewrite_a_tag(match):
        tag = match.group(0)
        href_match = re.search(r'\bhref=(?:([\'"])(.*?)\1|([^\s>]+))', tag, flags=re.I)
        if href_match:
            delim = href_match.group(1) or '"'
            raw_href = href_match.group(2) if href_match.group(1) else href_match.group(3)
            if raw_href and not raw_href.startswith(('#', 'javascript:')):
                abs_href = make_abs(raw_href)
                tag = re.sub(r'\bhref=(?:([\'"])(.*?)\1|([^\s>]+))', f'href={delim}{abs_href}{delim}', tag, count=1, flags=re.I)
                if not re.search(r'\btarget\s*=', tag, flags=re.I):
                    tag = re.sub(r'^<a\b', '<a target="_blank" rel="noopener noreferrer"', tag, flags=re.I)
        return tag

    html_content = re.sub(r'<a\b[^>]+>', rewrite_a_tag, html_content, flags=re.I)

    # 6. Очищення від мета-тегів блокування вбудовування
    html_content = re.sub(r'<meta[^>]*http-equiv\s*=\s*[\'"]?X-Frame-Options[\'"]?[^>]*>', '', html_content, flags=re.I)
    html_content = re.sub(r'<meta[^>]*http-equiv\s*=\s*[\'"]?Content-Security-Policy[\'"]?[^>]*>', '', html_content, flags=re.I)

    # 7. Вставка єдиного <base href="{effective_base}" target="_blank"> та захисту від frame-busting
    base_tag = f'<base href="{effective_base}" target="_blank">'
    anti_bust_script = '<script>try{Object.defineProperty(window,"top",{get:function(){return window;}});Object.defineProperty(window,"parent",{get:function(){return window;}});}catch(e){}</script>'
    injection = base_tag + anti_bust_script

    if '<head>' in html_content.lower():
        html_content = re.sub(r'(<head[^>]*>)', r'\1' + injection, html_content, count=1, flags=re.I)
    else:
        html_content = injection + html_content

    return html_content


@teacher_required
@xframe_options_sameorigin
def view_submission_web_proxy(request, submission_id):
    """
    Захищений проксі-перегляд зовнішніх вебсайтів (наприклад compx.ua, rozetka тощо),
    які забороняють вбудовування через заголовок X-Frame-Options або CSP frame-ancestors.
    Забезпечує пряме завантаження та комфортний перегляд сайту безпосередньо у вікні перевірки.
    """
    submission = get_object_or_404(Submission, id=submission_id)
    teacher = request.user.teacher_profile

    if not (request.user.is_superuser or (submission.teacher == teacher) or (submission.assignment and submission.assignment.teacher == teacher)):
        return HttpResponse('Немає доступу', status=403)

    raw_url = (request.GET.get('url') or submission.link or '').strip()
    if not raw_url:
        return HttpResponse('Посилання відсутнє у зданій роботі', status=400)

    # Нормалізація протоколу
    if not raw_url.startswith(('http://', 'https://', '//')):
        if raw_url.startswith(('localhost', '127.0.0.1', '192.168.', '10.', '172.')):
            raw_url = 'http://' + raw_url
        else:
            raw_url = 'https://' + raw_url
    elif raw_url.startswith('//'):
        raw_url = 'https:' + raw_url

    # Безпечне кодування для кириличних та специфічних URL
    from urllib.parse import urlsplit, urlunsplit, quote
    import urllib.request
    import ssl
    import gzip
    import zlib
    import re

    try:
        parts = urlsplit(raw_url)
        hostname = parts.hostname
        if hostname:
            try:
                hostname = hostname.encode('idna').decode('ascii')
            except Exception:
                pass
            netloc = hostname
            if parts.port:
                netloc = f"{hostname}:{parts.port}"
            if parts.username or parts.password:
                auth = parts.username or ''
                if parts.password:
                    auth += f":{parts.password}"
                netloc = f"{auth}@{netloc}"
        else:
            netloc = parts.netloc

        path = quote(parts.path, safe='/@:')
        query = quote(parts.query, safe='=&?/:')
        safe_url = urlunsplit((parts.scheme, netloc, path, query, parts.fragment))
    except Exception:
        safe_url = raw_url

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'uk-UA,uk;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept-Encoding': 'gzip, deflate',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
    }

    req = urllib.request.Request(safe_url, headers=headers)
    ctx = ssl.create_default_context()

    try:
        try:
            resp = urllib.request.urlopen(req, context=ctx, timeout=12)
        except ssl.SSLError:
            ctx_unverified = ssl._create_unverified_context()
            resp = urllib.request.urlopen(req, context=ctx_unverified, timeout=12)
    except urllib.error.HTTPError as e:
        error_html = f"""<!DOCTYPE html>
<html lang="uk">
<head><meta charset="utf-8"><title>Статус відповіді сайту: HTTP {e.code}</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f8fafc; color: #1e293b; display: flex; align-items: center; justify-content: center; min-height: 80vh; margin: 0; padding: 20px; }}
.card {{ background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 20px rgba(0,0,0,0.06); max-width: 580px; width: 100%; padding: 32px; text-align: center; }}
.icon {{ font-size: 42px; margin-bottom: 12px; }}
h2 {{ margin: 0 0 10px; font-size: 20px; color: #0f172a; }}
p {{ margin: 0 0 16px; font-size: 14px; color: #64748b; line-height: 1.5; }}
.code {{ background: #f1f5f9; padding: 6px 12px; border-radius: 6px; font-size: 13px; font-family: monospace; word-break: break-all; color: #0f172a; display: block; margin: 12px 0; }}
.btn {{ display: inline-flex; align-items: center; gap: 6px; padding: 10px 18px; border-radius: 8px; font-size: 14px; font-weight: 600; text-decoration: none; cursor: pointer; transition: all 0.15s; }}
.btn-primary {{ background: #2563eb; color: #ffffff; border: none; }}
.btn-primary:hover {{ background: #1d4ed8; }}
.btn-secondary {{ background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; margin-right: 8px; }}
</style></head>
<body>
<div class="card">
    <div class="icon">⚠️</div>
    <h2>Зовнішній сервер повернув HTTP {e.code}</h2>
    <span class="code">{raw_url}</span>
    <p>Сайт відповів статусом {e.code} ({e.reason}). Ви можете оновити запит або перейти на сайт напряму в новій вкладці.</p>
    <div style="margin-top: 24px;">
        <a href="" onclick="window.location.reload(); return false;" class="btn btn-secondary">🔄 Оновити</a>
        <a href="{raw_url}" target="_blank" rel="noopener noreferrer" class="btn btn-primary">↗ Відкрити у новій вкладці</a>
    </div>
</div></body></html>"""
        response = HttpResponse(error_html, status=200, content_type='text/html; charset=utf-8')
        response['X-Frame-Options'] = 'SAMEORIGIN'
        return response
    except Exception as e:
        error_html = f"""<!DOCTYPE html>
<html lang="uk">
<head><meta charset="utf-8"><title>Не вдалося завантажити сайт</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f8fafc; color: #1e293b; display: flex; align-items: center; justify-content: center; min-height: 80vh; margin: 0; padding: 20px; }}
.card {{ background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 20px rgba(0,0,0,0.06); max-width: 580px; width: 100%; padding: 32px; text-align: center; }}
.icon {{ font-size: 42px; margin-bottom: 12px; }}
h2 {{ margin: 0 0 10px; font-size: 20px; color: #0f172a; }}
p {{ margin: 0 0 16px; font-size: 14px; color: #64748b; line-height: 1.5; }}
.code {{ background: #f1f5f9; padding: 6px 12px; border-radius: 6px; font-size: 13px; font-family: monospace; word-break: break-all; color: #0f172a; display: block; margin: 12px 0; }}
.btn {{ display: inline-flex; align-items: center; gap: 6px; padding: 10px 18px; border-radius: 8px; font-size: 14px; font-weight: 600; text-decoration: none; cursor: pointer; transition: all 0.15s; }}
.btn-primary {{ background: #2563eb; color: #ffffff; border: none; }}
.btn-primary:hover {{ background: #1d4ed8; }}
.btn-secondary {{ background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; margin-right: 8px; }}
</style></head>
<body>
<div class="card">
    <div class="icon">🔌</div>
    <h2>Не вдалося підключитися до сайту</h2>
    <span class="code">{raw_url}</span>
    <p>Виникла помилка підключення ({str(e)}). Перевірте зв'язок або відкрийте сайт в окремій вкладці.</p>
    <div style="margin-top: 24px;">
        <a href="" onclick="window.location.reload(); return false;" class="btn btn-secondary">🔄 Спробувати знову</a>
        <a href="{raw_url}" target="_blank" rel="noopener noreferrer" class="btn btn-primary">↗ Відкрити у новій вкладці</a>
    </div>
</div></body></html>"""
        response = HttpResponse(error_html, status=200, content_type='text/html; charset=utf-8')
        response['X-Frame-Options'] = 'SAMEORIGIN'
        return response

    final_url = resp.geturl()
    content_type = resp.headers.get('content-type', 'text/html')
    raw_body = resp.read()

    # Декомпресія при потребі
    content_encoding = (resp.headers.get('content-encoding') or '').lower()
    if 'gzip' in content_encoding:
        try:
            raw_body = gzip.decompress(raw_body)
        except Exception:
            pass
    elif 'deflate' in content_encoding:
        try:
            raw_body = zlib.decompress(raw_body)
        except Exception:
            pass

    if 'text/html' in content_type or 'xhtml' in content_type:
        encoding = resp.headers.get_content_charset() or 'utf-8'
        try:
            html = raw_body.decode(encoding, errors='replace')
        except Exception:
            html = raw_body.decode('utf-8', errors='replace')

        # Повне перетворення ресурсів (CSS, JS, зображення, посилання) на абсолютні URL
        html = _rewrite_html_resources_to_absolute(html, final_url)

        response = HttpResponse(html, content_type='text/html; charset=utf-8')
        response['X-Frame-Options'] = 'SAMEORIGIN'
        return response
    else:
        response = HttpResponse(raw_body, content_type=content_type)
        response['X-Frame-Options'] = 'SAMEORIGIN'
        return response


@teacher_required
def download_submission_files_zip(request, sub_id):
    """Завантажує всі прикріплені файли однієї здачі учня у вигляді ZIP-архіву."""
    submission = get_object_or_404(Submission.objects.select_related('assignment', 'class_group', 'teacher'), id=sub_id)
    teacher = request.user.teacher_profile

    if not (request.user.is_superuser or submission.teacher == teacher or (submission.assignment and submission.assignment.teacher == teacher)):
        messages.error(request, "У вас немає доступу до цієї здачі.")
        return redirect('teacher_dashboard')

    sub_files = list(submission.files.all())
    if not sub_files and not submission.file:
        messages.warning(request, "У цій здачі немає завантажених файлів.")
        return redirect('view_file', submission_id=sub_id)

    # Якщо прикріплено лише 1 файл — віддаємо його напряму
    if len(sub_files) == 1 and sub_files[0].file and os.path.exists(sub_files[0].file.path):
        return FileResponse(open(sub_files[0].file.path, 'rb'), as_attachment=True, filename=sub_files[0].original_name)
    if not sub_files and submission.file and os.path.exists(submission.file.path):
        return FileResponse(open(submission.file.path, 'rb'), as_attachment=True, filename=os.path.basename(submission.file.name))

    zip_buffer = tempfile.TemporaryFile(mode='w+b')
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for sf in sub_files:
            if sf.file and os.path.exists(sf.file.path):
                fname = sf.original_name or os.path.basename(sf.file.name)
                zip_file.write(sf.file.path, fname)

    zip_buffer.seek(0)
    student_name = f"{submission.last_name}_{submission.first_name}"
    filename = f"Robota_{student_name}.zip"
    response = FileResponse(zip_buffer, as_attachment=True, filename=filename, content_type='application/zip')
    return response



@teacher_required
@require_POST
def delete_comment(request, comment_id):
    """AJAX: видалення коментаря вчителя."""
    comment = get_object_or_404(SubmissionComment, id=comment_id)

    if comment.author == request.user or request.user.is_superuser:
        comment.delete()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'success'})
        messages.success(request, 'Коментар видалено!')
        return redirect('view_file', submission_id=comment.submission_id)

    return JsonResponse({'status': 'error', 'message': 'Немає прав на видалення'}, status=403)


# ═══════════════════════════════════════════════════════════════════════════════
# ПЕРЕГЛЯД ЗДАЧ ПО ЗАВДАННЮ ТА ЗАГАЛЬНИЙ ДАШБОРД
# ═══════════════════════════════════════════════════════════════════════════════

def assignment_ai_understanding(request, pk):
    """
    AJAX endpoint для перегляду та генерації звіту розуміння завдання штучним інтелектом.
    - Вчитель/автор може перевірити виявлені завдання, вимоги та оновити аналіз.
    - Учні мають доступ до перегляду роз'яснення, якщо вчитель увімкнув функцію (allow_student_ai_understanding).
    """
    assignment = get_object_or_404(
        Assignment.objects.prefetch_related('classes', 'files'),
        pk=pk
    )

    is_owner = bool(
        request.user.is_authenticated and
        hasattr(request.user, 'teacher_profile') and
        assignment.teacher == request.user.teacher_profile
    )
    is_admin = bool(request.user.is_authenticated and request.user.is_superuser)
    can_view_as_student = bool(
        assignment.allow_student_ai_understanding and
        assignment.status in [Assignment.STATUS_PUBLISHED, Assignment.STATUS_ARCHIVED]
    )

    if not (is_admin or is_owner or can_view_as_student):
        return JsonResponse({
            'status': 'error',
            'message': 'Доступ заборонено. Переглядати аналіз ШІ може тільки автор завдання або учні (якщо вчитель увімкнув цю опцію під час створення завдання).'
        }, status=403)

    is_teacher = bool(is_admin or is_owner)
    # Учні можуть лише переглядати збережений аналіз (force_refresh вимкнено для учнів)
    force_refresh = is_teacher and ((request.method == 'POST') or (request.GET.get('refresh') in ['1', 'true']))

    try:
        from .gemini_service import analyze_assignment_task_understanding
        from .ai_jobs import enqueue_understanding_job, job_response
        import json
        from .ai_context import assignment_fingerprint
        try:
            data = json.loads(assignment.ai_task_understanding or 'null')
            cached = isinstance(data, dict) and data.get('_source_fingerprint') == assignment_fingerprint(assignment) and data.get('analysis_mode') == 'ai'
        except (ValueError, TypeError):
            cached = False
        if cached and not force_refresh:
            result = analyze_assignment_task_understanding(assignment, force_refresh=False)
            result['is_teacher'] = is_teacher
            return JsonResponse(result)
        job = enqueue_understanding_job(assignment, request.user if is_teacher else None, force_refresh)
        return job_response(job, is_teacher=is_teacher, request=request)
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': f'Помилка під час аналізу завдання ШІ: {str(e)}'
        }, status=500)


@teacher_required
def assignment_submissions(request, pk):
    """
    Сторінка вчителя: всі здачі робіт по конкретному завданню.
    """
    teacher = request.user.teacher_profile
    assignment = get_object_or_404(
        Assignment.objects.prefetch_related('classes', 'files'),
        pk=pk
    )

    if not (request.user.is_superuser or assignment.teacher == teacher):
        messages.error(request, 'У вас немає доступу до цього завдання.')
        return redirect('teacher_dashboard')

    show_mode = request.GET.get('mode', 'grouped')

    submissions_qs = Submission.objects.filter(
        assignment=assignment
    ).select_related('class_group', 'teacher', 'previous_submission').prefetch_related('comments', 'files', 'subsequent_submissions').order_by('-submitted_at')

    # Не дублювати колективні роботи: показуємо одну основну здачу групи зі списком усіх співавторів
    submissions_qs = submissions_qs.filter(primary_submission__isnull=True)

    if show_mode == 'grouped':
        submissions_qs = submissions_qs.filter(is_latest_attempt=True)

    # Фільтр по класу
    class_filter = request.GET.get('class')
    selected_class_id = None
    if class_filter:
        try:
            selected_class_id = int(class_filter)
            submissions_qs = submissions_qs.filter(class_group_id=selected_class_id)
        except (ValueError, TypeError):
            pass

    # Фільтр по оцінці
    grade_filter = request.GET.get('grade_filter', 'all')
    if grade_filter == 'ungraded':
        submissions_qs = submissions_qs.filter(is_latest_attempt=True).filter(Q(grade__isnull=True) | Q(grade=''))
    elif grade_filter == 'graded':
        submissions_qs = submissions_qs.exclude(grade__isnull=True).exclude(grade='')

    # Пошук
    search_query = request.GET.get('search', '').strip()
    if search_query:
        submissions_qs = fuzzy_search_submissions(submissions_qs, search_query)

    # Пагінація
    paginator = Paginator(submissions_qs, 20)
    page_obj = paginator.get_page(request.GET.get('page'))

    # Статистика
    all_sub = Submission.objects.filter(assignment=assignment, is_latest_attempt=True)
    total_count = all_sub.count()
    graded_count = all_sub.exclude(grade__isnull=True).exclude(grade='').count()
    ungraded_count = total_count - graded_count

    # Розподіл оцінок та середня успішність
    grade_dist = {'low': 0, 'medium': 0, 'good': 0, 'excellent': 0}
    numeric_scores = []
    for s in all_sub:
        if s.grade and s.grade.isdigit():
            val = int(s.grade)
            numeric_scores.append(val)
            if val >= 10:
                grade_dist['excellent'] += 1
            elif val >= 7:
                grade_dist['good'] += 1
            elif val >= 4:
                grade_dist['medium'] += 1
            else:
                grade_dist['low'] += 1

    avg_score = round(sum(numeric_scores) / len(numeric_scores), 1) if numeric_scores else None

    assigned_classes = assignment.classes.all().order_by('grade', 'letter')

    # Пошук учнів класу, які ще не здали це завдання (боржники)
    from .student_matcher import is_same_student_identity
    submitted_students = list(all_sub.values_list('last_name', 'first_name', 'class_group_id'))
    submitted_exact_set = {
        (s_last.strip().lower(), s_first.strip().lower(), s_cls_id)
        for s_last, s_first, s_cls_id in submitted_students
    }
    
    classes_to_check = [selected_class_id] if selected_class_id else list(assigned_classes.values_list('id', flat=True))
    all_class_students = Submission.objects.filter(class_group_id__in=classes_to_check).values('last_name', 'first_name', 'class_group__name', 'class_group_id').distinct()

    unsubmitted_students = []
    seen_unsub = set()
    for cs in all_class_students:
        c_last = cs['last_name'].strip()
        c_first = cs['first_name'].strip()
        c_cls_id = cs['class_group_id']
        key = (c_last.lower(), c_first.lower(), c_cls_id)
        if key in seen_unsub:
            continue
        seen_unsub.add(key)

        if key in submitted_exact_set:
            has_submitted = True
        else:
            has_submitted = False
            for s_last, s_first, s_cls_id in submitted_students:
                if s_cls_id == c_cls_id and is_same_student_identity(c_last, c_first, s_last, s_first):
                    has_submitted = True
                    break

        if not has_submitted:
            unsubmitted_students.append({
                'last_name': c_last,
                'first_name': c_first,
                'full_name': f"{c_last} {c_first}".strip(),
                'class_name': cs['class_group__name'],
            })

    unsubmitted_students.sort(key=lambda x: (x['class_name'], x['last_name'].lower()))

    filter_params = request.GET.copy()
    filter_params.pop('page', None)
    filter_params['assignment'] = str(assignment.pk)
    filter_params['from'] = 'assignment_submissions'
    filter_querystring = filter_params.urlencode()

    context = {
        'assignment': assignment,
        'page_obj': page_obj,
        'show_mode': show_mode,
        'total_count': total_count,
        'graded_count': graded_count,
        'ungraded_count': ungraded_count,
        'assigned_classes': assigned_classes,
        'selected_class_id': selected_class_id,
        'grade_filter': grade_filter,
        'search_query': search_query,
        'teacher': teacher,
        'grade_dist': grade_dist,
        'avg_score': avg_score,
        'unsubmitted_students': unsubmitted_students,
        'filter_querystring': filter_querystring,
    }
    return render(request, 'feed/assignment_submissions.html', context)



@teacher_required
def all_submissions_dashboard(request):
    """
    Загальна таблиця всіх здач робіт для вчителя з розумним пошуком, фільтрами та сортуванням.
    """
    teacher = request.user.teacher_profile

    if request.user.is_superuser:
        submissions_qs = Submission.objects.filter(primary_submission__isnull=True)
    else:
        submissions_qs = Submission.objects.filter(
            Q(assignment__teacher=teacher) | Q(teacher=teacher),
            primary_submission__isnull=True
        )

    submissions_qs = submissions_qs.select_related(
        'assignment', 'class_group', 'teacher'
    ).prefetch_related('comments', 'coauthor_submissions').order_by('-submitted_at')

    class_filter = request.GET.get('class')
    assignment_filter = request.GET.get('assignment')
    grade_filter = request.GET.get('grade_filter', 'all')
    search_query = request.GET.get('search', '').strip()
    date_filter = request.GET.get('date', '')

    selected_class_id = None
    if class_filter:
        try:
            selected_class_id = int(class_filter)
            submissions_qs = submissions_qs.filter(class_group_id=selected_class_id)
        except (ValueError, TypeError):
            pass

    selected_assignment_id = None
    if assignment_filter:
        try:
            selected_assignment_id = int(assignment_filter)
            submissions_qs = submissions_qs.filter(assignment_id=selected_assignment_id)
        except (ValueError, TypeError):
            pass

    if grade_filter == 'ungraded':
        submissions_qs = submissions_qs.filter(is_latest_attempt=True).filter(Q(grade__isnull=True) | Q(grade=''))
    elif grade_filter == 'graded':
        submissions_qs = submissions_qs.exclude(grade__isnull=True).exclude(grade='')

    if search_query:
        submissions_qs = fuzzy_search_submissions(submissions_qs, search_query)

    if date_filter:
        try:
            from datetime import datetime as dt
            filter_date = dt.strptime(date_filter, '%Y-%m-%d').date()
            submissions_qs = submissions_qs.filter(submitted_at__date=filter_date)
        except (ValueError, TypeError):
            date_filter = ''

    sort_by = request.GET.get('sort', 'date')
    sort_order = request.GET.get('order', 'desc')

    if sort_by == 'student':
        order = ['-last_name', '-first_name'] if sort_order == 'desc' else ['last_name', 'first_name']
    elif sort_by == 'class':
        order = ['-class_group__name'] if sort_order == 'desc' else ['class_group__name']
    elif sort_by == 'assignment':
        order = ['-assignment__title'] if sort_order == 'desc' else ['assignment__title']
    elif sort_by == 'grade':
        order = ['-grade'] if sort_order == 'desc' else ['grade']
    else:
        order = ['-submitted_at'] if sort_order == 'desc' else ['submitted_at']

    submissions_qs = submissions_qs.order_by(*order)

    paginator = Paginator(submissions_qs, 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    if request.user.is_superuser:
        all_classes = teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter')
        all_assignments = Assignment.objects.all().order_by('-published_at')
    else:
        teacher_class_ids = teacher.classes.values_list('id', flat=True)
        all_classes = ClassGroup.objects.filter(id__in=teacher_class_ids).order_by('grade', 'letter')
        all_assignments = Assignment.objects.filter(teacher=teacher).order_by('-published_at')[:100]

    all_sub = submissions_qs
    total = paginator.count
    graded = all_sub.exclude(grade__isnull=True).exclude(grade='').count()

    filter_params = request.GET.copy()
    filter_params.pop('page', None)
    filter_params['from'] = 'all_submissions'
    filter_querystring = filter_params.urlencode()

    context = {
        'page_obj': page_obj,
        'total_count': total,
        'graded_count': graded,
        'ungraded_count': total - graded,
        'all_classes': all_classes,
        'all_assignments': all_assignments,
        'selected_class_id': selected_class_id,
        'selected_assignment_id': selected_assignment_id,
        'grade_filter': grade_filter,
        'search_query': search_query,
        'date_filter': date_filter,
        'sort_by': sort_by,
        'sort_order': sort_order,
        'teacher': teacher,
        'filter_querystring': filter_querystring,
    }
    return render(request, 'feed/all_submissions_dashboard.html', context)


def sync_grades_to_coauthors(submission, grade, graded_by_user):
    """
    Автоматично проставляє оцінку всім співавторам групової (колективної) роботи без повторень.
    Повертає список імен оновлених/створених робіт співавторів.
    """
    from .student_matcher import extract_coauthors_from_comment, is_same_student_identity, resolve_canonical_student_name
    from .models import Submission, SubmissionFile, Student

    if not submission.assignment or not grade:
        return []

    graded_names = []
    processed_identities = set()

    # Додаємо поточну роботу до вже оброблених
    curr_key = f"{submission.last_name.strip().lower()}_{submission.first_name.strip().lower()}"
    processed_identities.add(curr_key)

    # 1. Знаходимо кореневу роботу та всі зв'язані через primary_submission
    root = submission.primary_submission if submission.primary_submission else submission
    linked_subs = []
    if root.id != submission.id:
        linked_subs.append(root)
    for cs in root.coauthor_submissions.all():
        if cs.id != submission.id and cs not in linked_subs:
            linked_subs.append(cs)

    # 2. Оновлюємо вже зв'язані здачі
    for ls in linked_subs:
        ls_key = f"{ls.last_name.strip().lower()}_{ls.first_name.strip().lower()}"
        if ls_key in processed_identities:
            continue
        processed_identities.add(ls_key)

        ls.grade = grade
        ls.graded_by = graded_by_user
        ls.graded_at = submission.graded_at or timezone.now()
        if submission.teacher_comment:
            ls.teacher_comment = submission.teacher_comment
        ls.save(update_fields=['grade', 'graded_by', 'graded_at', 'teacher_comment'])
        graded_names.append(ls.get_student_full_name())

    # 3. Додатково перевіряємо текстові списки (group_authors та коментар учня) для повної сумісності
    candidate_coauthors = []

    # 3.1. З group_authors кореневої або поточної роботи
    authors_text = root.group_authors or submission.group_authors
    if authors_text:
        for a_name in authors_text.split(','):
            a_clean = a_name.strip()
            if not a_clean:
                continue
            a_ln, a_fn = resolve_canonical_student_name(a_clean, class_group=submission.class_group)
            if not a_ln and not a_fn:
                continue
            cand_k = f"{a_ln.lower()}_{a_fn.lower()}"
            if cand_k not in processed_identities:
                candidate_coauthors.append({
                    'last_name': a_ln,
                    'first_name': a_fn,
                    'full_name': f"{a_ln} {a_fn}".strip(),
                    'student': None,
                })

    # 3.2. З коментаря учня
    comment_coauthors = extract_coauthors_from_comment(
        submission.comment_student,
        class_group=submission.class_group,
        exclude_last_name=submission.last_name,
        exclude_first_name=submission.first_name,
    )
    for cco in comment_coauthors:
        cand_k = f"{cco['last_name'].lower()}_{cco['first_name'].lower()}"
        if cand_k not in processed_identities and not any(is_same_student_identity(cco['last_name'], cco['first_name'], c['last_name'], c['first_name']) for c in candidate_coauthors):
            candidate_coauthors.append(cco)

    # 4. Обробляємо знайдених кандидатів, якщо для них ще не було зв'язаного запису
    for co in candidate_coauthors:
        co_ln = co['last_name']
        co_fn = co['first_name']

        ident_key = f"{co_ln.lower()}_{co_fn.lower()}"
        if ident_key in processed_identities:
            continue
        processed_identities.add(ident_key)

        co_st = co.get('student')
        if not co_st:
            for s in Student.objects.filter(class_group=submission.class_group):
                if is_same_student_identity(co_ln, co_fn, s.last_name, s.first_name):
                    co_st = s
                    break

        existing_sub = None
        if co_st:
            existing_sub = Submission.objects.filter(
                assignment=submission.assignment,
                class_group=submission.class_group,
                student=co_st
            ).exclude(pk=submission.pk).first()

        if not existing_sub:
            for s in Submission.objects.filter(assignment=submission.assignment, class_group=submission.class_group).exclude(pk=submission.pk):
                if is_same_student_identity(co_ln, co_fn, s.last_name, s.first_name):
                    existing_sub = s
                    break

        if existing_sub:
            existing_sub.grade = grade
            existing_sub.graded_by = graded_by_user
            existing_sub.graded_at = submission.graded_at or timezone.now()
            if submission.teacher_comment:
                existing_sub.teacher_comment = submission.teacher_comment
            if not existing_sub.primary_submission and root.id != existing_sub.id:
                existing_sub.primary_submission = root
                existing_sub.is_group_work = True
                existing_sub.save(update_fields=['grade', 'graded_by', 'graded_at', 'teacher_comment', 'primary_submission', 'is_group_work'])
            else:
                existing_sub.save(update_fields=['grade', 'graded_by', 'graded_at', 'teacher_comment'])
            graded_names.append(existing_sub.get_student_full_name())
        else:
            new_sub = Submission.objects.create(
                assignment=submission.assignment,
                student=co_st,
                first_name=co_fn,
                last_name=co_ln,
                class_group=submission.class_group,
                teacher=submission.teacher,
                file=submission.file,
                link=submission.link,
                comment_student=f"Колективна робота (спільно з {submission.get_student_full_name()})",
                teacher_comment=submission.teacher_comment,
                is_group_work=True,
                group_authors=root.group_authors or submission.group_authors,
                primary_submission=root,
                grade=grade,
                graded_by=graded_by_user,
                graded_at=submission.graded_at or timezone.now(),
                ai_suggested_grade=submission.ai_suggested_grade,
                ai_score_level=submission.ai_score_level,
                ai_feedback=submission.ai_feedback,
                ai_status=submission.ai_status,
                is_latest_attempt=True,
            )
            # Прив'язуємо файли якщо є
            if hasattr(submission, 'files') and submission.files.exists():
                for sf in submission.files.all():
                    SubmissionFile.objects.create(
                        submission=new_sub,
                        file=sf.file,
                        original_name=sf.original_name
                    )
            graded_names.append(new_sub.get_student_full_name())

    return graded_names


@teacher_required
@transaction.atomic
def grade_submission(request, sub_id):
    """AJAX: виставлення або зміна оцінки здачі роботи з підтримкою співавторів та індивідуальних оцінок."""
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)

    submission = get_object_or_404(Submission, id=sub_id)
    teacher = request.user.teacher_profile

    if not (request.user.is_superuser or (submission.teacher == teacher) or (submission.assignment and submission.assignment.teacher == teacher)):
        return JsonResponse({'status': 'error', 'message': 'Немає доступу'}, status=403)

    grade = request.POST.get('grade', '').strip()
    group_members = submission.get_all_group_submissions() if (submission.is_group_work or submission.primary_submission_id or submission.coauthor_submissions.exists()) else [submission]
    graded_members = []
    try:
        validated_grades = member_grades(request.POST, group_members, grade)
    except ValidationError as exc:
        return JsonResponse({'status': 'error', 'message': exc.messages[0]}, status=400)

    for m in group_members:
        m_grade = validated_grades[m.id]
        if not m_grade and grade:
            m_grade = grade

        m.grade = m_grade or None
        m.graded_by = request.user
        if m_grade:
            m.graded_at = timezone.now()
            graded_members.append(f"{m.get_student_full_name()} ({m_grade})")

        update_f = ['grade', 'graded_by']
        if m_grade:
            update_f.append('graded_at')
        m.save(update_fields=update_f)

    saved_comment = None
    feedback = request.POST.get('comment_text', '').strip()
    if feedback:
        comment = SubmissionComment.objects.create(submission=submission, author=request.user, text=feedback)
        log_submission_activity(request.user, 'comment', f"Коментар до роботи {submission.get_student_full_name()}: {feedback[:50]}", submission=submission)
        saved_comment = {
            'id': comment.id, 'author': comment.get_author_name(), 'text': comment.text,
            'created_at': timezone.localtime(comment.created_at).strftime('%d.%m.%Y %H:%M'),
        }

    submission.refresh_from_db()

    coauthors_graded = []
    if grade and len(group_members) <= 1:
        coauthors_graded = sync_grades_to_coauthors(submission, grade, request.user)
        for c_name in coauthors_graded:
            if not any(c_name in gm for gm in graded_members):
                graded_members.append(f"{c_name} ({grade})")

    log_msg = f"Оцінено роботу {submission.get_student_full_name()}: {', '.join(graded_members) if graded_members else (grade or 'оцінку знято')}"
    if coauthors_graded:
        log_msg += f" (також виставлено оцінку співавторам: {', '.join(coauthors_graded)})"

    log_submission_activity(
        request.user,
        'grading',
        log_msg,
        submission=submission
    )

    # Оновлюємо актуальний лічильник робіт без оцінки для інтерфейсу вчителя (без дублів колективних робіт)
    if request.user.is_superuser or request.session.get('superadmin_mode'):
        remaining_pending = Submission.objects.filter(is_latest_attempt=True, primary_submission__isnull=True).filter(Q(grade__isnull=True) | Q(grade='')).count()
    elif teacher:
        remaining_pending = Submission.objects.filter(
            assignment__teacher=teacher,
            is_latest_attempt=True,
            primary_submission__isnull=True
        ).filter(
            Q(grade__isnull=True) | Q(grade='')
        ).count()
    else:
        remaining_pending = 0

    from .utils import get_teacher_upcoming_notifications
    notifs = get_teacher_upcoming_notifications(teacher) if teacher else []
    unread_count = len([n for n in notifs if n.get('type') == 'missing_task'])

    return JsonResponse({
        'status': 'success',
        'grade': submission.grade or '',
        'comment': saved_comment,
        'is_graded': bool(submission.grade),
        'graded_members': graded_members,
        'coauthors_graded': coauthors_graded,
        'message': log_msg,
        'pending_submissions_count': remaining_pending,
        'unread_notifications_count': unread_count,
    })


@teacher_required
def toggle_submission_ignore_plagiarism(request, sub_id):
    """
    AJAX: Вчитель вмикає або вимикає ігнорування плагіату для зданої роботи.
    Дозволяє позначити спільну роботу учнів, навіть якщо вони не зазначили співавторів при здачі.
    При увімкненні автоматично синхронізує прапорець із парними роботами з таким самим файлом.
    """
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)

    submission = get_object_or_404(Submission, id=sub_id)
    teacher = getattr(request.user, 'teacher_profile', None)

    if not (request.user.is_superuser or (submission.teacher == teacher) or (submission.assignment and submission.assignment.teacher == teacher)):
        return JsonResponse({'status': 'error', 'message': 'Немає доступу'}, status=403)

    raw_ignore = request.POST.get('ignore')
    if raw_ignore is None:
        try:
            import json
            data = json.loads(request.body.decode('utf-8'))
            raw_ignore = data.get('ignore')
        except Exception:
            pass

    if raw_ignore is not None:
        new_val = str(raw_ignore).strip().lower() in ('true', '1', 'yes')
    else:
        new_val = not submission.ignore_plagiarism

    submission.ignore_plagiarism = new_val
    submission.save(update_fields=['ignore_plagiarism'])
    if hasattr(submission, '_cached_dup_info'):
        delattr(submission, '_cached_dup_info')

    # Синхронізуємо прапорець із парними роботами в межах цього завдання, які мають такий самий файл
    paired_students = []
    if submission.file and submission.assignment:
        try:
            file_path = submission.file.path if submission.file else None
            if file_path and os.path.exists(file_path):
                from .duplicate_detector import get_file_sha256
                sub_hash = get_file_sha256(file_path)
                if sub_hash:
                    matching_subs = submission.assignment.submissions.exclude(id=submission.id).filter(file__isnull=False)
                    for other in matching_subs:
                        if other.file and os.path.exists(other.file.path):
                            if get_file_sha256(other.file.path) == sub_hash:
                                other.ignore_plagiarism = new_val
                                other.save(update_fields=['ignore_plagiarism'])
                                if hasattr(other, '_cached_dup_info'):
                                    delattr(other, '_cached_dup_info')
                                paired_students.append(other.get_student_full_name())
        except Exception:
            pass

    action_text = "увімкнено" if new_val else "вимкнено"
    log_msg = f"Вчитель {action_text} ігнорування плагіату (спільна робота) для {submission.get_student_full_name()}"
    if paired_students:
        log_msg += f" (також оновлено для {', '.join(paired_students)})"

    log_submission_activity(
        request.user,
        'update',
        log_msg,
        submission=submission
    )

    dup_info = check_submission_duplicates(submission)

    return JsonResponse({
        'status': 'success',
        'ignore_plagiarism': submission.ignore_plagiarism,
        'dup_info': dup_info,
        'message': 'Плагіат проігноровано: роботу позначено як спільну' if new_val else 'Ігнорування плагіату вимкнено',
        'paired_students': paired_students,
    })


@teacher_required
@transaction.atomic
def mass_grade_submissions(request):
    """
    AJAX / POST: Масове виставлення оцінок кільком здачам робіт одночасно.
    Оновлює оцінку для вибраних здач, автоматично синхронізує оцінку зі співавторами,
    логує дію та повертає оновлені лічильники сповіщень.
    """
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)

    teacher = getattr(request.user, 'teacher_profile', None)
    if not teacher and (request.user.is_superuser or request.session.get('superadmin_mode')):
        teacher = Teacher.objects.first()

    payload = {}
    if request.content_type == 'application/json' or (request.body and not request.POST):
        try:
            import json
            payload = json.loads(request.body.decode('utf-8'))
        except Exception:
            payload = {}

    sub_ids = request.POST.getlist('submission_ids[]') or request.POST.getlist('submission_ids')
    if not sub_ids and payload.get('submission_ids'):
        val = payload.get('submission_ids')
        sub_ids = val if isinstance(val, list) else [val]

    if not sub_ids:
        raw_ids = request.POST.get('submission_ids', '')
        if raw_ids:
            sub_ids = [s.strip() for s in str(raw_ids).split(',') if s.strip().isdigit()]

    if not sub_ids:
        return JsonResponse({'status': 'error', 'message': 'Не вибрано жодної роботи'}, status=400)

    grade = str(request.POST.get('grade') or payload.get('grade') or '').strip()
    action = str(request.POST.get('action') or payload.get('action') or 'grade')
    if action == 'clear':
        grade = ''

    if not grade and action != 'clear':
        return JsonResponse({'status': 'error', 'message': 'Вкажіть оцінку для виставлення'}, status=400)

    try:
        grade = validate_grade(grade)
    except ValidationError as exc:
        return JsonResponse({'status': 'error', 'message': exc.messages[0]}, status=400)

    try:
        sub_int_ids = [int(i) for i in sub_ids]
    except (ValueError, TypeError):
        return JsonResponse({'status': 'error', 'message': 'Некоректні ідентифікатори здач'}, status=400)

    if request.user.is_superuser or request.session.get('superadmin_mode'):
        subs = list(Submission.objects.filter(id__in=sub_int_ids).select_related('assignment', 'class_group'))
    else:
        subs = list(Submission.objects.filter(
            id__in=sub_int_ids
        ).filter(
            Q(assignment__teacher=teacher) | Q(teacher=teacher)
        ).select_related('assignment', 'class_group'))

    now = timezone.now()
    updated_subs = []
    coauthors_all = []

    for sub in subs:
        sub.grade = grade or None
        sub.graded_by = request.user
        if grade:
            sub.graded_at = now
        sub.save(update_fields=['grade', 'graded_by', 'graded_at'])
        updated_subs.append(sub.id)

        if grade:
            coauthors = sync_grades_to_coauthors(sub, grade, request.user)
            if coauthors:
                coauthors_all.extend(coauthors)

        log_msg = f"Масове оцінювання: {sub.get_student_full_name()} -> {grade or 'оцінку знято'}"
        log_submission_activity(request.user, 'grading', log_msg, submission=sub)

    # Перераховуємо актуальний лічильник робіт без оцінки
    if request.user.is_superuser or request.session.get('superadmin_mode'):
        remaining_pending = Submission.objects.filter(is_latest_attempt=True).filter(Q(grade__isnull=True) | Q(grade='')).count()
    elif teacher:
        remaining_pending = Submission.objects.filter(
            assignment__teacher=teacher,
            is_latest_attempt=True
        ).filter(
            Q(grade__isnull=True) | Q(grade='')
        ).count()
    else:
        remaining_pending = 0

    from .utils import get_teacher_upcoming_notifications
    notifs = get_teacher_upcoming_notifications(teacher) if teacher else []
    unread_count = len([n for n in notifs if n.get('type') == 'missing_task'])

    return JsonResponse({
        'status': 'success',
        'success': True,
        'updated_count': len(updated_subs),
        'graded_count': len(updated_subs),
        'updated_ids': updated_subs,
        'grade': grade or '',
        'coauthors_graded': coauthors_all,
        'pending_submissions_count': remaining_pending,
        'unread_notifications_count': unread_count,
        'notifications': [{
            'id': n.get('id', ''),
            'type': n.get('type', ''),
            'icon': n.get('icon', '🔔'),
            'title': n.get('title', ''),
            'message': n.get('message', ''),
            'action_url': n.get('action_url', ''),
            'badge': n.get('badge', ''),
            'badge_class': n.get('badge_class', ''),
        } for n in notifs],
        'message': f'Успішно оцінено {len(updated_subs)} робіт (оцінка: {grade or "знято"}).',
    })



@teacher_required
def add_submission_comment(request, sub_id):
    """AJAX: додавання коментаря вчителя до здачі роботи."""
    if request.method != 'POST':
        return JsonResponse({'status': 'error'}, status=405)

    submission = get_object_or_404(Submission, id=sub_id)
    teacher = request.user.teacher_profile

    if not (request.user.is_superuser or (submission.teacher == teacher) or (submission.assignment and submission.assignment.teacher == teacher)):
        return JsonResponse({'status': 'error', 'message': 'Немає доступу'}, status=403)

    text = request.POST.get('text', '').strip()
    if not text:
        return JsonResponse({'status': 'error', 'message': 'Порожній коментар'}, status=400)

    comment = SubmissionComment.objects.create(
        submission=submission,
        author=request.user,
        text=text
    )

    log_submission_activity(
        request.user,
        'comment',
        f"Коментар до роботи {submission.get_student_full_name()}: {text[:50]}",
        submission=submission
    )

    return JsonResponse({
        'status': 'success',
        'comment': {
            'id': comment.id,
            'author': comment.get_author_name(),
            'text': comment.text,
            'created_at': timezone.localtime(comment.created_at).strftime('%d.%m.%Y %H:%M'),
        }
    })


@teacher_required
@require_POST
def teacher_submission_coauthors(request, sub_id):
    """
    Дозволяє вчителю самостійно призначати/змінювати співавторів колективної роботи,
    якщо учні забули або помилилися при здачі. Всі дії фіксуються в журналі.
    """
    from .student_matcher import is_same_student_identity, resolve_canonical_student_name

    submission = get_object_or_404(
        Submission.objects.select_related('assignment', 'class_group', 'student', 'primary_submission'),
        id=sub_id
    )

    # Якщо це робота-співавтор, діємо від імені кореневої primary_submission
    root = submission.primary_submission if submission.primary_submission else submission

    # Отримуємо список обраних студентів (ID або ПІБ)
    student_ids = request.POST.getlist('student_ids')
    custom_names_raw = request.POST.get('custom_names', '')

    target_students = []
    if student_ids:
        target_students = list(Student.objects.filter(id__in=student_ids))

    # Додаткові імена, введені вручну
    manual_names = [n.strip() for n in custom_names_raw.split(',') if n.strip()]

    # Збираємо всіх авторів
    all_coauthors_info = []
    for s in target_students:
        all_coauthors_info.append({
            'student': s,
            'last_name': s.last_name,
            'first_name': s.first_name,
            'full_name': s.get_full_name(),
        })

    for m_name in manual_names:
        ln, fn = resolve_canonical_student_name(m_name, class_group=root.class_group)
        if ln or fn:
            all_coauthors_info.append({
                'student': None,
                'last_name': ln or m_name,
                'first_name': fn or '',
                'full_name': f"{ln} {fn}".strip() if fn else m_name,
            })

    # Виключаємо автора кореневої роботи зі списку співавторів
    final_coauthors = []
    for c in all_coauthors_info:
        if is_same_student_identity(c['last_name'], c['first_name'], root.last_name, root.first_name):
            continue
        if any(is_same_student_identity(c['last_name'], c['first_name'], fc['last_name'], fc['first_name']) for fc in final_coauthors):
            continue
        final_coauthors.append(c)

    # Формуємо рядок group_authors
    members_display = [root.get_student_full_name()] + [c['full_name'] for c in final_coauthors]
    new_group_authors_str = ", ".join(members_display)

    if final_coauthors:
        root.is_group_work = True
        root.group_authors = new_group_authors_str
    else:
        # Якщо вчитель прибрав усіх співавторів
        root.is_group_work = False
        root.group_authors = ''
    root.save(update_fields=['is_group_work', 'group_authors'])

    # Для кожного співавтора створюємо або оновлюємо Submission
    linked_subs = []
    for co in final_coauthors:
        co_st = co.get('student')
        co_ln = co['last_name']
        co_fn = co['first_name']

        if not co_st and root.class_group:
            for s in Student.objects.filter(class_group=root.class_group):
                if is_same_student_identity(co_ln, co_fn, s.last_name, s.first_name):
                    co_st = s
                    break

        peer_sub = None
        if co_st:
            peer_sub = Submission.objects.filter(
                assignment=root.assignment,
                class_group=root.class_group,
                student=co_st
            ).exclude(id=root.id).first()

        if not peer_sub:
            peer_sub = Submission.objects.filter(
                assignment=root.assignment,
                class_group=root.class_group,
                last_name__iexact=co_ln,
                first_name__iexact=co_fn
            ).exclude(id=root.id).first()

        if peer_sub:
            peer_sub.primary_submission = root
            peer_sub.is_group_work = True
            peer_sub.group_authors = new_group_authors_str
            if root.grade and not peer_sub.grade:
                peer_sub.grade = root.grade
                peer_sub.graded_by = root.graded_by or request.user
                peer_sub.graded_at = root.graded_at or timezone.now()
                peer_sub.teacher_comment = root.teacher_comment
            peer_sub.save(update_fields=['primary_submission', 'is_group_work', 'group_authors', 'grade', 'graded_by', 'graded_at', 'teacher_comment'])
            linked_subs.append(peer_sub)
        else:
            peer_comment = f"Колективна робота (додано вчителем спільно з {root.get_student_full_name()})"
            new_sub = Submission.objects.create(
                assignment=root.assignment,
                student=co_st,
                last_name=co_ln,
                first_name=co_fn,
                class_group=root.class_group,
                teacher=root.teacher,
                file=root.file,
                link=root.link,
                comment_student=peer_comment,
                teacher_comment=root.teacher_comment,
                is_group_work=True,
                group_authors=new_group_authors_str,
                primary_submission=root,
                grade=root.grade,
                graded_by=root.graded_by if root.grade else None,
                graded_at=root.graded_at if root.grade else None,
                is_latest_attempt=True
            )
            # Копіюємо файли
            for sf in root.files.all():
                SubmissionFile.objects.create(
                    submission=new_sub,
                    file=sf.file,
                    original_name=sf.original_name
                )
            linked_subs.append(new_sub)

    # Якщо раніше були прив'язані інші coauthor_submissions, які тепер прибрали зі списку:
    linked_ids = {s.id for s in linked_subs}
    for old_co in root.coauthor_submissions.all():
        if old_co.id not in linked_ids:
            old_co.primary_submission = None
            old_co.is_group_work = False
            old_co.save(update_fields=['primary_submission', 'is_group_work'])

    log_desc = (f"Вчитель {request.user.get_full_name() or request.user.username} оновив склад "
                f"колективної роботи для «{root.get_student_full_name()}» "
                f"(Завдання «{root.assignment.title if root.assignment else '—'}», ID {root.id}). "
                f"Склад групи: {new_group_authors_str if final_coauthors else 'індивідуальна робота'}.")
    log_submission_activity(request.user, 'group_authors', log_desc, submission=root)

    success_msg = f"Склад колективної роботи успішно оновлено! Учасники: {new_group_authors_str if final_coauthors else 'індивідуальна'}"
    messages.success(request, success_msg)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.POST.get('format') == 'json':
        return JsonResponse({
            'success': True,
            'message': success_msg,
            'group_authors': new_group_authors_str,
            'members': members_display,
            'is_group_work': bool(final_coauthors)
        })

    return redirect('view_file', submission_id=root.id)


@teacher_required
def delete_submission(request, sub_id):
    """Видалення здачі роботи (POST)."""
    if request.method != 'POST':
        return JsonResponse({'status': 'error'}, status=405)

    get_object_or_404(Submission, id=sub_id)
    from .student_deletion import delete_submission as remove_submission
    assignment_pk, student_name = remove_submission(sub_id, request.user)
    messages.success(request, f'Здачу від {student_name} видалено.')

    if assignment_pk:
        return redirect('assignment_submissions', pk=assignment_pk)
    return redirect('all_submissions_dashboard')


# ═══════════════════════════════════════════════════════════════════════════════
# КЕРУВАННЯ УЧНЯМИ ТА КЛАСАМИ (STUDENT ROSTER & PROFILE MANAGEMENT)
# ═══════════════════════════════════════════════════════════════════════════════

@teacher_required
def teacher_students(request):
    """
    Панель керування учнями та класами для вчителів:
    - Перегляд учнів по класах
    - Редагування імен/прізвищ учнів (виправлення помилок)
    - Зміна класу учня з автоматичною синхронізацією робіт та журналу
    - Додавання нового учня вручну
    - Імпорт списків учнів та класів з файлу / тексту
    - Експорт списків учнів у CSV
    """
    from .student_importer import sync_all_existing_submissions_to_students
    
    # Автоматично синхронізуємо наявні здачі в учнів при першому запуску, якщо таблиця пуста
    if not Student.objects.exists() and Submission.objects.exists():
        sync_all_existing_submissions_to_students()

    teacher = request.user.teacher_profile if hasattr(request.user, 'teacher_profile') else None

    # Отримуємо доступні класи (суперадмін бачить усі, вчитель — свої або всі для школи)
    if request.user.is_superuser:
        all_class_groups = list(teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter'))
    elif teacher and teacher.classes.exists():
        my_classes = list(teaching_classes(teacher.classes.all()).order_by('grade', 'letter'))
        other_classes = list(ClassGroup.objects.exclude(id__in=[c.id for c in my_classes]).order_by('grade', 'letter'))
        all_class_groups = my_classes + other_classes
    else:
        all_class_groups = list(teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter'))

    all_class_groups = list(teaching_classes(ClassGroup.objects.filter(pk__in=[c.pk for c in all_class_groups])).order_by('grade', 'letter'))
    selected_class_id = request.GET.get('class_group') or request.GET.get('class')
    search_query = request.GET.get('search', '').strip()
    current_tab = request.GET.get('tab', 'students')

    students_qs = Student.objects.select_related('class_group').order_by('class_group__grade', 'class_group__letter', 'last_name', 'first_name')

    selected_class = None
    if selected_class_id:
        try:
            cid = int(selected_class_id)
            students_qs = students_qs.filter(class_group_id=cid)
            selected_class = ClassGroup.objects.filter(id=cid).first()
        except (ValueError, TypeError):
            pass

    if search_query:
        tokens = search_query.split()
        if len(tokens) == 1:
            q_token = tokens[0]
            students_qs = students_qs.filter(
                Q(last_name__icontains=q_token) |
                Q(first_name__icontains=q_token) |
                Q(class_group__name__icontains=q_token)
            )
        else:
            q_first, q_last = tokens[0], tokens[1]
            students_qs = students_qs.filter(
                (Q(last_name__icontains=q_first) & Q(first_name__icontains=q_last)) |
                (Q(last_name__icontains=q_last) & Q(first_name__icontains=q_first)) |
                Q(last_name__icontains=search_query) |
                Q(first_name__icontains=search_query)
            )

    # Статистика
    total_students_count = Student.objects.count()
    total_classes_count = ClassGroup.objects.count()
    total_submissions_count = Submission.objects.count()

    # Кількість учнів у класах для бейджів
    from django.db.models import Count
    class_counts_map = dict(Student.objects.values('class_group_id').annotate(c=Count('id')).values_list('class_group_id', 'c'))
    for cg in all_class_groups:
        cg.students_count = class_counts_map.get(cg.id, 0)
        cg.is_selected = bool(selected_class and cg.id == selected_class.id)

    # Список учнів з підрахунком робіт
    students_list = list(students_qs)
    submissions_by_class = {}
    for sub in Submission.objects.filter(class_group_id__in=[s.class_group_id for s in students_list if s.class_group_id]).values('id', 'student_id', 'outside_student_id', 'last_name', 'first_name', 'class_group_id', 'grade'):
        cid = sub['class_group_id']
        if cid not in submissions_by_class:
            submissions_by_class[cid] = []
        submissions_by_class[cid].append(sub)

    from .student_matcher import is_same_student_identity
    profile_class_ids = set(teacher.classes.values_list('pk', flat=True)) if teacher else set()
    for st in students_list:
        st.profile_url = (
            reverse('student_detail', kwargs={'student_name': st.get_full_name()}) + f'?student_id={st.pk}'
            if request.user.is_superuser or st.class_group_id in profile_class_ids else ''
        )
        c_subs = submissions_by_class.get(st.class_group_id, [])
        from .roster_identity import has_stable_class_roster
        allow_names = not has_stable_class_roster(st.class_group) and not Student.objects.filter(
            class_group_id=st.class_group_id, last_name__iexact=st.last_name, first_name__iexact=st.first_name).exclude(pk=st.pk).exists()
        st_subs = [s for s in c_subs if s['student_id'] == st.pk or (allow_names and s['student_id'] is None
            and s['outside_student_id'] is None and is_same_student_identity(st.last_name, st.first_name, s['last_name'], s['first_name']))]
        st.subs_count = len(st_subs)
        st.graded_count = len([s for s in st_subs if s.get('grade')])

    paginator = Paginator(students_list, 20)
    page_obj = paginator.get_page(request.GET.get('page') if current_tab == 'students' else 1)

    # Форми
    add_form = StudentForm(initial={'class_group': selected_class} if selected_class else None)
    import_form = StudentImportForm(initial={'default_class': selected_class} if selected_class else None)

    # Обробка дій через POST
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'add_student':
            add_form = StudentForm(request.POST)
            if add_form.is_valid():
                new_st = add_form.save()
                if add_form.cleaned_data.get('sync_submissions', True):
                    new_st.sync_submissions()
                log_submission_activity(
                    request.user,
                    'student_created',
                    f"Додано нового учня «{new_st.get_full_name()}» до класу {new_st.class_group.name}"
                )
                messages.success(request, f"Учня «{new_st.get_full_name()}» успішно додано до класу {new_st.class_group.name}!")
                return redirect(f"{reverse('teacher_students')}?class_group={new_st.class_group_id}")

        elif action == 'save_teacher_schedule' and teacher:
            bell_slots_all = BellSchedule.objects.all().order_by('order', 'lesson_number')
            days_list = [1, 2, 3, 4, 5, 6]
            saved_count = 0
            cleared_count = 0

            for day_num in days_list:
                for slot in bell_slots_all:
                    class_key = f"cell_{day_num}_{slot.id}_class"
                    subject_key = f"cell_{day_num}_{slot.id}_subject"

                    class_id_str = request.POST.get(class_key, '').strip()
                    subject_id_str = request.POST.get(subject_key, '').strip()

                    if class_id_str and class_id_str.isdigit():
                        class_id = int(class_id_str)
                        subject_id = int(subject_id_str) if (subject_id_str and subject_id_str.isdigit()) else None
                        TeacherLessonSchedule.objects.update_or_create(
                            teacher=teacher,
                            day_of_week=day_num,
                            bell_slot=slot,
                            defaults={
                                'class_group_id': class_id,
                                'subject_id': subject_id
                            }
                        )
                        saved_count += 1
                    else:
                        deleted, _ = TeacherLessonSchedule.objects.filter(
                            teacher=teacher,
                            day_of_week=day_num,
                            bell_slot=slot
                        ).delete()
                        if deleted:
                            cleared_count += 1

            messages.success(request, f"Тижневий розклад уроків збережено! Зафіксовано {saved_count} уроків на тиждень.")
            return redirect(f"{reverse('teacher_students')}?tab=schedule")

        elif action == 'clear_teacher_schedule' and teacher:
            TeacherLessonSchedule.objects.filter(teacher=teacher).delete()
            messages.success(request, "Ваш тижневий розклад уроків успішно очищено.")
            return redirect(f"{reverse('teacher_students')}?tab=schedule")

    ukr_weekdays = {
        0: 'Понеділок',
        1: 'Вівторок',
        2: 'Середа',
        3: 'Четвер',
        4: "П'ятниця",
        5: 'Субота',
        6: 'Неділя',
    }

    # Дані для розкладу уроків вчителя
    bell_slots = BellSchedule.objects.all().order_by('order', 'lesson_number')
    days_of_week = [
        (1, 'Понеділок'),
        (2, 'Вівторок'),
        (3, 'Середа'),
        (4, 'Четвер'),
        (5, "П'ятниця"),
    ]
    # Якщо у вчителя призначено уроки на суботу або обрано суботу
    if teacher and TeacherLessonSchedule.objects.filter(teacher=teacher, day_of_week=6).exists():
        days_of_week.append((6, 'Субота'))

    teacher_classes = []
    if teacher and teacher.classes.exists():
        teacher_classes = list(teaching_classes(teacher.classes.all()).order_by('grade', 'letter'))
    else:
        teacher_classes = all_class_groups

    teacher_subjects = []
    if teacher and teacher.subjects.exists():
        teacher_subjects = list(teacher.subjects.all().order_by('name'))
    else:
        teacher_subjects = list(Subject.objects.all().order_by('name'))

    now_dt = timezone.localtime(timezone.now())
    today_date = now_dt.date()
    today_weekday = today_date.weekday() + 1  # 1=Понеділок .. 7=Неділя
    current_time = now_dt.time()
    now_minutes = current_time.hour * 60 + current_time.minute
    today_weekday_name = ukr_weekdays.get(today_date.weekday(), '')
    today_date_str = today_date.strftime('%d.%m.%Y')
    today_time_str = current_time.strftime('%H:%M')

    schedule_rows = []
    total_scheduled_lessons = 0
    if teacher:
        schedules = TeacherLessonSchedule.objects.filter(teacher=teacher).select_related('bell_slot', 'class_group', 'subject')
        total_scheduled_lessons = schedules.count()
        schedule_map = {(s.day_of_week, s.bell_slot_id): s for s in schedules}
        for slot in bell_slots:
            s_min = slot.start_time.hour * 60 + slot.start_time.minute
            e_min = slot.end_time.hour * 60 + slot.end_time.minute
            is_current_slot = (s_min <= now_minutes < e_min)

            row_days = []
            for day_num, day_name in days_of_week:
                entry = schedule_map.get((day_num, slot.id))
                is_cell_today = (day_num == today_weekday)
                is_current_lesson = (is_cell_today and is_current_slot)
                row_days.append({
                    'day_num': day_num,
                    'day_name': day_name,
                    'is_today': is_cell_today,
                    'is_current_lesson': is_current_lesson,
                    'entry': entry,
                    'class_id': entry.class_group_id if entry else None,
                    'subject_id': entry.subject_id if entry else None,
                })
            schedule_rows.append({
                'slot': slot,
                'is_current_slot': is_current_slot,
                'days': row_days,
            })

    # ── Облік проведених тем уроків (вкладка tab=lessons) ─────────────────────
    lessons_base_qs = Assignment.objects.filter(
        status__in=[Assignment.STATUS_PUBLISHED, Assignment.STATUS_ARCHIVED]
    )
    if teacher and not request.user.is_superuser:
        lessons_base_qs = lessons_base_qs.filter(teacher=teacher)

    total_conducted_lessons_count = lessons_base_qs.count()
    archived_conducted_lessons_count = lessons_base_qs.filter(status=Assignment.STATUS_ARCHIVED).count()
    published_conducted_lessons_count = total_conducted_lessons_count - archived_conducted_lessons_count

    # Підрахунок проведених уроків по класах для бейджів у фільтрі
    class_lessons_count_map = dict(
        lessons_base_qs.filter(classes__isnull=False)
        .values('classes__id')
        .annotate(cnt=Count('id', distinct=True))
        .values_list('classes__id', 'cnt')
    )
    for cg in all_class_groups:
        cg.conducted_lessons_count = class_lessons_count_map.get(cg.id, 0)

    lessons_filter_qs = lessons_base_qs
    if selected_class_id:
        try:
            cid = int(selected_class_id)
            lessons_filter_qs = lessons_filter_qs.filter(classes__id=cid)
        except (ValueError, TypeError):
            pass

    lesson_status_filter = request.GET.get('status', '').strip()
    if lesson_status_filter in [Assignment.STATUS_PUBLISHED, Assignment.STATUS_ARCHIVED]:
        lessons_filter_qs = lessons_filter_qs.filter(status=lesson_status_filter)

    if search_query:
        lessons_filter_qs = lessons_filter_qs.filter(
            Q(title__icontains=search_query) |
            Q(subject__name__icontains=search_query) |
            Q(classes__name__icontains=search_query) |
            Q(student_name__icontains=search_query)
        ).distinct()

    lessons_filter_qs = lessons_filter_qs.select_related('teacher__user', 'subject').prefetch_related('classes', 'submissions').order_by('-published_at', '-created_at', '-id')

    conducted_lessons_list = []
    for a in lessons_filter_qs:
        dt = a.published_at or a.created_at
        local_dt = timezone.localtime(dt) if dt and timezone.is_aware(dt) else dt
        w_day = ukr_weekdays.get(local_dt.weekday(), '') if local_dt else ''
        d_str = local_dt.strftime('%d.%m.%Y') if local_dt else '—'
        t_str = local_dt.strftime('%H:%M') if local_dt else ''

        c_list = list(a.classes.all())
        if c_list:
            c_str = ", ".join(c.name for c in c_list)
        elif a.is_individual:
            c_str = f"Індивідуально ({a.student_name})" if a.student_name else "Індивідуально"
        else:
            c_str = "Всі класи"

        conducted_lessons_list.append({
            'assignment': a,
            'id': a.id,
            'title': a.title,
            'subject_name': a.subject.name if a.subject else '—',
            'status': a.status,
            'status_display': a.get_status_display(),
            'is_archived': a.status == Assignment.STATUS_ARCHIVED,
            'date_str': d_str,
            'time_str': t_str,
            'day_name': w_day,
            'full_date': f"{d_str} ({w_day})" if w_day else d_str,
            'classes': c_list,
            'classes_str': c_str,
            'submissions_count': a.submissions.count(),
        })

    lessons_paginator = Paginator(conducted_lessons_list, 20)
    lessons_page_obj = lessons_paginator.get_page(request.GET.get('page') if current_tab == 'lessons' else 1)

    return render(request, 'feed/teacher_students.html', {
        'page_obj': page_obj,
        'students_list': students_list,
        'class_groups': all_class_groups,
        'selected_class': selected_class,
        'selected_class_id': selected_class_id,
        'search_query': search_query,
        'total_students_count': total_students_count,
        'total_classes_count': total_classes_count,
        'total_submissions_count': total_submissions_count,
        'add_form': add_form,
        'import_form': import_form,
        'current_tab': current_tab,
        'bell_slots': bell_slots,
        'days_of_week': days_of_week,
        'teacher_classes': teacher_classes,
        'teacher_subjects': teacher_subjects,
        'schedule_rows': schedule_rows,
        'total_scheduled_lessons': total_scheduled_lessons,
        'conducted_lessons': conducted_lessons_list,
        'lessons_page_obj': lessons_page_obj,
        'total_conducted_lessons_count': total_conducted_lessons_count,
        'published_conducted_lessons_count': published_conducted_lessons_count,
        'archived_conducted_lessons_count': archived_conducted_lessons_count,
        'lesson_status_filter': lesson_status_filter,
        'today_weekday': today_weekday,
        'today_weekday_name': today_weekday_name,
        'today_date_str': today_date_str,
        'today_time_str': today_time_str,
    })


@teacher_required
def teacher_student_edit(request, student_id):
    """
    Редагування профілю учня:
    - Зміна прізвища або імені (виправлення одруків)
    - Зміна класу учня з автоматичним перенесенням зданих робіт та журналу
    """
    student = get_object_or_404(Student, id=student_id)
    old_last_name = student.last_name
    old_first_name = student.first_name
    old_class_group = student.class_group

    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            updated_student = form.save()
            sync_subs = form.cleaned_data.get('sync_submissions', True)

            updated_subs_count = 0
            if sync_subs:
                updated_subs_count = updated_student.sync_submissions(
                    old_last_name=old_last_name,
                    old_first_name=old_first_name,
                    old_class_group=old_class_group
                )

            changes_desc = []
            if old_last_name != updated_student.last_name or old_first_name != updated_student.first_name:
                changes_desc.append(f"ПІБ змінено з «{old_last_name} {old_first_name}» на «{updated_student.get_full_name()}»")
            if old_class_group != updated_student.class_group:
                changes_desc.append(f"Клас змінено з {old_class_group.name if old_class_group else '—'} на {updated_student.class_group.name} (перенесено {updated_subs_count} робіт)")

            log_desc = "; ".join(changes_desc) or f"Оновлено дані учня {updated_student.get_full_name()}"
            log_submission_activity(request.user, 'student_updated', log_desc)

            if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.POST.get('format') == 'json':
                return JsonResponse({
                    'success': True,
                    'message': f"Профіль учня «{updated_student.get_full_name()}» успішно оновлено!",
                    'student': {
                        'id': updated_student.id,
                        'first_name': updated_student.first_name,
                        'last_name': updated_student.last_name,
                        'full_name': updated_student.get_full_name(),
                        'class_name': updated_student.class_group.name,
                        'class_id': updated_student.class_group.id,
                        'synced_subs_count': updated_subs_count,
                    }
                })

            messages.success(request, f"Профіль учня «{updated_student.get_full_name()}» успішно оновлено! {('Синхронізовано ' + str(updated_subs_count) + ' зданих робіт.') if updated_subs_count else ''}")
            return redirect(f"{reverse('teacher_students')}?class_group={updated_student.class_group_id}")
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.POST.get('format') == 'json':
                return JsonResponse({'success': False, 'errors': form.errors}, status=400)

    else:
        form = StudentForm(instance=student)

    return render(request, 'feed/teacher_student_edit.html', {
        'form': form,
        'student': student,
    })


@teacher_required
@require_POST
def teacher_student_delete(request, student_id):
    """Повне явне видалення профілю та його власних робіт за стабільним ID."""
    get_object_or_404(Student, id=student_id)
    from .student_deletion import delete_student
    class_id, st_name, class_name, count = delete_student(student_id, request.user)
    text = f'Учня «{st_name}» і його здачі ({count}) повністю видалено. Дію записано в журналі.'
    messages.success(request, text)
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({'success': True, 'message': text, 'deleted_submissions': count})

    return redirect(f"{reverse('teacher_students')}?class_group={class_id}")


@teacher_required
@require_POST
def teacher_student_merge(request):
    """
    Об'єднує два профілі учня (коли учень двічі здав роботу з різними або помилковими даними).
    Переприв'язує всі здані роботи, актуалізує спроби, об'єднує нотатки, видаляє дублікат
    та обов'язково фіксує дію у журналі подій.
    """
    source_id = request.POST.get('source_student_id')
    target_id = request.POST.get('target_student_id')

    if not source_id or not target_id:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.POST.get('format') == 'json':
            return JsonResponse({'success': False, 'error': "Не вказано учнів для об'єднання."}, status=400)
        messages.error(request, "Будь ласка, оберіть обох учнів для об'єднання.")
        return redirect('teacher_students')

    try:
        source_id = int(source_id)
        target_id = int(target_id)
    except (ValueError, TypeError):
        return JsonResponse({'success': False, 'error': "Некоректні ідентифікатори учнів."}, status=400)

    if source_id == target_id:
        err = "Неможливо об'єднати профіль учня із самим собою."
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.POST.get('format') == 'json':
            return JsonResponse({'success': False, 'error': err}, status=400)
        messages.error(request, err)
        return redirect('teacher_students')

    source_student = get_object_or_404(Student, id=source_id)
    target_student = get_object_or_404(Student, id=target_id)
    from .models import RosterReplica
    if RosterReplica.objects.filter(data__kind='class', data__native_id__in=[source_student.class_group_id, target_student.class_group_id]).exists():
        return JsonResponse({'success': False, 'error': 'Учні синхронізованого класу мають стабільні ID. Видалення чи об’єднання профілів із переприв’язуванням історії заблоковано. Використовуйте явне зіставлення ID або зняття активності.'}, status=409)

    source_name = source_student.get_full_name()
    target_name = target_student.get_full_name()
    source_class = source_student.class_group.name if source_student.class_group else '—'
    target_class = target_student.class_group.name if target_student.class_group else '—'

    # Знаходимо всі роботи дубліката
    source_subs = list(Submission.objects.filter(
        Q(student=source_student) |
        (Q(class_group=source_student.class_group) &
         Q(last_name__iexact=source_student.last_name) &
         Q(first_name__iexact=source_student.first_name))
    ))

    merged_subs_count = 0
    affected_assignments = set()

    for sub in source_subs:
        sub.student = target_student
        sub.last_name = target_student.last_name
        sub.first_name = target_student.first_name
        sub.class_group = target_student.class_group
        sub.save(update_fields=['student', 'last_name', 'first_name', 'class_group'])
        if sub.assignment_id:
            affected_assignments.add(sub.assignment_id)
        merged_subs_count += 1

    # Актуалізуємо is_latest_attempt для цільового учня в зачеплених завданнях
    for a_id in affected_assignments:
        user_subs = list(Submission.objects.filter(
            assignment_id=a_id, student=target_student
        ).order_by('submitted_at', 'id'))
        if user_subs:
            for s in user_subs[:-1]:
                if s.is_latest_attempt:
                    s.is_latest_attempt = False
                    s.save(update_fields=['is_latest_attempt'])
            if not user_subs[-1].is_latest_attempt:
                user_subs[-1].is_latest_attempt = True
                user_subs[-1].save(update_fields=['is_latest_attempt'])

    # Об'єднуємо нотатки вчителя
    if source_student.notes and source_student.notes.strip():
        if target_student.notes and target_student.notes.strip():
            target_student.notes += f"\n[Перенесено з об'єднаного профілю {source_name}]: {source_student.notes.strip()}"
        else:
            target_student.notes = source_student.notes.strip()
        target_student.save(update_fields=['notes'])

    # Видаляємо дублікат
    source_student.delete()

    log_msg = (f"Вчитель об'єднав дублікат учня «{source_name}» ({source_class}, ID {source_id}) "
               f"з основним профілем «{target_name}» ({target_class}, ID {target_id}). "
               f"Перенесено зданих робіт: {merged_subs_count}.")
    log_submission_activity(request.user, 'students_merged', log_msg)

    success_msg = f"Профіль «{source_name}» успішно об'єднано з «{target_name}». Перенесено робіт: {merged_subs_count}."
    messages.success(request, success_msg)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.POST.get('format') == 'json':
        return JsonResponse({
            'success': True,
            'message': success_msg,
            'merged_count': merged_subs_count,
            'target_student_id': target_id,
        })

    return redirect(f"{reverse('teacher_students')}?class_group={target_student.class_group_id}")


@teacher_required
def teacher_students_import(request):
    """
    Обробка імпорту списку учнів та класів з файлу або вставки тексту.
    """
    from .student_importer import import_students_from_file, import_students_from_text

    teacher = request.user.teacher_profile if hasattr(request.user, 'teacher_profile') else None

    if request.method == 'POST':
        form = StudentImportForm(request.POST, request.FILES)
        if form.is_valid():
            import_mode = form.cleaned_data.get('import_mode')
            default_class = form.cleaned_data.get('default_class')
            create_missing = form.cleaned_data.get('create_missing_classes', True)

            if import_mode == 'file':
                uploaded_file = form.cleaned_data.get('file')
                if not uploaded_file:
                    messages.error(request, "Будь ласка, оберіть файл для завантаження.")
                    return redirect('teacher_students')
                result = import_students_from_file(
                    uploaded_file,
                    default_class=default_class,
                    teacher=teacher,
                    create_missing_classes=create_missing
                )
            else:
                raw_text = form.cleaned_data.get('raw_text', '')
                if not raw_text.strip():
                    messages.error(request, "Будь ласка, вставте текст зі списком учнів.")
                    return redirect('teacher_students')
                result = import_students_from_text(
                    raw_text,
                    default_class=default_class,
                    teacher=teacher,
                    create_missing_classes=create_missing
                )

            created_cnt = result['created_count']
            existing_cnt = result['existing_count']
            created_classes = result['created_classes']
            errors = result['errors']

            cls_msg = f", створено класів: {len(created_classes)} ({', '.join(created_classes)})" if created_classes else ""
            msg = f"🎉 Імпорт завершено! Додано нових учнів: {created_cnt}, оновлено наявних: {existing_cnt}{cls_msg}."
            messages.success(request, msg)

            if errors:
                for err in errors[:5]:
                    messages.warning(request, err)

            log_submission_activity(
                request.user,
                'students_imported',
                f"Імпортовано учнів: {created_cnt} нових, {existing_cnt} оновлено{cls_msg}"
            )

            target_redirect = reverse('teacher_students')
            if default_class:
                target_redirect += f"?class_group={default_class.id}"
            elif result['students']:
                first_cls = result['students'][0].class_group_id
                target_redirect += f"?class_group={first_cls}"

            return redirect(target_redirect)
        else:
            for err_list in form.errors.values():
                for err in err_list:
                    messages.error(request, err)

    return redirect('teacher_students')


@teacher_required
def teacher_students_export(request):
    """
    Експорт списку учнів обраного класу (або всіх класів) у CSV файл.
    Підтримує кодування UTF-8 з BOM для коректного відкриття в Microsoft Excel.
    """
    selected_class_id = request.GET.get('class_group') or request.GET.get('class')
    students_qs = Student.objects.select_related('class_group').order_by('class_group__grade', 'class_group__letter', 'last_name', 'first_name')

    class_suffix = "all"
    if selected_class_id:
        try:
            cid = int(selected_class_id)
            students_qs = students_qs.filter(class_group_id=cid)
            cls_obj = ClassGroup.objects.filter(id=cid).first()
            if cls_obj:
                class_suffix = cls_obj.name.replace(' ', '_')
        except (ValueError, TypeError):
            pass

    response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
    filename = f"students_list_{class_suffix}_{timezone.now().strftime('%Y%m%d')}.csv"
    response['Content-Disposition'] = f'attachment; filename="{filename}"'

    writer = csv.writer(response, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    # Заголовки стовпчиків
    writer.writerow(['№', 'Клас', 'Прізвище', 'Імʼя', 'Повне ПІБ', 'Кількість зданих робіт', 'Нотатки'])

    for idx, st in enumerate(students_qs, 1):
        subs_count = st.get_submissions_count()
        writer.writerow([
            idx,
            st.class_group.name if st.class_group else '—',
            st.last_name,
            st.first_name,
            st.get_full_name(),
            subs_count,
            st.notes.replace('\n', ' ') if st.notes else ''
        ])

    return response


# ═══════════════════════════════════════════════════════════════════════════════
# ІСТОРІЯ УЧНЯ (STUDENT DETAIL)
# ═══════════════════════════════════════════════════════════════════════════════

@teacher_required
def student_detail(request, student_name):
    """
    Відображає повну історію робіт конкретного учня з урахуванням нечіткого зіставлення,
    різного порядку слів та пестливих/скорочених імен.
    """
    from .student_matcher import is_same_student_identity
    
    clean_target = student_name.replace('+', ' ').replace('_', ' ').strip()
    parts = clean_target.split()
    target_last = parts[0] if parts else clean_target
    target_first = " ".join(parts[1:]) if len(parts) > 1 else ""

    native_id = request.GET.get('student_id')
    if not native_id:
        # Legacy name URLs may navigate to a unique exact profile, but never
        # expose a destructive action for a fuzzy guess or an ambiguous name.
        profiles = Student.objects.filter(last_name__iexact=target_last, first_name__iexact=target_first)
        if not request.user.is_superuser:
            profiles = profiles.filter(class_group__in=request.user.teacher_profile.classes.all())
        exact = list(profiles[:2])
        if len(exact) == 1:
            return redirect(f"{reverse('student_detail', kwargs={'student_name': exact[0].get_full_name()})}?student_id={exact[0].pk}")

    all_subs = Submission.objects.all().select_related('assignment', 'class_group', 'teacher').prefetch_related('comments').order_by('-submitted_at')
    
    # Первинна фільтрація за коренем імені або прізвища
    initial_q = (
        Q(last_name__icontains=target_last[:4]) |
        Q(first_name__icontains=target_last[:4])
    )
    if target_first:
        initial_q |= (
            Q(last_name__icontains=target_first[:4]) |
            Q(first_name__icontains=target_first[:4])
        )
    candidate_subs = all_subs.filter(initial_q)
    if not candidate_subs.exists():
        candidate_subs = all_subs

    matched_ids = []
    for sub in candidate_subs:
        if is_same_student_identity(target_last, target_first, sub.last_name, sub.first_name):
            matched_ids.append(sub.id)

    if matched_ids:
        submissions = all_subs.filter(id__in=matched_ids)
    else:
        submissions = all_subs.filter(
            Q(last_name__icontains=target_last) | Q(first_name__icontains=target_last)
        )

    # Знаходимо відповідний профіль Student
    student_obj = None
    first_sub = submissions.first()
    target_class = first_sub.class_group if first_sub else None
    # New links use the stored pupil FK, preserving twins and moved pupils.
    if native_id:
        student_obj = get_object_or_404(Student, pk=int(native_id) if native_id.isdigit() else 0)
        if not request.user.is_superuser and not request.user.teacher_profile.classes.filter(pk=student_obj.class_group_id).exists():
            return HttpResponseForbidden('Немає доступу до цього учня.')
        submissions = all_subs.filter(student_id=student_obj.pk)
        if not request.user.is_superuser:
            submissions = submissions.filter(assignment__teacher=request.user.teacher_profile)
        target_class = student_obj.class_group
        target_last, target_first = student_obj.last_name, student_obj.first_name
    else:
        if not request.user.is_superuser:
            submissions = submissions.filter(assignment__teacher=request.user.teacher_profile)
        if not submissions.exists():
            raise Http404('Профіль учня або його роботи не знайдено.')
        from .models import RosterReplica
        shared_ids = [pk for pk in RosterReplica.objects.filter(data__kind='class').values_list('data__native_id', flat=True) if pk is not None]
        if submissions.filter(class_group_id__in=shared_ids).exists():
            return HttpResponse('Для синхронізованого класу відкрийте профіль учня за ID зі списку робіт.', status=409)

    paginator = Paginator(submissions, 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    display_name = f"{target_last} {target_first}".strip()

    return render(request, 'feed/student_detail.html', {
        'page_obj': page_obj,
        'student_name': display_name,
        'raw_student_name': student_name,
        'student_obj': student_obj,
        'target_class': target_class,
    })


# ═══════════════════════════════════════════════════════════════════════════════
# ЕЛЕКТРОННИЙ ЖУРНАЛ ОЦІНОК ТА ЕКСПОРТ (GRADEBOOK & EXPORT)
# ═══════════════════════════════════════════════════════════════════════════════

@teacher_required
def gradebook(request):
    """
    Електронний журнал оцінок:
    - Матриця оцінок (Учні × Дати/Завдання) по обраному класу
    - Загальна таблиця всіх виставлених оцінок
    """
    teacher = request.user.teacher_profile

    if request.user.is_superuser:
        class_groups = list(teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter'))
    else:
        class_groups = list(teaching_classes(teacher.classes.all()).order_by('grade', 'letter'))

    selected_class_id = request.GET.get('class_group') or request.GET.get('class')
    view_mode = request.GET.get('view')

    if view_mode == 'all_grades':
        from django.db.models.functions import Coalesce
        all_subs = Submission.objects.filter(
            grade__isnull=False
        ).exclude(
            grade=''
        ).select_related(
            'assignment', 'class_group', 'teacher'
        ).annotate(
            sort_date=Coalesce('graded_at', 'submitted_at')
        ).order_by('-sort_date', '-submitted_at')

        if selected_class_id:
            all_subs = all_subs.filter(class_group_id=selected_class_id)
        elif not request.user.is_superuser:
            all_subs = all_subs.filter(Q(assignment__teacher=teacher) | Q(teacher=teacher))

        paginator = Paginator(all_subs, 25)
        page_obj = paginator.get_page(request.GET.get('page'))

        return render(request, 'feed/gradebook_all.html', {
            'page_obj': page_obj,
            'class_groups': class_groups,
            'selected_class_id': selected_class_id,
        })

    for cls in class_groups:
        cls.selected = (str(cls.id) == str(selected_class_id))

    if not selected_class_id:
        return render(request, 'feed/gradebook.html', {
            'class_groups': class_groups,
            'selected_class': None,
        })

    try:
        selected_class = ClassGroup.objects.get(id=selected_class_id)
    except ClassGroup.DoesNotExist:
        selected_class = None

    submissions = Submission.objects.filter(
        class_group_id=selected_class_id
    ).select_related('assignment', 'teacher').order_by('last_name', 'first_name', 'submitted_at')

    # Інтелектуальне групування учнів у журналі
    from .student_matcher import cluster_submissions_by_student
    clusters = cluster_submissions_by_student(submissions)

    dates = set()
    date_assignments = {}
    for sub in submissions:
        d = sub.effective_grade_date
        dates.add(d)
        if sub.assignment:
            if d not in date_assignments:
                date_assignments[d] = []
            if sub.assignment.title not in date_assignments[d]:
                date_assignments[d].append(sub.assignment.title)

    sorted_dates = sorted(dates)

    # ── Фільтрація діапазону оцінок та дат ────────────────────────────────────
    import datetime

    date_from_str = request.GET.get('date_from', '').strip()
    date_to_str = request.GET.get('date_to', '').strip()
    single_date_str = request.GET.get('single_date', '').strip()
    grade_filter = request.GET.get('grade_filter', '').strip()
    date_preset = request.GET.get('date_preset', '').strip()

    today_date = timezone.localtime(timezone.now()).date()

    if date_preset == 'today':
        single_date_str = today_date.strftime('%Y-%m-%d')
    elif date_preset == 'week':
        start_week = today_date - datetime.timedelta(days=today_date.weekday())
        date_from_str = start_week.strftime('%Y-%m-%d')
        date_to_str = today_date.strftime('%Y-%m-%d')
    elif date_preset == 'month':
        start_month = today_date.replace(day=1)
        date_from_str = start_month.strftime('%Y-%m-%d')
        date_to_str = today_date.strftime('%Y-%m-%d')

    parsed_single_date = None
    if single_date_str:
        try:
            parsed_single_date = datetime.datetime.strptime(single_date_str, '%Y-%m-%d').date()
        except ValueError:
            try:
                parsed_single_date = datetime.datetime.strptime(single_date_str, '%d.%m.%Y').date()
            except ValueError:
                parsed_single_date = None

    parsed_date_from = None
    if date_from_str:
        try:
            parsed_date_from = datetime.datetime.strptime(date_from_str, '%Y-%m-%d').date()
        except ValueError:
            try:
                parsed_date_from = datetime.datetime.strptime(date_from_str, '%d.%m.%Y').date()
            except ValueError:
                parsed_date_from = None

    parsed_date_to = None
    if date_to_str:
        try:
            parsed_date_to = datetime.datetime.strptime(date_to_str, '%Y-%m-%d').date()
        except ValueError:
            try:
                parsed_date_to = datetime.datetime.strptime(date_to_str, '%d.%m.%Y').date()
            except ValueError:
                parsed_date_to = None

    # Відбираємо дати згідно з фільтрами
    filtered_dates = []
    for d in sorted_dates:
        if parsed_single_date and d != parsed_single_date:
            continue
        if parsed_date_from and d < parsed_date_from:
            continue
        if parsed_date_to and d > parsed_date_to:
            continue
        filtered_dates.append(d)

    view_mode = request.GET.get('view_mode', 'journal')
    if view_mode not in ('journal', 'table'):
        view_mode = 'journal'
    journal_paginator = Paginator(filtered_dates, 15)
    try:
        page_number = int(request.GET.get('journal_page', journal_paginator.num_pages))
    except (ValueError, TypeError):
        page_number = journal_paginator.num_pages
    journal_page = journal_paginator.get_page(max(1, min(page_number, journal_paginator.num_pages)))
    displayed_dates = list(journal_page) if view_mode == 'journal' else filtered_dates
    displayed_date_set = set(displayed_dates)

    def journal_page_url(number):
        params = request.GET.copy()
        params['class_group'] = str(selected_class_id)
        params['view_mode'] = 'journal'
        params['journal_page'] = str(number)
        return '?' + params.urlencode()

    journal_page_links = [
        {'label': str(number), 'url': journal_page_url(number), 'current': number == journal_page.number}
        if isinstance(number, int) else {'label': str(number), 'url': None, 'current': False}
        for number in journal_paginator.get_elided_page_range(journal_page.number, on_each_side=1, on_ends=1)
    ]

    def match_grade_filter(item, g_filt):
        if not g_filt or g_filt == 'all':
            return True
        val = str(item.get('grade', '')).strip().lower()
        if g_filt == '10-12':
            return val in ['10', '11', '12']
        elif g_filt == '7-9':
            return val in ['7', '8', '9']
        elif g_filt == '4-6':
            return val in ['4', '5', '6']
        elif g_filt == '1-3':
            return val in ['1', '2', '3']
        elif g_filt == 'rework':
            return val in ['доопрацювати', 'на доопрацювання', 'д']
        elif g_filt == 'ungraded':
            return (not item.get('has_grade') or val == '') and item.get('is_latest_attempt', True)
        return True

    has_active_filter = bool(parsed_single_date or parsed_date_from or parsed_date_to or (grade_filter and grade_filter != 'all') or date_preset)

    student_list = []
    class_all_numeric_grades = []

    for cl in clusters:
        cells = []
        legacy_grade_list = []
        student_matching_items_count = 0
        student_numeric_grades = []

        for d in filtered_dates:
            raw_items = cl['grades_by_date'].get(d, [])
            filtered_items = [it for it in raw_items if match_grade_filter(it, grade_filter)]
            if d in displayed_date_set:
                cells.append({'date': d, 'items': filtered_items})
            for it in filtered_items:
                if it.get('grade'):
                    legacy_grade_list.append([it['grade']])
                    if str(it['grade']).isdigit():
                        student_numeric_grades.append(int(it['grade']))
                student_matching_items_count += 1

        if grade_filter and grade_filter != 'all' and student_matching_items_count == 0:
            continue

        avg_score = None
        if student_numeric_grades:
            avg_score = round(sum(student_numeric_grades) / len(student_numeric_grades), 1)
            class_all_numeric_grades.extend(student_numeric_grades)
        elif not has_active_filter and cl['numeric_grades']:
            avg_score = round(sum(cl['numeric_grades']) / len(cl['numeric_grades']), 1)
            class_all_numeric_grades.extend(cl['numeric_grades'])

        student_list.append({
            'last_name': cl['last_name'],
            'first_name': cl['first_name'],
            'full_name': cl['full_name'],
            'name_key': cl['name_key'],
            'cells': cells,
            'grades': legacy_grade_list,
            'avg_score': avg_score,
            'total_submissions': cl['all_submissions_count'],
            'submissions_count': cl['all_submissions_count'],
            'graded_count': len(student_numeric_grades) if has_active_filter else len(cl['numeric_grades']),
            'grades_count': len(student_numeric_grades) if has_active_filter else len(cl['numeric_grades']),
        })

    class_avg = round(sum(class_all_numeric_grades) / len(class_all_numeric_grades), 1) if class_all_numeric_grades else None

    dates_meta = []
    for d in displayed_dates:
        titles = date_assignments.get(d, [])
        title_str = ", ".join(titles) if titles else f"Заняття {d.strftime('%d.%m.%Y')}"
        dates_meta.append({
            'date': d,
            'title': title_str,
        })


    return render(request, 'feed/gradebook.html', {
        'class_groups': class_groups,
        'selected_class': selected_class,
        'selected_class_id': selected_class_id,
        'students': student_list,
        'student_list': student_list,
        'dates': displayed_dates,
        'sorted_dates': displayed_dates,
        'all_available_dates': sorted_dates,
        'dates_meta': dates_meta,
        'journal_page': journal_page,
        'journal_dates_count': len(filtered_dates),
        'journal_page_links': journal_page_links,
        'journal_previous_url': journal_page_url(journal_page.previous_page_number()) if journal_page.has_previous() else None,
        'journal_next_url': journal_page_url(journal_page.next_page_number()) if journal_page.has_next() else None,
        'date_assignments': {d: ", ".join(titles) for d, titles in date_assignments.items()},
        'class_avg': class_avg,
        'view_mode': view_mode,
        'total_submissions': len(submissions),
        'total_graded': len(class_all_numeric_grades),
        'single_date': single_date_str,
        'date_from': date_from_str,
        'date_to': date_to_str,
        'grade_filter': grade_filter,
        'date_preset': date_preset,
        'has_active_filter': has_active_filter,
    })




@teacher_required
def export_grades(request):
    """
    Експорт оцінок у формат CSV з кодуванням UTF-8-sig для коректного відкриття в Excel.
    """
    class_group_id = request.GET.get('class_group')
    teacher = request.user.teacher_profile

    submissions = Submission.objects.filter(grade__isnull=False).exclude(grade='').select_related('assignment', 'class_group', 'teacher').order_by('class_group__grade', 'class_group__letter', 'last_name', 'submitted_at')

    if not request.user.is_superuser:
        submissions = submissions.filter(Q(assignment__teacher=teacher) | Q(teacher=teacher))

    filename = 'grades.csv'

    if class_group_id:
        try:
            selected_class = ClassGroup.objects.get(id=class_group_id)
            submissions = submissions.filter(class_group_id=class_group_id)
            filename = f'grades_{selected_class.name}.csv'
        except ClassGroup.DoesNotExist:
            pass

    response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'

    import csv
    writer = csv.writer(response)
    writer.writerow(['Прізвище', "Ім'я", 'Клас', 'Завдання', 'Дата завдання', 'Вчитель', 'Дата здачі', 'Дата оцінювання', 'Оцінка'])

    for sub in submissions:
        assignment_title = sub.assignment.title if sub.assignment else '-'
        teacher_name = sub.teacher.full_name if sub.teacher else (sub.assignment.teacher.full_name if sub.assignment else '-')
        graded_at_str = timezone.localtime(sub.graded_at).strftime('%d.%m.%Y %H:%M') if sub.graded_at else ''
        assign_date_str = sub.effective_grade_date.strftime('%d.%m.%Y')
        writer.writerow([
            sub.last_name,
            sub.first_name,
            sub.class_group.name if sub.class_group else '',
            assignment_title,
            assign_date_str,
            teacher_name,
            timezone.localtime(sub.submitted_at).strftime('%d.%m.%Y %H:%M'),
            graded_at_str,
            sub.grade
        ])

    return response


# ═══════════════════════════════════════════════════════════════════════════════
# ЗВІТИ ВЧИТЕЛЯ ТА ЖУРНАЛ ЗАМІНИ (REPORTS & PDF EXPORT)
# ═══════════════════════════════════════════════════════════════════════════════

@teacher_required
def teacher_reports(request):
    """
    Панель формування звітів вчителя та відомостей для журналу / замін.
    Дозволяє обирати учнів, класи, часовий діапазон, переглядати зведену таблицю
    та експортувати результати у PDF (як лише оцінки, так і з роботами).
    """
    teacher = getattr(request.user, 'teacher_profile', None)

    from .reports_service import get_report_submissions, get_report_assignments, report_filters_from_request
    filters = report_filters_from_request(request)
    class_id, assignment_id = filters['class_id'], filters['assignment_id']
    target_teacher, scope = filters['target_teacher'], filters['scope']

    classes = teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter')
    class_names = {c.pk: c.name for c in classes}
    assignments_qs = get_report_assignments(request.user, filters)
    assignments = list(assignments_qs[:200])
    try:
        aid = int(assignment_id)
        if 0 < aid <= 9223372036854775807 and not any(a.pk == aid for a in assignments):
            selected = assignments_qs.filter(pk=aid).first()
            if selected:
                assignments.append(selected)
    except (ValueError, TypeError):
        pass

    # Include classes of accessible historical/substitution works in topic labels.
    work_classes = {}
    accessible = get_report_submissions(request.user, {'scope': scope, 'graded_only': '0'})
    for row in accessible.filter(assignment_id__in=[a.pk for a in assignments]).values(
            'assignment_id', 'class_group_id'):
        cid = row['class_group_id']
        if cid:
            work_classes.setdefault(row['assignment_id'], set()).add(cid)
    for a in assignments:
        c_ids = {c.pk for c in a.classes.all()} | work_classes.get(a.pk, set())
        a.class_ids_str = ','.join(map(str, sorted(c_ids)))
        a.class_names_str = ', '.join(class_names[cid] for cid in sorted(c_ids) if cid in class_names)

    submissions = get_report_submissions(request.user, filters)

    # Підрахунок статистики
    grades_nums = []
    for s in submissions:
        if s.grade:
            try:
                val = float(s.grade.replace(',', '.').strip())
                grades_nums.append(val)
            except ValueError:
                pass

    avg_grade = round(sum(grades_nums) / len(grades_nums), 1) if grades_nums else None
    high_cnt = sum(1 for g in grades_nums if g >= 10)
    good_cnt = sum(1 for g in grades_nums if 7 <= g < 10)
    avg_cnt = sum(1 for g in grades_nums if 4 <= g < 7)
    low_cnt = sum(1 for g in grades_nums if g < 4)

    other_teachers = Teacher.objects.all()
    if teacher:
        other_teachers = other_teachers.exclude(id=teacher.id)
    other_teachers = other_teachers.order_by('full_name')

    school = School.objects.first()

    context = {
        'teacher': teacher,
        'submissions': submissions,
        'classes': classes,
        'assignments': assignments,
        'other_teachers': other_teachers,
        'school': school,
        'filters': filters,
        'selected_assignment_unavailable': assignment_id != 'all' and not any(str(a.pk) == assignment_id for a in assignments),
        'stats': {
            'total_count': len(submissions),
            'grades_count': len(grades_nums),
            'avg_grade': avg_grade,
            'high_cnt': high_cnt,
            'good_cnt': good_cnt,
            'avg_cnt': avg_cnt,
            'low_cnt': low_cnt,
        }
    }
    return render(request, 'feed/teacher_reports.html', context)


@teacher_required
def teacher_reports_pdf(request):
    """
    Генерація та завантаження PDF-звіту оцінок.
    Підтримує вибір режиму: 'grades_only' (тільки зведена таблиця для журналу)
    або 'detailed' (з роботами, коментарями та перевіркою ШІ).
    """
    teacher = getattr(request.user, 'teacher_profile', None)
    teacher_name = teacher.full_name if teacher else request.user.get_full_name() or request.user.username

    from .reports_service import get_report_submissions, get_report_assignments, generate_teacher_report_pdf, report_filters_from_request
    filters = report_filters_from_request(request)
    class_id, assignment_id = filters['class_id'], filters['assignment_id']
    pupil_scope = filters['pupil_scope']
    date_from, date_to = filters['date_from'], filters['date_to']
    target_teacher = filters['target_teacher']
    report_title, report_notes = filters['report_title'], filters['report_notes']
    mode = request.GET.get('mode', 'grades_only')
    submissions = get_report_submissions(request.user, filters)

    classes_str = 'Всі класи'
    if class_id != 'all':
        try:
            cid = int(class_id)
            cg = ClassGroup.objects.filter(pk=cid).first() if 0 < cid <= 9223372036854775807 else None
            classes_str = cg.name if cg else 'Невідомий клас'
        except (ValueError, TypeError):
            classes_str = 'Невідомий клас'
    elif submissions:
        unique_classes = sorted({s.class_group.name for s in submissions if s.class_group})
        if unique_classes:
            classes_str = ', '.join(unique_classes)

    subject_name = ''
    if assignment_id != 'all':
        try:
            aid = int(assignment_id)
            assign = get_report_assignments(request.user, filters).filter(pk=aid).first() if 0 < aid <= 9223372036854775807 else None
            if assign and assign.subject:
                subject_name = assign.subject.name
        except (ValueError, TypeError):
            pass

    date_range_str = "Весь період"
    if date_from and date_to:
        date_range_str = f"{date_from} — {date_to}"
    elif date_from:
        date_range_str = f"з {date_from}"
    elif date_to:
        date_range_str = f"до {date_to}"

    school = School.objects.first()
    school_name = school.name if school else "Шкільний портал"

    report_meta = {
        'title': report_title or ("ВІДОМІСТЬ ОЦІНОК / ЖУРНАЛ ЗАМІНИ УРОКІВ" if target_teacher else "ЗВІТ ПРО ОЦІНЮВАННЯ НАВЧАЛЬНИХ ДОСЯГНЕНЬ"),
        'teacher_name': teacher_name,
        'target_teacher': target_teacher,
        'subject_name': subject_name,
        'date_range_str': date_range_str,
        'classes_str': ('Позакласні учні — ' + classes_str) if pupil_scope == 'outside' else classes_str,
        'notes': report_notes,
        'school_name': school_name,
    }

    import io
    buffer = io.BytesIO()
    generate_teacher_report_pdf(buffer, report_meta, list(submissions), mode=mode)
    buffer.seek(0)

    filename = f"zvit_otsinok_{timezone.now().strftime('%Y%m%d_%H%M')}.pdf"
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


# ═══════════════════════════════════════════════════════════════════════════════
# ЖУРНАЛ ДІЙ ТА АВТОАРХІВАЦІЯ ЛОГІВ (ACTIVITY LOG)
# ═══════════════════════════════════════════════════════════════════════════════

def archive_old_activity_logs(days=30):
    """Архівує логи старші за 30 днів у файл на диску та видаляє їх з БД."""
    from datetime import timedelta
    cutoff_date = timezone.now() - timedelta(days=days)
    old_logs = list(SubmissionActivityLog.objects.filter(timestamp__lt=cutoff_date).order_by('timestamp'))

    if not old_logs:
        return 0, None

    from django.conf import settings
    logs_dir = os.path.join(settings.MEDIA_ROOT, 'logs_archives')
    os.makedirs(logs_dir, exist_ok=True)

    min_date = old_logs[0].timestamp.strftime("%Y%m%d")
    max_date = old_logs[-1].timestamp.strftime("%Y%m%d")
    filename = f"Архів_логів_{min_date}_{max_date}.csv"
    filepath = os.path.join(logs_dir, filename)

    if os.path.exists(filepath):
        filename = f"Архів_логів_{min_date}_{max_date}_{int(timezone.now().timestamp())}.csv"
        filepath = os.path.join(logs_dir, filename)

    rows = [["ID", "Час", "Користувач", "Тип дії", "Опис", "ID роботи"]]
    for log in old_logs:
        rows.append([
            str(log.id),
            timezone.localtime(log.timestamp).strftime("%d.%m.%Y %H:%M:%S"),
            log.actor.username if log.actor else "Гість / Учень",
            log.get_action_type_display(),
            log.description,
            str(log.submission_id or "-")
        ])

    import io, csv
    csv_buffer = io.StringIO()
    csv_writer = csv.writer(csv_buffer)
    for row in rows:
        csv_writer.writerow(row)

    with open(filepath, 'w', encoding='utf-8-sig') as f:
        f.write(csv_buffer.getvalue())

    log_ids = [l.id for l in old_logs]
    SubmissionActivityLog.objects.filter(id__in=log_ids).delete()

    return len(old_logs), filename


def get_logs_archives_list():
    """Повертає список збережених CSV-архівів логів на диску."""
    from django.conf import settings
    logs_dir = os.path.join(settings.MEDIA_ROOT, 'logs_archives')
    archives_list = []
    if os.path.exists(logs_dir):
        for f in sorted(os.listdir(logs_dir), reverse=True):
            if f.endswith('.csv'):
                fpath = os.path.join(logs_dir, f)
                fsize = os.path.getsize(fpath)
                mtime = datetime.fromtimestamp(os.path.getmtime(fpath))
                archives_list.append({
                    'filename': f,
                    'size': f"{round(fsize/1024, 1)} КБ" if fsize > 1024 else f"{fsize} Б",
                    'date': mtime.strftime("%d.%m.%Y %H:%M"),
                })
    return archives_list


@teacher_required
def activity_log(request):
    """
    Журнал дій системи та перегляд архівів на диску.
    """
    logs_qs = SubmissionActivityLog.objects.all().select_related('actor', 'submission').order_by('-timestamp')

    action_type = request.GET.get('action_type')
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')

    if action_type:
        logs_qs = logs_qs.filter(action_type=action_type)

    if date_from:
        try:
            from datetime import datetime as dt
            df = dt.strptime(date_from, '%Y-%m-%d')
            logs_qs = logs_qs.filter(timestamp__gte=df)
        except Exception:
            pass

    if date_to:
        try:
            from datetime import datetime as dt
            dt_obj = dt.strptime(date_to, '%Y-%m-%d') + timedelta(days=1)
            logs_qs = logs_qs.filter(timestamp__lt=dt_obj)
        except Exception:
            pass

    total_logs_count = SubmissionActivityLog.objects.count()
    paginator = Paginator(logs_qs, 25)
    page_obj = paginator.get_page(request.GET.get('page'))

    logs_archives = get_logs_archives_list()

    action_choices = [
        {'code': 'submission', 'name': 'Здача роботи', 'selected': action_type == 'submission'},
        {'code': 'grading', 'name': 'Оцінювання', 'selected': action_type == 'grading'},
        {'code': 'comment', 'name': 'Коментар', 'selected': action_type == 'comment'},
        {'code': 'login', 'name': 'Вхід в систему', 'selected': action_type == 'login'},
        {'code': 'delete', 'name': 'Видалення', 'selected': action_type == 'delete'},
    ]

    return render(request, 'feed/activity_log.html', {
        'page_obj': page_obj,
        'total_logs_count': total_logs_count,
        'logs_archives': logs_archives,
        'action_choices': action_choices,
        'action_type': action_type,
        'date_from': date_from,
        'date_to': date_to,
        'is_superadmin': request.user.is_superuser,
    })


@teacher_required
@require_POST
def trigger_log_archive(request):
    """Ручний запуск архівації старих логів."""
    if not request.user.is_superuser:
        messages.error(request, "Тільки адміністратор може запускати архівацію логів.")
        return redirect('activity_log')

    count, filename = archive_old_activity_logs(days=30)
    if count > 0:
        messages.success(request, f"Успішно заархівовано {count} старих логів у файл: {filename}")
    else:
        messages.info(request, "Немає логів старших за 30 днів для архівації.")

    return redirect('activity_log')


@teacher_required
def view_log_archive(request, filename):
    """Перегляд вмісту CSV-архіву логів у вигляді HTML-таблиці."""
    from django.conf import settings
    safe_filename = os.path.basename(filename)
    filepath = os.path.join(settings.MEDIA_ROOT, 'logs_archives', safe_filename)

    if not os.path.exists(filepath):
        messages.error(request, "Файл архіву не знайдено.")
        return redirect('activity_log')

    rows = []
    try:
        import csv
        with open(filepath, 'r', encoding='utf-8-sig', errors='ignore') as f:
            reader = csv.reader(f)
            rows = list(reader)
    except Exception as e:
        messages.error(request, f"Помилка читання архіву: {str(e)}")
        return redirect('activity_log')

    headers = rows[0] if rows else []
    data_rows = rows[1:] if len(rows) > 1 else []

    return render(request, 'feed/log_archive_viewer.html', {
        'filename': safe_filename,
        'headers': headers,
        'rows': data_rows,
        'total_rows': len(data_rows),
    })


@teacher_required
def download_log_archive(request, filename):
    """Завантаження CSV-архіву логів."""
    from django.conf import settings
    safe_filename = os.path.basename(filename)
    filepath = os.path.join(settings.MEDIA_ROOT, 'logs_archives', safe_filename)

    if os.path.exists(filepath):
        from django.http import FileResponse
        return FileResponse(open(filepath, 'rb'), as_attachment=True, filename=safe_filename)

    messages.error(request, "Файл не знайдено.")
    return redirect('activity_log')


# ═══════════════════════════════════════════════════════════════════════════════
# КЕРУВАННЯ ЗАКЛАДОМ ТА ВЧИТЕЛЯМИ (TEACHER PROFILES & SUPERADMIN)
# ═══════════════════════════════════════════════════════════════════════════════

def get_master_school_archive_info():
    """Повертає метадані єдиного централізованого ZIP-архіву школи на диску."""
    from django.conf import settings
    import zipfile
    master_zip_path = os.path.join(settings.MEDIA_ROOT, 'school_archives', "Архів_робіт_школи.zip")
    if os.path.exists(master_zip_path):
        f_size = os.path.getsize(master_zip_path)
        f_time = datetime.fromtimestamp(os.path.getmtime(master_zip_path))
        files_count = 0
        try:
            with zipfile.ZipFile(master_zip_path, 'r') as zf:
                files_count = len([m for m in zf.namelist() if not m.endswith('/') and m != 'список_всіх_робіт.csv'])
        except Exception:
            pass
        return {
            'name': 'Архів_робіт_школи.zip',
            'url': f"{settings.MEDIA_URL}school_archives/Архів_робіт_школи.zip",
            'size': f"{round(f_size / (1024 * 1024), 2)} МБ" if f_size > 1048576 else f"{round(f_size / 1024, 1)} КБ",
            'date': f_time.strftime("%d.%m.%Y %H:%M"),
            'files_count': files_count
        }
    return None


def archive_submissions_to_master_zip(teacher_name, teacher_submissions):
    """Зберігає роботи в єдиний централізований накопичувальний архів школи."""
    from django.conf import settings
    import zipfile, io, csv
    archives_dir = os.path.join(settings.MEDIA_ROOT, 'school_archives')
    os.makedirs(archives_dir, exist_ok=True)
    master_zip_path = os.path.join(archives_dir, "Архів_робіт_школи.zip")
    temp_zip_path = os.path.join(archives_dir, "Архів_робіт_школи.tmp.zip")

    existing_members = set()
    existing_summary_rows = []

    if os.path.exists(master_zip_path):
        try:
            with zipfile.ZipFile(master_zip_path, 'r') as old_zip:
                for item in old_zip.infolist():
                    existing_members.add(item.filename)
                if "список_всіх_робіт.csv" in existing_members:
                    csv_content = old_zip.read("список_всіх_робіт.csv").decode('utf-8-sig', errors='ignore')
                    csv_reader = csv.reader(csv_content.splitlines())
                    existing_summary_rows = list(csv_reader)
        except Exception:
            pass

    if not existing_summary_rows:
        existing_summary_rows = [
            ["Прізвище", "Ім'я", "Клас", "Вчитель", "Дата здачі", "Оцінка", "Файл/Посилання", "Коментарі", "Дата архівації"]
        ]

    archived_at_str = timezone.localtime(timezone.now()).strftime("%d.%m.%Y %H:%M")
    files_to_delete = []

    with zipfile.ZipFile(temp_zip_path, 'w', zipfile.ZIP_DEFLATED) as new_zip:
        if os.path.exists(master_zip_path):
            with zipfile.ZipFile(master_zip_path, 'r') as old_zip:
                for item in old_zip.infolist():
                    if item.filename != "список_всіх_робіт.csv":
                        with old_zip.open(item) as source, new_zip.open(item, 'w', force_zip64=True) as target:
                            shutil.copyfileobj(source, target, length=64 * 1024)

        for sub in teacher_submissions:
            comments_list = [f"{c.get_author_name()}: {c.text}" for c in sub.comments.all()]
            comments_str = " | ".join(comments_list)
            work_item = os.path.basename(sub.file.name) if sub.file else (sub.link or '')
            existing_summary_rows.append([
                sub.last_name,
                sub.first_name,
                sub.class_group.name if sub.class_group else "-",
                teacher_name,
                timezone.localtime(sub.submitted_at).strftime("%d.%m.%Y %H:%M"),
                sub.grade or "-",
                work_item,
                comments_str,
                archived_at_str
            ])
            if sub.file:
                try:
                    if os.path.exists(sub.file.path):
                        file_path = sub.file.path
                        files_to_delete.append(file_path)
                        safe_teacher = "".join(c for c in teacher_name if c.isalnum() or c in (' ', '_', '-')).strip().replace(' ', '_')
                        class_name = sub.class_group.name if sub.class_group else "Загальні"
                        arcname = f"{safe_teacher}/{class_name}/{sub.last_name}_{sub.first_name}/{os.path.basename(file_path)}"
                        
                        counter = 1
                        orig_arcname = arcname
                        while arcname in existing_members:
                            name_part, ext_part = os.path.splitext(orig_arcname)
                            arcname = f"{name_part}_{counter}{ext_part}"
                            counter += 1
                        new_zip.write(file_path, arcname)
                        existing_members.add(arcname)
                except Exception:
                    pass

        csv_buffer = io.StringIO()
        csv_writer = csv.writer(csv_buffer)
        for row in existing_summary_rows:
            csv_writer.writerow(row)
        new_zip.writestr("список_всіх_робіт.csv", "\ufeff" + csv_buffer.getvalue())

    if os.path.exists(master_zip_path):
        os.remove(master_zip_path)
    os.rename(temp_zip_path, master_zip_path)

    return master_zip_path, files_to_delete


@teacher_required
def enter_superadmin_mode(request):

    if not request.user.is_superuser:
        messages.error(request, "У вас немає прав супер-адміністратора.")
        return redirect('teacher_profiles')

    request.session['superadmin_mode'] = True
    messages.warning(request, "👑 РЕЖИМ СУПЕР-АДМІНІСТРАТОРА АКТИВОВАНО.")
    return redirect(request.META.get('HTTP_REFERER') or 'teacher_profiles')


@teacher_required
def exit_superadmin_mode(request):
    if 'superadmin_mode' in request.session:
        request.session['superadmin_mode'] = False
    messages.info(request, "Ви вийшли з режиму супер-адміністратора.")
    return redirect(request.META.get('HTTP_REFERER') or 'teacher_dashboard')


@teacher_required
def teacher_profiles_view(request):
    """
    Сумісність: делегування до Єдиного Центру Налаштувань (вкладка Середовище та заклад).
    """
    if request.method == 'GET':
        q = request.GET.copy()
        q['tab'] = 'environment'
        request.GET = q
    return teacher_settings_view(request)


@teacher_required
def teacher_profile_edit(request, profile_id):
    is_superadmin_mode = request.user.is_superuser and request.session.get('superadmin_mode', False)
    teacher_obj = get_object_or_404(Teacher, id=profile_id)

    if not is_superadmin_mode and teacher_obj.user != request.user:
        messages.error(request, "У вас немає прав редагувати цей профіль.")
        return redirect('teacher_profiles')

    if request.method == 'POST':
        form = TeacherProfileForm(request.POST, request.FILES, instance=teacher_obj)
        if form.is_valid():
            form.save()
            messages.success(request, f"Профіль вчителя «{teacher_obj.full_name}» оновлено!")
            return redirect('teacher_profiles')
    else:
        form = TeacherProfileForm(instance=teacher_obj)

    return render(request, 'feed/teacher_profile_edit.html', {
        'form': form,
        'teacher_obj': teacher_obj,
    })


@teacher_required
@require_POST
def teacher_profile_delete(request, profile_id):
    if not request.user.is_superuser:
        messages.error(request, "Тільки супер-адміністратор може видаляти профілі.")
        return redirect('teacher_profiles')

    teacher_obj = get_object_or_404(Teacher, id=profile_id)
    t_name = teacher_obj.full_name
    linked_user = teacher_obj.user

    teacher_submissions = list(
        Submission.objects.filter(
            Q(teacher=teacher_obj) | Q(assignment__teacher=teacher_obj)
        ).distinct().select_related('class_group', 'teacher')
    )

    submissions_count = len(teacher_submissions)
    master_zip_path, files_to_delete = archive_submissions_to_master_zip(t_name, teacher_submissions)

    for fpath in files_to_delete:
        try:
            if os.path.exists(fpath):
                os.remove(fpath)
        except Exception:
            pass

    if submissions_count > 0:
        Submission.objects.filter(id__in=[s.id for s in teacher_submissions]).delete()

    teacher_obj.delete()
    if linked_user and not linked_user.is_superuser and linked_user != request.user:
        linked_user.delete()

    log_submission_activity(
        request.user,
        'delete',
        f"Супер-адмін видалив вчителя '{t_name}'. {submissions_count} робіт заархівовано в Архів_робіт_школи.zip"
    )
    messages.success(
        request,
        f"Акаунт вчителя «{t_name}» видалено. {submissions_count} робіт надійно збережено в архів школи."
    )
    return redirect('teacher_profiles')


@teacher_required
@require_POST
def toggle_superadmin(request, user_id):
    if not request.user.is_superuser:
        messages.error(request, "Тільки супер-адміністратор може змінювати права.")
        return redirect('teacher_profiles')

    target_user = get_object_or_404(User, id=user_id)
    if target_user == request.user and target_user.is_superuser:
        messages.warning(request, "Ви не можете зняти права супер-адміністратора із себе.")
        return redirect('teacher_profiles')

    target_user.is_superuser = not target_user.is_superuser
    target_user.is_staff = True
    target_user.save()

    status_str = "призначено супер-адміністратором школи" if target_user.is_superuser else "переведено у звичайні вчителі"
    messages.success(request, f"Користувача «{target_user.username}» {status_str}!")
    return redirect('teacher_profiles')


@teacher_required
@require_POST
def school_settings(request):
    if not request.user.is_superuser:
        messages.error(request, "Тільки супер-адміністратор може змінювати налаштування закладу.")
        return redirect('teacher_profiles')

    school = School.objects.first()
    if not school:
        school = School.objects.create(name="Наш Заклад Освіти", admin=request.user)

    school_name = request.POST.get('school_name', '').strip()
    if school_name:
        school.name = school_name
        school.admin = request.user
        school.save()
        messages.success(request, f"Назву закладу успішно оновлено: «{school_name}»!")

    return redirect(f"{reverse('teacher_settings')}?tab=environment")


# ═══════════════════════════════════════════════════════════════════════════════
# НОВІ СЕРВІСНІ ТА ПЕДАГОГІЧНІ ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

def api_students_autocomplete(request):
    """
    Повертає список унікальних імен учнів для миттєвого автодоповнення у формі здачі робіт.
    """
    class_group_id = request.GET.get('class_group_id')
    if class_group_id and (not class_group_id.isdigit() or int(class_group_id) < 1):
        return JsonResponse({'error': 'Некоректний ID класу.'}, status=400)
    query = request.GET.get('query', '').strip().lower()

    students_qs = scope_students(request, Student.objects.filter(integration_active=True, class_group__integration_active=True))
    submissions = scope_submissions(request, Submission.objects.all())
    if class_group_id:
        students_qs = students_qs.filter(class_group_id=class_group_id)
        submissions = submissions.filter(class_group_id=class_group_id)
    students, seen = [], set()
    for pupil in students_qs:
        full_name = pupil.get_full_name()
        seen.add((pupil.last_name.casefold(), pupil.first_name.casefold()))
        if not query or query in full_name.casefold() or query in f"{pupil.first_name} {pupil.last_name}".casefold():
            students.append({'id': pupil.pk, 'last_name': pupil.last_name, 'first_name': pupil.first_name, 'full_name': full_name})
    # Historical names remain available in legacy, unshared classes. They have
    # no stable ID and cannot be silently matched to a synchronized pupil.
    from .roster_identity import has_stable_class_roster
    shared = has_stable_class_roster(ClassGroup.objects.filter(pk=class_group_id).first()) if class_group_id else False
    if not shared:
        for ln, fn in submissions.values_list('last_name', 'first_name').distinct():
            key = (ln.strip().casefold(), fn.strip().casefold())
            full_name = f"{ln} {fn}".strip()
            if key not in seen and full_name and (not query or query in full_name.casefold()):
                seen.add(key)
                students.append({'id': None, 'last_name': ln, 'first_name': fn, 'full_name': full_name})

    try:
        limit = int(request.GET.get('limit', 15 if query else 100))
    except (ValueError, TypeError):
        limit = 100 if not query else 15

    students.sort(key=lambda x: (x['last_name'].lower(), x['first_name'].lower()))
    return JsonResponse({'students': students[:max(1, min(limit, 1000))], 'stable_roster': bool(shared)})


@teacher_required
def download_assignment_submissions_zip(request, pk):
    """
    Масове завантаження робіт учнів по завданню одним структурованим ZIP-архівом.
    """
    import zipfile
    import io
    from django.http import HttpResponse

    assignment = get_object_or_404(Assignment, pk=pk)
    teacher = request.user.teacher_profile

    if not (request.user.is_superuser or assignment.teacher == teacher):
        messages.error(request, "У вас немає доступу до експорту робіт цього завдання.")
        return redirect('teacher_dashboard')

    class_id = request.GET.get('class_group')
    submissions = assignment.submissions.all().select_related('class_group')
    if class_id:
        submissions = submissions.filter(class_group_id=class_id)

    zip_buffer = tempfile.TemporaryFile(mode='w+b')
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        files_added = 0
        for sub in submissions:
            class_name = sub.class_group.name if sub.class_group else "Загальний"
            student_name = f"{sub.last_name}_{sub.first_name}".strip()
            
            sub_files = list(sub.files.all())
            if sub_files:
                for idx, sf in enumerate(sub_files):
                    if sf.file and os.path.exists(sf.file.path):
                        ext = sf.get_extension() or ''
                        orig_base = os.path.splitext(sf.original_name or os.path.basename(sf.file.name))[0]
                        prefix = f"_{idx+1}" if len(sub_files) > 1 else ""
                        arc_name = f"{class_name}/{student_name}_{orig_base}{prefix}{ext}"
                        zip_file.write(sf.file.path, arc_name)
                        files_added += 1
            elif sub.file and os.path.exists(sub.file.path):
                ext = sub.get_file_extension() or ''
                orig_base = os.path.splitext(os.path.basename(sub.file.name))[0]
                arc_name = f"{class_name}/{student_name}_{orig_base}{ext}"
                zip_file.write(sub.file.path, arc_name)
                files_added += 1
            elif sub.link:
                arc_name = f"{class_name}/{student_name}_посилання.txt"
                content = f"Учень: {sub.get_student_full_name()}\nКлас: {class_name}\nПосилання на роботу:\n{sub.link}\n"
                if sub.comment_student:
                    content += f"\nКоментар учня:\n{sub.comment_student}\n"
                zip_file.writestr(arc_name, content)
                files_added += 1

    if files_added == 0:
        messages.warning(request, "У цьому завданні немає зданих файлів або посилань для завантаження.")
        return redirect('assignment_submissions', pk=pk)

    zip_buffer.seek(0)
    safe_title = re.sub(r'[^\w\-_\. ]', '_', assignment.title)[:30]
    filename = f"Roboty_{safe_title}.zip"

    response = FileResponse(zip_buffer, as_attachment=True, filename=filename, content_type='application/zip')
    return response


@teacher_required
def download_database_backup(request):
    """
    Створення та завантаження резервної копії бази даних у 1 клік (тільки для супер-адміністраторів школи).
    """
    if not request.user.is_superuser:
        messages.error(request, "Резервне копіювання бази даних доступне лише супер-адміністраторам.")
        return redirect('teacher_dashboard')

    from django.conf import settings
    from django.http import HttpResponse, FileResponse
    from datetime import datetime
    import io

    db_path = settings.DATABASES['default'].get('NAME')
    today_str = timezone.localtime(timezone.now()).strftime('%Y-%m-%d_%H-%M')

    if db_path and os.path.exists(str(db_path)):
        backup_filename = f"schoolnet_backup_{today_str}.sqlite3"
        return FileResponse(
            open(db_path, 'rb'),
            as_attachment=True,
            filename=backup_filename,
            content_type='application/x-sqlite3'
        )
    else:
        # Резервний експорт через dumpdata у JSON
        from django.core.management import call_command
        buf = io.StringIO()
        call_command('dumpdata', stdout=buf)
        buf.seek(0)
        resp = HttpResponse(buf.getvalue(), content_type='application/json')
        resp['Content-Disposition'] = f'attachment; filename="schoolnet_backup_{today_str}.json"'
        return resp


# ═══════════════════════════════════════════════════════════════════════════════
# МОДУЛЬ ШТУЧНОГО ІНТЕЛЕКТУ (GOOGLE GEMINI AI)
# ═══════════════════════════════════════════════════════════════════════════════

@teacher_required

# ═══════════════════════════════════════════════════════════════════════════════
# ЄДИНИЙ ЦЕНТР НАЛАШТУВАНЬ ВЧИТЕЛЯ ТА АДМІНІСТРАТОРА (ПРОФІЛЬ, СЕРЕДОВИЩЕ, ШІ)
# ═══════════════════════════════════════════════════════════════════════════════

@teacher_required
def teacher_settings_view(request):
    """
    Єдиний Центр Налаштувань для вчителів та адміністраторів.
    Об'єднує:
    1. Профіль вчителя (ПІБ, фото аватара, колір, власні предмети та класи, зміна пароля).
    2. Середовище закладу (Назва школи, супер-адмін режим, бекап БД, керування вчителями).
    3. Штучний інтелект (API ключ, системний промт, пріоритети моделей, черга fallback, видалення моделей, статистика).
    """
    teacher = request.user.teacher_profile
    just_created_api_key = just_created_api_key_name = None
    tab = request.GET.get('tab', 'profile')
    env_section = request.GET.get('section', 'school')
    if tab == 'notifications':
        tab = 'environment'
        env_section = 'notifications'
    elif tab not in ['profile', 'environment', 'ai', 'api']:
        tab = 'profile'

    from .submission_notifications import SubmissionNotificationSettings, SubmissionNotificationSettingsForm
    notification_settings = SubmissionNotificationSettings.objects.filter(teacher=teacher).first()
    if notification_settings is None:
        notification_settings = SubmissionNotificationSettings(teacher=teacher)
    notification_form = SubmissionNotificationSettingsForm(instance=notification_settings)

    # This subpage needs neither AI statistics nor storage scans or hidden forms.
    def render_notification_settings():
        response = render(request, 'feed/notification_settings.html', {
            'active_tab': 'environment', 'active_env_section': 'notifications',
            'teacher': teacher, 'school': School.objects.first(),
            'is_superadmin_mode': request.session.get('superadmin_mode', False),
            'submission_notification_form': notification_form,
        })
        response['Cache-Control'] = 'no-store'
        return response

    if request.method == 'POST' and request.POST.get('action') == 'save_submission_notifications':
        notification_form = SubmissionNotificationSettingsForm(request.POST, instance=notification_settings)
        if notification_form.is_valid():
            notification_form.save()
            messages.success(request, 'Сповіщення про здачу робіт збережено.')
            return redirect(f"{reverse('teacher_settings')}?tab=environment&section=notifications#submission-notification-settings")
        return render_notification_settings()
    if request.method == 'GET' and tab == 'environment' and env_section == 'notifications':
        return render_notification_settings()

    ai_settings = AISettings.get_solo()
    if request.method == 'GET' and tab == 'ai':
        ai_settings.import_legacy_connections()
    school = School.objects.first()
    if not school:
        school = School.objects.create(name="Наш Заклад Освіти", admin=request.user)

    profile_form = TeacherProfileForm(instance=teacher)
    subject_form = SubjectForm()
    class_form = ClassGroupForm()
    teacher_create_form = TeacherCreateForm()

    if request.method == 'POST':
        action = request.POST.get('action')
        is_superadmin_mode = bool(request.user.is_superuser and request.session.get('superadmin_mode', False))

        # ── 1. ДІЇ ПРОФІЛЮ ────────────────────────────────────────────────────
        if action == 'update_profile':
            profile_form = TeacherProfileForm(request.POST, request.FILES, instance=teacher)
            if profile_form.is_valid():
                profile_form.save()
                messages.success(request, 'Профіль та аватар успішно збережено! ✅')
            else:
                for field, errors in profile_form.errors.items():
                    for err in errors:
                        messages.error(request, f'{err}')
            return redirect(f"{reverse('teacher_settings')}?tab=profile")

        elif action == 'remove_avatar':
            if teacher.avatar_image:
                try:
                    if os.path.exists(teacher.avatar_image.path):
                        os.remove(teacher.avatar_image.path)
                except Exception:
                    pass
                teacher.avatar_image = None
                teacher.save(update_fields=['avatar_image'])
                messages.info(request, 'Фото аватара видалено. Використовуються кольорові ініціали.')
            return redirect(f"{reverse('teacher_settings')}?tab=profile")

        elif action == 'change_own_password':
            new_pass = request.POST.get('new_password', '').strip()
            if len(new_pass) < 4:
                messages.error(request, 'Пароль занадто короткий (мінімум 4 символи).')
            else:
                request.user.set_password(new_pass)
                request.user.save()
                from django.contrib.auth import update_session_auth_hash
                update_session_auth_hash(request, request.user)
                messages.success(request, 'Ваш пароль успішно змінено! 🔐')
            return redirect(f"{reverse('teacher_settings')}?tab=profile")

        elif action == 'add_teacher_subject':
            subject_id = request.POST.get('subject_id')
            if subject_id:
                subject = get_object_or_404(Subject, pk=subject_id)
                teacher.subjects.add(subject)
                messages.success(request, f'Предмет «{subject.name}» додано до вашого профілю! 📚')
            return redirect(f"{reverse('teacher_settings')}?tab=profile")

        elif action == 'remove_teacher_subject':
            subject_id = request.POST.get('subject_id')
            if subject_id:
                subject = get_object_or_404(Subject, pk=subject_id)
                teacher.subjects.remove(subject)
                messages.info(request, f'Предмет «{subject.name}» видалено з вашого профілю.')
            return redirect(f"{reverse('teacher_settings')}?tab=profile")

        elif action == 'add_teacher_class':
            class_id = request.POST.get('class_id')
            if class_id:
                cgroup = get_object_or_404(ClassGroup, pk=class_id)
                teacher.classes.add(cgroup)
                messages.success(request, f'Клас «{cgroup.name}» додано до вашого профілю! 🏫')
            return redirect(f"{reverse('teacher_settings')}?tab=profile")

        elif action == 'remove_teacher_class':
            class_id = request.POST.get('class_id')
            if class_id:
                cgroup = get_object_or_404(ClassGroup, pk=class_id)
                teacher.classes.remove(cgroup)
                messages.info(request, f'Клас «{cgroup.name}» видалено з вашого профілю.')
            return redirect(f"{reverse('teacher_settings')}?tab=profile")

        elif action == 'create_subject':
            subject_form = SubjectForm(request.POST)
            if subject_form.is_valid():
                subject = subject_form.save(commit=False)
                subject.created_by = teacher
                subject.save()
                teacher.subjects.add(subject)
                messages.success(request, f'Предмет «{subject.name}» успішно створено та додано до вашого профілю! 📚')
            else:
                for field, errors in subject_form.errors.items():
                    for err in errors:
                        messages.error(request, f'{err}')
            return redirect(f"{reverse('teacher_settings')}?tab=profile")

        elif action == 'create_class':
            class_form = ClassGroupForm(request.POST)
            if class_form.is_valid():
                cgroup = class_form.save(commit=False)
                cgroup.created_by = teacher
                cgroup.save()
                teacher.classes.add(cgroup)
                messages.success(request, f'Клас «{cgroup.name}» успішно створено та додано до вашого профілю! 🏫')
            else:
                for field, errors in class_form.errors.items():
                    for err in errors:
                        messages.error(request, f'{err}')
            return redirect(f"{reverse('teacher_settings')}?tab=profile")

        # ── 2. ДІЇ СЕРЕДОВИЩА ТА АДМІНІСТРУВАННЯ ──────────────────────────────
        elif action == 'update_school_name':
            if not is_superadmin_mode:
                messages.error(request, "Для зміни назви закладу необхідно увімкнути режим супер-адміністратора 👑.")
            else:
                s_name = request.POST.get('school_name', '').strip()
                if s_name:
                    school.name = s_name
                    school.admin = request.user
                    school.save()
                    messages.success(request, f"Назву закладу успішно змінено на «{s_name}»! 🏫")
            return redirect(f"{reverse('teacher_settings')}?tab=environment")

        elif action == 'create_teacher_account':
            if not is_superadmin_mode:
                messages.error(request, "Для створення акаунтів вчителів необхідно увімкнути режим супер-адміністратора 👑.")
            else:
                t_form = TeacherCreateForm(request.POST)
                if t_form.is_valid():
                    username = t_form.cleaned_data['username']
                    password = t_form.cleaned_data['password']
                    full_name = t_form.cleaned_data['full_name']
                    is_super = t_form.cleaned_data.get('is_superuser', False)

                    user = User.objects.create_user(username=username, password=password, is_superuser=is_super, is_staff=is_super)
                    Teacher.objects.create(user=user, full_name=full_name)
                    messages.success(request, f"Акаунт вчителя «{full_name}» (логін: {username}) успішно створено! 👤")
                else:
                    for field, errors in t_form.errors.items():
                        for err in errors:
                            messages.error(request, f'{err}')
            return redirect(f"{reverse('teacher_settings')}?tab=environment")

        elif action == 'reset_teacher_password':
            if not is_superadmin_mode:
                messages.error(request, "Для скидання паролів необхідно увімкнути режим супер-адміністратора 👑.")
            else:
                u_id = request.POST.get('user_id')
                new_pass = request.POST.get('new_password', '').strip()
                if u_id and new_pass:
                    target_user = get_object_or_404(User, pk=u_id)
                    target_user.set_password(new_pass)
                    target_user.save()
                    messages.success(request, f"Пароль для «{target_user.teacher_profile.full_name}» ({target_user.username}) успішно змінено! 🔑")
            return redirect(f"{reverse('teacher_settings')}?tab=environment")

        elif action == 'toggle_teacher_superadmin':
            if not is_superadmin_mode:
                messages.error(request, "Для зміни прав супер-адміністратора необхідно увімкнути відповідний режим 👑.")
            else:
                u_id = request.POST.get('user_id')
                if u_id:
                    target_user = get_object_or_404(User, pk=u_id)
                    if target_user == request.user:
                        messages.warning(request, "Ви не можете змінити статус супер-адміністратора для власного акаунта.")
                    else:
                        target_user.is_superuser = not target_user.is_superuser
                        target_user.is_staff = target_user.is_superuser
                        target_user.save()
                        status_msg = "надано права супер-адміністратора" if target_user.is_superuser else "переведено у звичайні вчителі"
                        messages.success(request, f"Користувачу «{target_user.username}» {status_msg}!")
            return redirect(f"{reverse('teacher_settings')}?tab=environment")

        elif action == 'delete_teacher':
            if not is_superadmin_mode:
                messages.error(request, "Для видалення вчителів необхідно увімкнути режим супер-адміністратора 👑.")
            else:
                t_id = request.POST.get('teacher_id')
                if t_id:
                    t_del = get_object_or_404(Teacher, pk=t_id)
                    if t_del.user == request.user:
                        messages.error(request, "Ви не можете видалити власний профіль.")
                    else:
                        u_del = t_del.user
                        t_name = t_del.full_name
                        t_del.delete()
                        u_del.delete()
        # ── 2.2. ДІЇ РОЗКЛАДУ ДЗВІНКІВ ──────────────────────────────────────
        elif action == 'save_bell_slot':
            slot_id = request.POST.get('slot_id')
            lesson_number = request.POST.get('lesson_number')
            start_time_str = request.POST.get('start_time', '').strip()
            end_time_str = request.POST.get('end_time', '').strip()

            if lesson_number and start_time_str and end_time_str:
                import datetime
                try:
                    num = int(lesson_number)
                    sh, sm = map(int, start_time_str.split(':'))
                    eh, em = map(int, end_time_str.split(':'))
                    s_time = datetime.time(sh, sm)
                    e_time = datetime.time(eh, em)

                    if s_time >= e_time:
                        messages.error(request, "Час завершення уроку має бути пізніше за час початку.")
                    else:
                        if slot_id:
                            slot = get_object_or_404(BellSchedule, pk=slot_id)
                            slot.lesson_number = num
                            slot.start_time = s_time
                            slot.end_time = e_time
                            slot.order = num
                            slot.save()
                            messages.success(request, f"Урок №{num} успішно оновлено! 🔔")
                        else:
                            BellSchedule.objects.update_or_create(
                                lesson_number=num,
                                defaults={'start_time': s_time, 'end_time': e_time, 'order': num}
                            )
                            messages.success(request, f"Урок №{num} ({start_time_str} – {end_time_str}) успішно збережено в розкладі дзвінків! 🔔")
                except Exception as ex:
                    messages.error(request, f"Помилка формату часу: {ex}")
            else:
                messages.error(request, "Будь ласка, вкажіть номер уроку, час початку та час закінчення.")
            return redirect(f"{reverse('teacher_settings')}?tab=environment")

        elif action == 'delete_bell_slot':
            slot_id = request.POST.get('slot_id')
            if slot_id:
                slot = get_object_or_404(BellSchedule, pk=slot_id)
                num = slot.lesson_number
                slot.delete()
                messages.success(request, f"Урок №{num} видалено з розкладу дзвінків.")
            return redirect(f"{reverse('teacher_settings')}?tab=environment")

        elif action == 'reset_default_bells':
            BellSchedule.objects.all().delete()
            BellSchedule.seed_default_schedule()
            messages.success(request, "Відновлено стандартний розклад дзвінків (1–8 уроки)! 🔔")
            return redirect(f"{reverse('teacher_settings')}?tab=environment")

        # ── 3. ДІЇ ШТУЧНОГО ІНТЕЛЕКТУ ТА ПРІОРИТЕТІВ МОДЕЛЕЙ ─────────────────
        elif action in ('save_ai_connection', 'delete_ai_connection'):
            from .ai_connections import save_connection
            try:
                save_connection(ai_settings.pk, request.POST, delete=action == 'delete_ai_connection')
                messages.success(request, 'Підключення видалено разом із його моделями.' if action == 'delete_ai_connection' else 'Підключення збережено. Порядок використання змінюється на вкладці «Моделі».')
            except ValueError as error:
                messages.error(request, str(error))
            return redirect(ai_settings_url(request))

        elif action == 'save_ai_config' or (not action and ('api_key' in request.POST or 'temperature' in request.POST or 'system_prompt' in request.POST or 'ai_detector_tolerance_percent' in request.POST or 'backup_api_key' in request.POST)):
            ai_provider = request.POST.get('ai_provider', 'gemini').strip()
            api_key = request.POST.get('api_key', '').strip()
            model_name = request.POST.get('model_name', '').strip()
            custom_api_url = request.POST.get('custom_api_url', '').strip()

            backup_ai_provider = request.POST.get('backup_ai_provider', 'gemini').strip()
            backup_api_key = request.POST.get('backup_api_key', '').strip()
            backup_model_name = request.POST.get('backup_model_name', '').strip()
            backup_custom_api_url = request.POST.get('backup_custom_api_url', '').strip()

            active_api_type = request.POST.get('active_api_type', 'primary').strip()
            auto_failover_enabled = bool(request.POST.get('auto_failover_enabled'))

            system_prompt = request.POST.get('system_prompt', DEFAULT_NUS_SYSTEM_PROMPT).strip()
            raw_temp = request.POST.get('temperature', '0.2')
            try:
                temperature_val = max(0.0, min(1.0, float(str(raw_temp).replace(',', '.').strip())))
            except (ValueError, TypeError):
                temperature_val = 0.2
            is_enabled = bool(request.POST.get('is_enabled'))
            tolerance_val = request.POST.get('ai_detector_tolerance_percent')

            if not ai_settings.unified_model_queue:
                ai_settings.ai_provider = ai_provider or 'gemini'
                ai_settings.api_key = api_key
                if model_name:
                    ai_settings.model_name = model_name
                    ai_settings.add_saved_model(model_name, provider=ai_settings.ai_provider)
                ai_settings.custom_api_url = custom_api_url

                ai_settings.backup_ai_provider = backup_ai_provider or 'gemini'
                ai_settings.backup_api_key = backup_api_key
                ai_settings.backup_model_name = backup_model_name
                ai_settings.backup_custom_api_url = backup_custom_api_url

                if active_api_type in ['primary', 'backup']:
                    ai_settings.active_api_type = active_api_type
            ai_settings.auto_failover_enabled = auto_failover_enabled

            ai_settings.system_prompt = system_prompt
            ai_settings.temperature = temperature_val
            ai_settings.is_enabled = is_enabled
            ai_settings.default_thinking_mode = bool(request.POST.get('default_thinking_mode'))
            privacy_mode = request.POST.get('privacy_mode')
            if privacy_mode in ('strict', 'redact'):
                ai_settings.privacy_mode = privacy_mode
            if tolerance_val is not None:
                try:
                    ai_settings.ai_detector_tolerance_percent = max(0, min(100, int(tolerance_val)))
                except (ValueError, TypeError):
                    pass
            if ai_settings.unified_model_queue:
                ai_settings.save(update_fields=['auto_failover_enabled', 'system_prompt', 'temperature', 'is_enabled',
                    'default_thinking_mode', 'ai_detector_tolerance_percent', 'privacy_mode', 'updated_at'])
            else:
                ai_settings.save()
            messages.success(request, "Параметри модуля ШІ збережено! 🤖")
            if request.path == reverse('ai_settings'):
                return redirect('ai_settings')
            return redirect(ai_settings_url(request))

        elif action == 'switch_active_api':
            if ai_settings.unified_model_queue:
                messages.info(request, 'Порядок використання змінюється на вкладці «Моделі».')
                return redirect(ai_settings_url(request))
            target_api = request.POST.get('target_api', '').strip()
            if target_api in ['primary', 'backup']:
                ai_settings.active_api_type = target_api
            else:
                ai_settings.active_api_type = 'backup' if ai_settings.active_api_type == 'primary' else 'primary'
            ai_settings.save(update_fields=['active_api_type', 'updated_at'])
            target_title = "Основний API" if ai_settings.active_api_type == 'primary' else "Резервний API"
            messages.success(request, f"Активний API успішно перемкнуто на: {target_title}! 🔄")
            if request.path == reverse('ai_settings'):
                return redirect('ai_settings')
            return redirect(ai_settings_url(request))

        elif action in ['add_custom_model', 'move_model_priority', 'toggle_model_enabled', 'delete_model', 'switch_model']:
            with transaction.atomic():
                ai_settings = AISettings.objects.select_for_update().get(pk=ai_settings.pk)
                provider = request.POST.get('model_provider', '').strip() or None
                connection_id = request.POST.get('connection_id', '').strip() or None
                if ai_settings.unified_model_queue:
                    connection = ai_settings.get_connection(connection_id)
                    if not connection:
                        messages.error(request, 'Оберіть підключення для моделі.')
                        return redirect(ai_settings_url(request))
                    provider = connection['provider']
                try:
                    if provider and provider not in dict(AI_PROVIDER_CHOICES):
                        raise ValueError('Оберіть підтримуваного провайдера.')
                    if action == 'add_custom_model':
                        name = request.POST.get('new_model_name', '').strip()
                        if not name or len(name) > 100 or any(ch.isspace() for ch in name):
                            raise ValueError('Вкажіть ідентифікатор моделі без пробілів, до 100 символів.')
                        raw_priority = request.POST.get('priority', '')
                        priority = int(raw_priority) if raw_priority.isdigit() else None
                        if request.POST.get('make_active'): priority = 1
                        ai_settings.add_saved_model(name, priority=priority, provider=provider, connection_id=connection_id)
                        messages.success(request, f'Модель «{name}» додано до черги.')
                        resolved = ai_settings._model_provider(name, provider)
                        if not ai_settings.get_provider_config(resolved, connection_id=connection_id):
                            messages.info(request, 'Модель збережено. Щоб використовувати її, налаштуйте цей провайдер у «Підключення».')
                    elif action == 'move_model_priority':
                        ai_settings.move_model_priority(request.POST.get('model_name', ''), request.POST.get('direction'), provider=provider, connection_id=connection_id)
                        messages.info(request, 'Порядок моделей оновлено.')
                    elif action == 'toggle_model_enabled':
                        ai_settings.toggle_model_enabled(request.POST.get('model_name', ''), provider=provider, connection_id=connection_id)
                        messages.info(request, 'Участь моделі у fallback змінено.')
                    elif action == 'delete_model':
                        ai_settings.remove_saved_model(request.POST.get('model_to_delete', ''), provider=provider, connection_id=connection_id)
                        messages.info(request, 'Модель видалено з черги.')
                    else:
                        name = request.POST.get('switch_to_model', '').strip()
                        if not name: raise ValueError('Оберіть модель.')
                        ai_settings.activate_saved_model(name, provider, connection_id=connection_id)
                        ai_settings.add_saved_model(name, priority=1, provider=provider, connection_id=connection_id)
                        messages.success(request, f'Активну модель змінено на «{name}».')
                except (ValueError, TypeError) as error:
                    messages.error(request, str(error))
                return redirect(ai_settings_url(request))

        elif action == 'reset_prompt':
            ai_settings.system_prompt = DEFAULT_NUS_SYSTEM_PROMPT
            ai_settings.save(update_fields=['system_prompt', 'updated_at'])
            messages.success(request, "Системний промт успішно скинуто до офіційного стандарту НУШ! 🔄")
            return redirect(ai_settings_url(request))

        # ── 4. ШАБЛОНИ КРИТЕРІЇВ ОЦІНЮВАННЯ ТА ФАЙЛИ МОН ─────────────────────
        elif action == 'create_criteria_preset':
            p_name = request.POST.get('preset_name', '').strip()
            p_eval_type = request.POST.get('evaluation_type', 'nus_gr').strip()
            p_desc = request.POST.get('description', '').strip()
            p_prompt = request.POST.get('system_prompt', '').strip()
            p_gr_definitions = request.POST.get('gr_definitions', '').strip()
            p_doc = request.FILES.get('document_file')
            p_is_def = (request.POST.get('is_default') == 'on' or request.POST.get('is_default') == '1')

            if p_name:
                preset = AICriteriaPreset.objects.create(
                    name=p_name,
                    evaluation_type=p_eval_type,
                    description=p_desc,
                    system_prompt=p_prompt,
                    gr_definitions=p_gr_definitions,
                    document_file=p_doc,
                    is_default=p_is_def,
                    is_system=False
                )
                if p_doc:
                    preset.document_name = p_doc.name
                    preset.extract_and_save_document_text()
                    preset.save()
                messages.success(request, f"Шаблон критеріїв «{p_name}» успішно створено!")
            else:
                messages.error(request, "Вкажіть назву шаблону критеріїв.")
            return redirect(ai_settings_url(request))

        elif action == 'update_criteria_preset':
            preset_id = request.POST.get('preset_id')
            preset = get_object_or_404(AICriteriaPreset, id=preset_id)
            p_name = request.POST.get('preset_name', '').strip()
            p_eval_type = request.POST.get('evaluation_type', 'nus_gr').strip()
            p_desc = request.POST.get('description', '').strip()
            p_prompt = request.POST.get('system_prompt', '').strip()
            p_gr_definitions = request.POST.get('gr_definitions', '').strip()
            p_doc = request.FILES.get('document_file')
            remove_doc = (request.POST.get('remove_document') == '1')
            p_is_def = (request.POST.get('is_default') == 'on' or request.POST.get('is_default') == '1')

            if p_name:
                preset.name = p_name
                preset.evaluation_type = p_eval_type
                preset.description = p_desc
                preset.system_prompt = p_prompt
                preset.gr_definitions = p_gr_definitions
                if p_is_def:
                    preset.is_default = True

                if remove_doc:
                    if preset.document_file:
                        try:
                            preset.document_file.delete(save=False)
                        except Exception:
                            pass
                    preset.document_file = None
                    preset.document_name = ''
                    preset.extracted_criteria_text = ''
                elif p_doc:
                    preset.document_file = p_doc
                    preset.document_name = p_doc.name
                    preset.extract_and_save_document_text()

                preset.save()
                messages.success(request, f"Шаблон критеріїв «{p_name}» оновлено!")
            return redirect(ai_settings_url(request))

        elif action == 'delete_criteria_preset':
            preset_id = request.POST.get('preset_id')
            preset = get_object_or_404(AICriteriaPreset, id=preset_id)
            p_name = preset.name
            was_default = preset.is_default

            if preset.document_file:
                try:
                    preset.document_file.delete(save=False)
                except Exception:
                    pass
            preset.delete()

            # Якщо видалено активний дефолтний шаблон, призначаємо новий
            if was_default:
                other_preset = AICriteriaPreset.objects.first()
                if other_preset:
                    other_preset.is_default = True
                    other_preset.save(update_fields=['is_default'])
                else:
                    AICriteriaPreset.ensure_default_presets()

            messages.warning(request, f"Шаблон критеріїв «{p_name}» успішно видалено.")
            return redirect(ai_settings_url(request))

        elif action == 'restore_default_presets':
            AICriteriaPreset.ensure_default_presets(force_recreate=True)
            messages.success(request, "Стандартні галузеві шаблони критеріїв МОН України відновлено та оновлено! ⭐")
            return redirect(ai_settings_url(request))

        elif action == 'set_default_criteria_preset':
            preset_id = request.POST.get('preset_id')
            preset = get_object_or_404(AICriteriaPreset, id=preset_id)
            preset.is_default = True
            preset.save()
            messages.success(request, f"Шаблон «{preset.name}» встановлено як активний за замовчуванням ⭐")
            return redirect(ai_settings_url(request))

        elif action == 'clear_ai_error_logs':
            AIErrorLog.objects.all().delete()
            messages.success(request, "Журнал помилок та збоїв ШІ успішно очищено! 🗑️")
            return redirect(ai_settings_url(request))

        elif action == 'generate_ai_error_report':
            from .ai_error_analyzer import generate_error_report_with_ai
            report = generate_error_report_with_ai(teacher=teacher)
            if report.verdict == 'no_errors':
                messages.info(request, "Помилок ШІ не виявлено — журнал чистий! 🟢")
            elif report.verdict == 'external_issue':
                messages.success(request, f"Звіт сформовано ШІ ({report.errors_count} помилок): {report.verdict_title} 🌐")
            else:
                messages.warning(request, f"Звіт сформовано ШІ ({report.errors_count} помилок): {report.verdict_title} ⚠️")
            return redirect(ai_settings_url(request, extra_params={'errors_view': 'analysis', 'report_id': report.pk}))

        elif action == 'mark_all_errors_read':
            count = AIErrorLog.objects.filter(is_read=False).update(is_read=True, read_at=timezone.now())
            messages.success(request, f"Позначено як зчитані {count} помилок ШІ! ✅")
            return redirect(ai_settings_url(request))

        # ── 5. ДІЇ ДЛЯ API ТА ЛОКАЛЬНОГО ЖУРНАЛУ ─────────────────────────────
        elif action in ('create_journal_api_key', 'create_simple_journal_api_key'):
            name = request.POST.get('key_name', '').strip() or 'Локальний журнал оцінок'
            can_export = action == 'create_simple_journal_api_key' or bool(request.POST.get('can_export_grades'))
            can_import = action == 'create_simple_journal_api_key' or bool(request.POST.get('can_import_roster'))
            journal_url = request.POST.get('local_journal_url', '').strip()

            from .models import JournalAPIKey
            key_token = JournalAPIKey.generate_key()
            JournalAPIKey.objects.create(
                name=name,
                key=key_token,
                teacher=teacher,
                can_export_grades=can_export,
                can_import_roster=can_import,
                local_journal_url=journal_url,
                is_active=True
            )
            just_created_api_key = key_token
            just_created_api_key_name = name
            tab = 'api'
            messages.success(request, f"API ключ «{name}» успішно згенеровано! 🔑 Скопіюйте його нижче для налаштування локального журналу.")

        elif action == 'delete_journal_api_key':
            key_id = request.POST.get('key_id')
            from .models import JournalAPIKey
            key_obj = get_object_or_404(JournalAPIKey.objects.all() if request.user.is_superuser else JournalAPIKey.objects.filter(teacher=teacher), id=key_id)
            k_name = key_obj.name
            key_obj.delete()
            messages.success(request, f"API ключ «{k_name}» видалено! 🗑️")
            return redirect(f"{reverse('teacher_settings')}?tab=api")

        elif action == 'toggle_journal_api_key':
            key_id = request.POST.get('key_id')
            from .models import JournalAPIKey
            key_obj = get_object_or_404(JournalAPIKey.objects.all() if request.user.is_superuser else JournalAPIKey.objects.filter(teacher=teacher), id=key_id)
            key_obj.is_active = not key_obj.is_active
            key_obj.save(update_fields=['is_active'])
            status_text = "активовано ✅" if key_obj.is_active else "деактивовано ⏸️"
            messages.info(request, f"API ключ «{key_obj.name}» {status_text}.")
            return redirect(f"{reverse('teacher_settings')}?tab=api")

        elif action == 'pull_local_journal_roster':
            target_url = request.POST.get('journal_url', '').strip()
            if not target_url:
                messages.error(request, "Вкажіть коректний URL локального журналу для отримання даних.")
            else:
                from .journal_api import sync_roster_data
                import urllib.request
                import json
                try:
                    req = urllib.request.Request(
                        target_url,
                        headers={'User-Agent': 'SchoolNet-Journal-Sync/1.0', 'Accept': 'application/json'}
                    )
                    with urllib.request.urlopen(req, timeout=8) as resp:
                        raw_data = json.loads(resp.read().decode('utf-8'))
                    payload = raw_data if isinstance(raw_data, dict) else {'students': raw_data}
                    res = sync_roster_data(payload, teacher=teacher)
                    c_count = len(res['created_classes'])
                    c_str = f" та {c_count} класів ({', '.join(res['created_classes'])})" if c_count else ""
                    messages.success(request, f"🎉 Успішно отримано дані з {target_url}! Створено учнів: {res['created_students']}, оновлено: {res['updated_students']}{c_str}.")
                except Exception as e:
                    messages.error(request, f"Помилка зʼєднання з локальним журналом ({target_url}): {e}")
            return redirect(f"{reverse('teacher_settings')}?tab=api")

    # Підготовка даних контексту для сторінки налаштувань
    teacher_subjects = teacher.subjects.all().order_by('name')
    teacher_classes = teaching_classes(teacher.classes.all()).order_by('grade', 'letter', 'name')
    other_subjects = Subject.objects.exclude(id__in=teacher_subjects.values_list('id', flat=True)).order_by('name')
    other_classes = teaching_classes(ClassGroup.objects.exclude(id__in=teacher_classes.values_list('id', flat=True))).order_by('grade', 'letter', 'name')
    all_teachers = Teacher.objects.select_related('user').all()

    # Гарантуємо наявність базових шаблонів критеріїв оцінювання
    AICriteriaPreset.ensure_default_presets()
    criteria_presets = AICriteriaPreset.objects.all()
    default_preset = AICriteriaPreset.objects.filter(is_default=True).first() or criteria_presets.first()

    # Дані AI та статистики
    models_with_priority = ai_settings.get_models_with_priority()
    saved_models = [m['name'] for m in models_with_priority]
    active_fallback_chain = ai_settings.get_active_fallback_chain()

    # Перевірки ШІ: рахуємо і вчительські (ai_status != 'none') і самоперевірки учнів (student_ai_checked=True)
    teacher_ai_checks = Submission.objects.exclude(ai_status__in=['none', '']).count()
    student_ai_checks = Submission.objects.filter(student_ai_checked=True).count()
    total_ai_checks = teacher_ai_checks + student_ai_checks

    total_ai_success = Submission.objects.filter(ai_status='success').count()
    total_ai_failed = Submission.objects.filter(ai_status='failed').count()
    total_ai_unsupported = Submission.objects.filter(ai_status='unsupported').count()

    # Оцінки застосовані (або через AI, або напряму)
    total_applied_grades = Submission.objects.filter(
        Q(graded_by__isnull=False) | Q(grade__isnull=False)
    ).count()

    # Середній відсоток ШІ-генерованості (де є дані)
    from django.db.models import Avg
    avg_ai_percent_result = Submission.objects.filter(
        ai_generated_percent__isnull=False
    ).aggregate(avg=Avg('ai_generated_percent'))
    avg_ai_percent = round(avg_ai_percent_result['avg'] or 0, 1)

    # Підозрілі (ai_generated_percent > порогового значення)
    tolerance = getattr(ai_settings, 'ai_detector_tolerance_percent', 25) or 25
    total_ai_detected = Submission.objects.filter(ai_generated_detected=True).count()

    from .ai_concurrency import get_model_cooldown, get_model_context_limit

    model_stats = []
    for item in models_with_priority:
        conn_id = item.get('connection_id') or ''
        provider = item['provider']
        model_name = item['name']
        display_name = model_name if provider == 'gemini' else f"{model_name} ({provider.title()})"

        # Рахуємо перевірки конкретного підключення (акаунта)
        if conn_id:
            conn_submissions = Submission.objects.filter(ai_connection_id=conn_id)
            has_conn_subs = conn_submissions.exists()
            conn_errors = AIErrorLog.objects.filter(connection_id=conn_id)
            has_conn_errors = conn_errors.exists()
        else:
            has_conn_subs = False
            has_conn_errors = False

        if has_conn_subs or has_conn_errors:
            success_count = conn_submissions.filter(ai_status='success').count()
            failed_count = conn_submissions.filter(ai_status='failed').count()
            total_failed = max(failed_count, conn_errors.count())
            total_checks = success_count + total_failed
        else:
            # Для історичних перевірок (до збереження ai_connection_id):
            same_siblings = [m for m in models_with_priority if m['provider'] == provider and m['name'] == model_name]
            is_first_sibling = (not same_siblings or item.get('connection_id') == same_siblings[0].get('connection_id'))

            if is_first_sibling:
                legacy_checks = Submission.objects.filter(
                    Q(ai_connection_id__in=['', None]) &
                    (Q(ai_provider_used=provider) | Q(ai_provider_used='')) &
                    (Q(ai_model_used=display_name) | Q(ai_model_used=model_name) | Q(ai_request_model=model_name))
                )
                legacy_errors = AIErrorLog.objects.filter(
                    Q(connection_id__in=['', None]) &
                    Q(provider=provider) &
                    (Q(model_name=model_name) | Q(model_name=display_name))
                )
                success_count = legacy_checks.filter(ai_status='success').count()
                failed_count = legacy_checks.filter(ai_status='failed').count()
                total_failed = max(failed_count, legacy_errors.count())
                total_checks = success_count + total_failed
            else:
                success_count = 0
                total_failed = 0
                total_checks = 0

        in_cd, cd_rem, cd_reason = get_model_cooldown(provider, model_name)
        ctx_limit = get_model_context_limit(provider, model_name)
        model_stats.append({
            **item,
            'is_saved': True,
            'configured': bool(ai_settings.get_provider_config(provider, connection_id=conn_id)),
            'is_active': bool(ai_settings.get_request_configs()) and (conn_id, model_name) == (ai_settings.get_request_configs()[0].get('connection_id'), ai_settings.get_request_configs()[0]['model']),
            'total_checks': total_checks,
            'success_checks': success_count,
            'failed_checks': total_failed,
            'is_in_cooldown': in_cd,
            'cooldown_remaining': cd_rem,
            'cooldown_reason': cd_reason,
            'context_limit_flagged': bool(ctx_limit),
            'context_limit_error': ctx_limit.get('error', '') if ctx_limit else ''
        })

    level_high = Submission.objects.filter(ai_score_level__icontains='висок').count()
    level_sufficient = Submission.objects.filter(ai_score_level__icontains='достат').count()
    level_medium = Submission.objects.filter(ai_score_level__icontains='серед').count()
    level_initial = Submission.objects.filter(ai_score_level__icontains='почат').count()
    level_rework = Submission.objects.filter(
        Q(ai_suggested_grade__icontains='доопрацю') | Q(ai_score_level__icontains='доопрацю')
    ).count()

    # Дані середовища
    env_stats = {
        'total_teachers': all_teachers.count(),
        'total_subjects': Subject.objects.count(),
        'total_classes': ClassGroup.objects.count(),
        'total_assignments': Assignment.objects.count(),
        'total_submissions': Submission.objects.count(),
        **get_storage_snapshot(),
    }

    from .ai_model_catalog import PROVIDER_CATALOG, CATALOG_CHECKED_AT

    # ── 3.3.2. СТАТИСТИКА ЗАПИТІВ ТА ТОКЕНІВ ДЛЯ ВИКОРИСТАНИХ МОДЕЛЕЙ ──────
    stats_days_param = request.GET.get('stats_days', '7').strip()
    now = timezone.now()
    one_minute_ago = now - timedelta(minutes=1)
    today_start = timezone.localtime(now).replace(hour=0, minute=0, second=0, microsecond=0)

    if stats_days_param == '1':
        start_date = now - timedelta(days=1)
        period_days_count = 1
        stats_days_label = '1 день (останні 24 години)'
    elif stats_days_param == '3':
        start_date = now - timedelta(days=3)
        period_days_count = 3
        stats_days_label = 'Останні 3 дні'
    elif stats_days_param == '14':
        start_date = now - timedelta(days=14)
        period_days_count = 14
        stats_days_label = 'Останні 14 днів'
    elif stats_days_param == '30':
        start_date = now - timedelta(days=30)
        period_days_count = 30
        stats_days_label = 'Останній місяць (30 днів)'
    elif stats_days_param == 'all':
        start_date = None
        period_days_count = None
        stats_days_label = 'Весь час'
    else:
        stats_days_param = '7'
        start_date = now - timedelta(days=7)
        period_days_count = 7
        stats_days_label = 'Останні 7 днів'

    from feed.models import AIRequestLog

    from .ai_usage_statistics import build_usage_chart, build_model_usage_stats
    active_provider, _, active_model, _, _ = ai_settings.get_active_config()
    used_model_usage_stats = build_model_usage_stats(AIRequestLog.objects.all(), now, start_date, period_days_count, active_provider, active_model)
    ai_usage_chart = build_usage_chart(AIRequestLog.objects.all(), now, start_date)
    error_logs = AIErrorLog.objects.all()
    if start_date is not None:
        error_logs = error_logs.filter(created_at__gte=start_date)
    stats_view = request.GET.get('stats_view', 'usage')
    if stats_view not in ['usage', 'models', 'overview']: stats_view = 'usage'

    errors_view = request.GET.get('errors_view', 'list')
    if errors_view not in ['list', 'analysis']:
        errors_view = 'list'

    from .models import AIErrorReport
    from .ai_error_analyzer import get_error_summary_stats
    reports = AIErrorReport.objects.select_related('created_by').order_by('-created_at', '-pk')
    latest_ai_error_report = reports.first()
    selected_ai_error_report = latest_ai_error_report
    report_id = request.GET.get('report_id')
    if report_id is not None:
        try:
            report_pk = int(report_id)
        except (TypeError, ValueError):
            raise Http404('Некоректний номер звіту.')
        if not 0 < report_pk <= 9223372036854775807:
            raise Http404('Некоректний номер звіту.')
        selected_ai_error_report = get_object_or_404(reports, pk=report_pk)
    if request.GET.get('report_download') == 'markdown':
        if selected_ai_error_report is None:
            raise Http404('Звітів ще немає.')
        response = HttpResponse(selected_ai_error_report.report_text, content_type='text/markdown; charset=utf-8')
        response['Content-Disposition'] = f'attachment; filename="schoolnet-ai-report-{selected_ai_error_report.pk}.md"'
        return response
    ai_error_reports_page = Paginator(reports, 10).get_page(request.GET.get('report_page'))
    ai_error_reports = ai_error_reports_page.object_list
    error_summary_stats = get_error_summary_stats()
    unread_ai_errors_count = AIErrorLog.objects.filter(is_read=False).count()

    from .models import JournalAPIKey
    journal_api_keys = (JournalAPIKey.objects.all() if request.user.is_superuser else JournalAPIKey.objects.filter(teacher=teacher)).order_by('-created_at')
    from django.conf import settings as journal_settings
    journal_site_url = request.build_absolute_uri(reverse('api_school_ping'))[:-len('/api/v2/ping')]
    from school_sync.network_inventory import connection_addresses
    from .school_api_v2 import local_instance_id
    journal_connection_addresses = connection_addresses(journal_site_url, os.getenv('APP_PORT') or '8000')
    import json as journal_json
    journal_connection_code = journal_json.dumps({'source': 'schoolwork', 'site_url': journal_site_url, 'api_key': just_created_api_key}, ensure_ascii=False) if just_created_api_key else ''

    context = {
        'active_tab': tab,
        'ai_section': ai_settings_section(request),
        'ai_settings_sections': AI_SETTINGS_SECTIONS,
        'journal_api_keys': journal_api_keys,
        'total_journal_keys_count': journal_api_keys.count(),
        'just_created_api_key': just_created_api_key,
        'just_created_api_key_name': just_created_api_key_name,
        'journal_site_url': journal_site_url,
        'source_instance_id': local_instance_id(),
        'connection_addresses': journal_connection_addresses,
        'journal_connection_code': journal_connection_code,
        'api_base_url': request.build_absolute_uri('/')[:-1],
        'teacher': teacher,
        'cloud_storage': teacher.get_cloud_storage(),
        'submission_notification_form': notification_form,
        'active_env_section': env_section,
        'school': school,
        'profile_form': profile_form,
        'subject_form': subject_form,
        'class_form': class_form,
        'teacher_create_form': teacher_create_form,
        'teacher_subjects': teacher_subjects,
        'teacher_classes': teacher_classes,
        'other_subjects': other_subjects,
        'other_classes': other_classes,
        'all_teachers': all_teachers,
        'is_superuser': request.user.is_superuser,
        'is_superadmin_mode': request.session.get('superadmin_mode', False),
        'bell_schedules': BellSchedule.objects.all().order_by('lesson_number'),
        'env_stats': env_stats,
        'ai_settings': ai_settings,
        'ai_providers': [(group['provider'], group['title']) for group in PROVIDER_CATALOG],
        'saved_models': saved_models,
        'models_with_priority': models_with_priority,
        'active_fallback_chain': active_fallback_chain,
        'model_stats': model_stats,
        'ai_connections': ai_settings.public_connections(),
        'provider_catalog': PROVIDER_CATALOG,
        'catalog_checked_at': CATALOG_CHECKED_AT,
        'stats_view': stats_view,
        'errors_view': errors_view,
        'ai_error_reports': ai_error_reports,
        'latest_ai_error_report': latest_ai_error_report,
        'selected_ai_error_report': selected_ai_error_report,
        'ai_error_reports_page': ai_error_reports_page,
        'error_summary_stats': error_summary_stats,
        'unread_ai_errors_count': unread_ai_errors_count,
        'used_model_usage_stats': used_model_usage_stats,
        'ai_usage_chart': ai_usage_chart,
        'stats_days': stats_days_param,
        'stats_days_label': stats_days_label,
        'default_prompt': DEFAULT_NUS_SYSTEM_PROMPT,
        'default_nus_gr_prompt': DEFAULT_NUS_GR_SYSTEM_PROMPT,
        'default_traditional_prompt': DEFAULT_TRADITIONAL_SYSTEM_PROMPT,
        'criteria_presets': criteria_presets,
        'default_preset': default_preset,
        'total_ai_checks': total_ai_checks,
        'teacher_ai_checks': teacher_ai_checks,
        'student_ai_checks': student_ai_checks,
        'total_ai_success': total_ai_success,
        'total_ai_failed': total_ai_failed,
        'total_ai_unsupported': total_ai_unsupported,
        'total_applied_grades': total_applied_grades,
        'avg_ai_percent': avg_ai_percent,
        'total_ai_detected': total_ai_detected,
        'level_high': level_high,
        'level_sufficient': level_sufficient,
        'level_medium': level_medium,
        'level_initial': level_initial,
        'level_rework': level_rework,
        'ai_error_logs': error_logs.select_related('teacher', 'submission', 'assignment').order_by('-created_at')[:100],
        'total_ai_errors_count': error_logs.count(),
    }
    response = render(request, 'feed/settings.html', context)
    response['Cache-Control'] = 'no-store'
    return response


@teacher_required
def ai_settings_view(request):
    """
    Сумісність: перенаправлення або відображення налаштувань ШІ у Єдиному центрі.
    """
    if request.method == 'GET':
        q = request.GET.copy()
        q['tab'] = 'ai'
        request.GET = q
    return teacher_settings_view(request)


@teacher_required
@require_POST
def api_test_gemini_connection(request):
    """
    AJAX endpoint для перевірки валідності API ключа будь-якого ШІ-провайдера (Gemini, OpenAI, DeepSeek тощо).
    """
    from .gemini_service import test_ai_connection
    provider = request.POST.get('provider', '').strip()
    if provider and provider not in dict(AI_PROVIDER_CHOICES):
        return JsonResponse({'success': False, 'message': 'Невідомий провайдер.'}, status=400)
    api_key = request.POST.get('api_key')
    model_name = request.POST.get('model_name', '').strip()
    custom_url = request.POST.get('custom_url')

    connection_id = request.POST.get('connection_id', '').strip()
    if connection_id:
        settings = AISettings.get_solo()
        connection = settings.get_connection(connection_id)
        if not connection:
            return JsonResponse({'success': False, 'message': 'Підключення більше не існує.'}, status=400)
        if provider and provider != connection['provider']:
            return JsonResponse({'success': False, 'message': 'Постачальник не відповідає підключенню.'}, status=400)
        provider = connection['provider']
        api_key = (api_key or '').strip() or connection['api_key']
        custom_url = custom_url if custom_url is not None else connection['custom_url']

    success, message, model_used, prov_used = test_ai_connection(
        provider=provider,
        api_key=api_key,
        model_name=model_name,
        custom_url=custom_url
    )
    return JsonResponse({
        'success': success,
        'message': message,
        'model': model_used,
        'provider': prov_used
    })


def _teacher_ai_selection(request, submission):
    """Validate both teacher entry points and freeze the displayed class policy."""
    preset_id = request.POST.get('preset_id') or request.GET.get('preset_id')
    preset, policy_codes = submission.assignment.get_ai_policy(submission.class_group) if submission.assignment else (None, [])
    if preset_id:
        if not str(preset_id).isdigit():
            raise ValueError('Невірний шаблон критеріїв.')
        preset = AICriteriaPreset.objects.filter(pk=preset_id).first()
        if not preset:
            raise ValueError('Шаблон критеріїв не знайдено.')
        policy_preset = submission.assignment.get_ai_policy(submission.class_group)[0] if submission.assignment else None
        if preset != policy_preset:
            policy_codes = []
    if not preset:
        AICriteriaPreset.ensure_default_presets()
        preset = AICriteriaPreset.objects.filter(is_default=True).first() or AICriteriaPreset.objects.first()
    values = request.POST.getlist('selected_gr_codes')
    codes = None
    if values:
        if len(values) > 1:
            codes = values
        else:
            try:
                codes = json.loads(values[0])
            except (ValueError, TypeError):
                codes = [value.strip() for value in values[0].split(',') if value.strip()]
        if not isinstance(codes, list) or not all(isinstance(code, str) for code in codes):
            raise ValueError('ГР потрібно передати списком кодів.')
    definitions = preset.get_gr_list() if preset and preset.evaluation_type != 'traditional' else []
    if definitions:
        valid_codes = {gr['code'] for gr in definitions}
        if codes is None:
            codes = policy_codes or [gr['code'] for gr in definitions]
        if not codes or any(code not in valid_codes for code in codes):
            raise ValueError('Оберіть хоча б одну ГР із цього шаблону.')
        codes = [gr['code'] for gr in definitions if gr['code'] in codes]
    elif preset and preset.evaluation_type == 'traditional':
        codes = []
    elif codes:
        raise ValueError('У цьому шаблоні немає визначених ГР. Оберіть шаблон із групами результатів.')
    else:
        codes = []
    return str(preset.pk) if preset else None, codes


def _teacher_ai_privacy_options(request):
    """Only teacher endpoints persist this explicit, single-request choice."""
    return {'ignore_strict_privacy': True} if request.POST.get('ignore_strict_privacy') == '1' else {}


@teacher_required
@require_POST
def ai_check_single_submission(request, submission_id):
    """
    Виконує ШІ-перевірку конкретної роботи учня за допомогою Google Gemini.
    Підтримує вибір шаблону критеріїв та вибір конкретних груп результатів (ГР) прапорцями.
    """
    from .gemini_service import evaluate_submission_with_gemini
    submission = get_object_or_404(Submission.objects.select_related('assignment', 'class_group'), id=submission_id)

    if not can_manage_submission(request, submission):
        return JsonResponse({'status': 'error', 'message': 'Немає доступу'}, status=403)

    custom_prompt = request.POST.get('custom_prompt', '').strip() or None
    try:
        preset_id, selected_gr_codes = _teacher_ai_selection(request, submission)
    except ValueError as exc:
        return JsonResponse({'status': 'error', 'error': str(exc)}, status=400)

    force_thinking_raw = request.POST.get('force_thinking')
    force_thinking = None
    if force_thinking_raw is not None:
        force_thinking = str(force_thinking_raw).strip().lower() in ('1', 'true', 'yes', 'on')

    from .ai_jobs import enqueue_submission_job, job_response, SelfCheckUnavailable
    try:
        job = enqueue_submission_job(submission, 'teacher_check', user=request.user, parameters={
            'custom_prompt': custom_prompt, 'preset_id': preset_id,
            'selected_gr_codes': selected_gr_codes, 'force_thinking': force_thinking,
            **_teacher_ai_privacy_options(request),
        })
    except SelfCheckUnavailable as exc:
        return JsonResponse({'status': 'error', 'error': str(exc)}, status=exc.http_status)
    return job_response(job, request=request)


@teacher_required
@require_POST
def teacher_generate_assignment_criteria(request):
    """
    AJAX endpoint: генерація структурованих індивідуальних критеріїв оцінювання
    за 12-бальною шкалою НУШ за допомогою Google Gemini на основі опису вчителя звичайною мовою.
    """
    from .gemini_service import generate_criteria_with_gemini

    if request.content_type == 'application/json':
        try:
            body = json.loads(request.body)
        except Exception:
            body = {}
        teacher_notes = body.get('teacher_notes', '').strip()
        assignment_title = body.get('assignment_title', '').strip()
        assignment_description = body.get('assignment_description', '').strip()
        subject_name = body.get('subject_name', '').strip()
        class_group_name = body.get('class_group_name', '').strip()
    else:
        teacher_notes = request.POST.get('teacher_notes', '').strip()
        assignment_title = request.POST.get('assignment_title', '').strip()
        assignment_description = request.POST.get('assignment_description', '').strip()
        subject_name = request.POST.get('subject_name', '').strip()
        class_group_name = request.POST.get('class_group_name', '').strip()

    if not teacher_notes and not assignment_description and not assignment_title:
        return JsonResponse({
            'status': 'error',
            'message': 'Будь ласка, опишіть своїми словами вимоги до завдання або заповніть тему чи опис.'
        }, status=400)

    res = generate_criteria_with_gemini(
        teacher_notes=teacher_notes,
        assignment_title=assignment_title,
        assignment_description=assignment_description,
        subject_name=subject_name,
        class_group_name=class_group_name
    )

    if res.get('status') == 'success':
        return JsonResponse({
            'status': 'success',
            'criteria': res.get('criteria', ''),
            'model_used': res.get('model_used', '')
        })
    else:
        return JsonResponse({
            'status': 'error',
            'message': res.get('message', 'Не вдалося згенерувати критерії.')
        }, status=400)



def api_classes_list(request):
    """Повертає класи вчителя або класи, дозволені публічним посиланням."""
    if not get_teacher_or_none(request) and not link_for(request) and not getattr(request, 'public_open_access', False):
        return redirect('teacher_login')
    from .models import ClassGroup
    classes = scope_classes(request, teaching_classes(ClassGroup.objects.all())).order_by('grade', 'letter', 'name')
    return JsonResponse({
        'status': 'ok',
        'classes': [{'id': c.id, 'name': c.name, 'grade': c.grade, 'letter': c.letter} for c in classes]
    })


@teacher_required
def api_teacher_schedules(request):
    """
    Повертає розклад уроків вчителя (TeacherLessonSchedule) у форматі JSON,
    згрупований по класах. Використовується в модальному вікні дублювання
    для динамічного відображення прив'язки до розкладу для кожного класу.
    """
    teacher = request.user.teacher_profile
    schedules = TeacherLessonSchedule.objects.filter(
        teacher=teacher
    ).select_related('bell_slot', 'class_group').order_by('class_group__grade', 'class_group__letter', 'day_of_week', 'bell_slot__lesson_number')

    day_names = {1: 'Понеділок', 2: 'Вівторок', 3: 'Середа', 4: 'Четвер', 5: "П'ятниця", 6: 'Субота', 7: 'Неділя'}

    # Групуємо по class_group_id
    by_class = {}
    for sch in schedules:
        cid = sch.class_group_id
        if cid not in by_class:
            by_class[cid] = []
        slot = sch.bell_slot
        by_class[cid].append({
            'day_of_week': sch.day_of_week,
            'day_name': day_names.get(sch.day_of_week, ''),
            'bell_slot_id': slot.id if slot else None,
            'lesson_number': slot.lesson_number if slot else None,
            'start_time': slot.start_time.strftime('%H:%M') if slot and slot.start_time else '',
            'end_time': slot.end_time.strftime('%H:%M') if slot and slot.end_time else '',
            'label': f"{day_names.get(sch.day_of_week, '')}, {slot.lesson_number}-й урок ({slot.start_time.strftime('%H:%M')})" if slot and slot.start_time else day_names.get(sch.day_of_week, ''),
            'value': f"slot_{sch.day_of_week}_{slot.id}" if slot else f"day_{sch.day_of_week}",
        })

    return JsonResponse({'status': 'ok', 'schedules_by_class': by_class})


@teacher_required
def ai_batch_check_view(request):
    """
    Сторінка масової перевірки робіт учнів штучним інтелектом:
    - Фільтр за класом або завданням
    - Вибір шаблону критеріїв оцінювання (НУШ, Класична 1-12, шаблони МОН)
    - Вибір: тільки неоцінені чи всі роботи
    - Інтерактивний покроковий запуск із прогрес-баром
    """
    ai_settings = AISettings.get_solo()
    all_classes = teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter')
    all_assignments = Assignment.objects.all().order_by('-published_at')

    AICriteriaPreset.ensure_default_presets()
    criteria_presets = AICriteriaPreset.objects.all()
    default_preset = AICriteriaPreset.objects.filter(is_default=True).first() or criteria_presets.first()

    # Підрахунок доступних робіт
    accessible_submissions = teacher_submissions(request, Submission.objects.all())
    total_submissions = accessible_submissions.count()
    ungraded_submissions = accessible_submissions.filter(is_latest_attempt=True).filter(Q(grade__isnull=True) | Q(grade='')).count()
    ai_evaluated_submissions = accessible_submissions.filter(ai_status='success').count()

    context = {
        'ai_settings': ai_settings,
        'all_classes': all_classes,
        'all_assignments': all_assignments,
        'criteria_presets': criteria_presets,
        'default_preset': default_preset,
        'total_submissions': total_submissions,
        'ungraded_submissions': ungraded_submissions,
        'ai_evaluated_submissions': ai_evaluated_submissions,
    }
    return render(request, 'feed/ai_batch_check.html', context)


@teacher_required
@require_POST
def api_ai_get_batch_queue(request):
    """
    AJAX endpoint: повертає список ID робіт для пакетної обробки за фільтрами.
    """
    class_id = request.POST.get('class_id')
    assignment_id = request.POST.get('assignment_id')
    only_ungraded = request.POST.get('only_ungraded') == 'true'
    only_unreviewed_ai = request.POST.get('only_unreviewed_ai') == 'true'

    qs = teacher_submissions(request, Submission.objects.all()).select_related('class_group', 'assignment')

    if class_id:
        qs = qs.filter(class_group_id=class_id)
    if assignment_id:
        qs = qs.filter(assignment_id=assignment_id)
    if only_ungraded:
        qs = qs.filter(is_latest_attempt=True).filter(Q(grade__isnull=True) | Q(grade=''))
    if only_unreviewed_ai:
        qs = qs.exclude(ai_status='success')

    items = []
    for s in qs.order_by('-submitted_at')[:300]:
        items.append({
            'id': s.id,
            'request_metadata': s.get_ai_request_metadata() if s.ai_status == 'success' else None,
            'student_name': s.get_student_full_name(),
            'class_name': s.class_group.name if s.class_group else '—',
            'assignment_title': s.assignment.title if s.assignment else '—',
            'current_grade': s.grade or 'Немає',
            'ai_status': s.ai_status,
            'ai_grade': s.ai_suggested_grade or '—',
            'ai_feedback': s.ai_feedback or '',
            'ai_generated_detected': bool(s.ai_generated_detected),
            'ai_generated_percent': s.ai_generated_percent,
            'ai_generated_confidence': s.get_ai_generated_confidence_display() if hasattr(s, 'get_ai_generated_confidence_display') else s.ai_generated_confidence,
            'ai_generated_details': s.ai_generated_details or '',
            'is_ai_allowed': bool(s.is_ai_allowed),
            'gr_results': s.get_ai_gr_results_list(),
            'gr_avg': s.get_ai_gr_average(),
            'has_format_warning': ('Зауваження до формату файлу' in (s.ai_feedback or ''))
        })

    return JsonResponse({'queue': items, 'total': len(items)})


@teacher_required
@require_POST
def api_ai_process_item(request, submission_id):
    """
    AJAX endpoint: обробляє один елемент із черги пакетної ШІ-перевірки за обраним шаблоном критеріїв.
    """
    from .gemini_service import evaluate_submission_with_gemini
    submission = get_object_or_404(Submission.objects.select_related('assignment', 'class_group'), id=submission_id)

    if not can_manage_submission(request, submission):
        return JsonResponse({'status': 'error', 'message': 'Немає доступу'}, status=403)

    try:
        preset_id, selected_gr_codes = _teacher_ai_selection(request, submission)
    except ValueError as exc:
        return JsonResponse({'status': 'error', 'error': str(exc)}, status=400)

    from .ai_jobs import enqueue_submission_job, job_response, SelfCheckUnavailable
    try:
        job = enqueue_submission_job(submission, 'batch_check', user=request.user, parameters={
            'preset_id': preset_id, 'selected_gr_codes': selected_gr_codes,
            **_teacher_ai_privacy_options(request),
        })
    except SelfCheckUnavailable as exc:
        return JsonResponse({'status': 'error', 'error': str(exc)}, status=exc.http_status)
    return job_response(job, request=request)


@teacher_required
@require_POST
@transaction.atomic
def ai_apply_suggested_grade(request, submission_id):
    """
    Застосовує попередню оцінку та коментар ШІ як офіційну оцінку вчителя в 1 клік.
    Оцінки за окремими ГР зберігаються в системі конфіденційно, а у відгук учню додаються
    лише рекомендації та педагогічні зауваження.
    """
    submission = get_object_or_404(Submission, id=submission_id)

    if not can_manage_submission(request, submission):
        return JsonResponse({'status': 'error', 'message': 'Немає доступу'}, status=403)

    if not submission.ai_suggested_grade:
        return JsonResponse({'status': 'error', 'message': 'У цієї роботи немає попередньої оцінки ШІ.'}, status=400)

    # Встановлюємо оцінку
    try:
        submission.grade = validate_grade(submission.ai_suggested_grade)
    except ValidationError as exc:
        return JsonResponse({'status': 'error', 'message': exc.messages[0]}, status=400)
    submission.graded_by = request.user
    submission.graded_at = timezone.now()

    # Додаємо або оновлюємо коментар ШІ у відгуках вчителя (використовуючи очищений від оцінок ГР відгук)
    clean_feedback = submission.get_clean_ai_feedback_for_student()
    if clean_feedback:
        submission.teacher_comment = clean_feedback
        ai_tag = "🤖 [Рекомендації та відгук ШІ]:"
        new_text = f"{ai_tag}\n{clean_feedback}"
        ai_comment_filter = (
            Q(text__startswith="🤖 [")
            | Q(text__contains="🤖 [Рекомендації")
            | Q(text__startswith="📌 **Висновок:**")
            | Q(text__startswith="**Висновок:**")
        )
        existing_comment = submission.comments.filter(ai_comment_filter).order_by('created_at').first()
        if existing_comment:
            if existing_comment.text != new_text:
                existing_comment.text = new_text
                existing_comment.save(update_fields=['text'])
            # Видаляємо дублікати старих AI-коментарів, якщо такі випадково існували
            submission.comments.filter(ai_comment_filter).exclude(id=existing_comment.id).delete()
        else:
            SubmissionComment.objects.create(
                submission=submission,
                author=request.user,
                text=new_text
            )

        # Синхронізуємо оновлений коментар зі співавторами колективної роботи
        if submission.is_group_work or submission.primary_submission_id or submission.coauthor_submissions.exists():
            for m in submission.get_all_group_submissions():
                if m.id == submission.id:
                    continue
                m_existing = m.comments.filter(ai_comment_filter).order_by('created_at').first()
                if m_existing:
                    if m_existing.text != new_text:
                        m_existing.text = new_text
                        m_existing.save(update_fields=['text'])
                    m.comments.filter(ai_comment_filter).exclude(id=m_existing.id).delete()
                else:
                    SubmissionComment.objects.create(
                        submission=m,
                        author=request.user,
                        text=new_text
                    )

    submission.save(update_fields=['grade', 'graded_by', 'graded_at', 'teacher', 'teacher_comment'])

    # Синхронізуємо оцінку зі співавторами
    coauthors_graded = sync_grades_to_coauthors(submission, submission.grade, request.user)

    log_msg = f"Вчитель прийняв оцінку ШІ «{submission.grade}» для учня {submission.get_student_full_name()}"
    if coauthors_graded:
        log_msg += f" (також виставлено оцінку співавторам: {', '.join(coauthors_graded)})"

    log_submission_activity(
        request.user,
        'grade_submission',
        log_msg,
        submission=submission
    )

    is_ajax = (
        request.headers.get('x-requested-with', '').lower() == 'xmlhttprequest'
        or request.GET.get('format') == 'json'
        or 'application/json' in request.headers.get('accept', '').lower()
        or request.content_type == 'application/json'
    )
    if is_ajax or request.method == 'POST':
        return JsonResponse({
            'status': 'success',
            'grade': submission.grade,
            'coauthors_graded': coauthors_graded,
            'message': f"Оцінку «{submission.grade}» успішно встановлено!" + (f" (також співавторам: {', '.join(coauthors_graded)})" if coauthors_graded else "")
        })

    succ_msg = f"Оцінку «{submission.grade}» успішно застосовано до роботи учня {submission.get_student_full_name()}!"
    if coauthors_graded:
        succ_msg += f" Оцінку також виставлено співавторам: {', '.join(coauthors_graded)}."
    messages.success(request, succ_msg)
    return redirect('view_file', submission_id=submission.id)


# ═══════════════════════════════════════════════════════════════════════════════
# ПЕРЕНЕСЕННЯ УРОКІВ, 30-ДЕННИЙ КАЛЕНДАР, РОЗКЛАД ТА ZIP ІМПОРТ/ЕКСПОРТ
# ═══════════════════════════════════════════════════════════════════════════════

@teacher_required
def reschedule_assignment(request, pk):
    """
    Перенесення уроку/завдання на іншу дату та урок із фіксацією причини.
    Оновлює цільовий розклад (AssignmentScheduleTarget) та за потреби дедлайн.
    """
    from datetime import datetime, timedelta, date
    from django.http import JsonResponse
    teacher = request.user.teacher_profile
    if request.user.is_superuser or request.session.get('superadmin_mode'):
        assignment = get_object_or_404(Assignment, pk=pk)
    else:
        assignment = get_object_or_404(Assignment, pk=pk, teacher=teacher)

    if request.method == 'POST':
        is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.POST.get('is_ajax')

        class_id = request.POST.get('class_group')
        new_date_str = request.POST.get('new_date')
        new_slot_id = request.POST.get('new_bell_slot')
        reason_type = request.POST.get('reason_type', AssignmentRescheduleLog.REASON_AIR_RAID)
        reason_comment = request.POST.get('reason_comment', '').strip()
        update_due_date = request.POST.get('update_due_date') in ['1', 'true', 'on', True]

        if not new_date_str:
            if is_ajax:
                return JsonResponse({'success': False, 'error': 'Вкажіть нову дату уроку.'}, status=400)
            messages.error(request, 'Помилка: обов\'язково вкажіть нову дату уроку.')
            return redirect(request.META.get('HTTP_REFERER') or 'teacher_dashboard')

        try:
            new_date = datetime.strptime(new_date_str, '%Y-%m-%d').date()
        except ValueError:
            if is_ajax:
                return JsonResponse({'success': False, 'error': 'Некоректний формат дати.'}, status=400)
            messages.error(request, 'Помилка: некоректний формат дати.')
            return redirect(request.META.get('HTTP_REFERER') or 'teacher_dashboard')

        class_group = None
        if class_id:
            class_group = ClassGroup.objects.filter(id=class_id).first()

        new_slot = None
        if new_slot_id:
            new_slot = BellSchedule.objects.filter(id=new_slot_id).first()

        # Визначаємо початкову дату та урок
        existing_target = None
        if class_group:
            existing_target = assignment.schedule_targets.filter(class_group=class_group).first()
        if not existing_target:
            existing_target = assignment.schedule_targets.first()

        if existing_target and existing_target.target_date:
            orig_date = existing_target.target_date
            orig_slot = existing_target.bell_slot
        else:
            orig_date = timezone.localdate(assignment.published_at) if assignment.published_at else timezone.localdate()
            orig_slot = None

        # Фіксуємо перенесення в базі даних
        reschedule_log = AssignmentRescheduleLog.objects.create(
            assignment=assignment,
            teacher=teacher,
            class_group=class_group,
            original_date=orig_date,
            original_bell_slot=orig_slot,
            new_date=new_date,
            new_bell_slot=new_slot,
            reason_type=reason_type,
            reason_comment=reason_comment
        )

        # Оновлюємо цільову дату для класів
        target_dow = new_date.weekday() + 1
        targets_to_update = []
        if class_group:
            t, _ = AssignmentScheduleTarget.objects.get_or_create(
                assignment=assignment,
                class_group=class_group
            )
            targets_to_update.append(t)
        else:
            assigned_classes = list(assignment.classes.all())
            if assigned_classes:
                for cg in assigned_classes:
                    t, _ = AssignmentScheduleTarget.objects.get_or_create(
                        assignment=assignment,
                        class_group=cg
                    )
                    targets_to_update.append(t)
            else:
                t, _ = AssignmentScheduleTarget.objects.get_or_create(
                    assignment=assignment,
                    class_group=None
                )
                targets_to_update.append(t)

        for t in targets_to_update:
            t.target_date = new_date
            t.target_day_of_week = target_dow
            t.bell_slot = new_slot
            t.save()

        if update_due_date:
            assignment.due_date = new_date
            assignment.save(update_fields=['due_date'])

        reason_label = reschedule_log.get_reason_type_display()
        log_submission_activity(
            request.user,
            'rescheduled',
            f"Урок «{assignment.title}» перенесено з {orig_date.strftime('%d.%m.%Y')} на {new_date.strftime('%d.%m.%Y')} ({reason_label})"
        )

        slot_text = f" ({new_slot.lesson_number}-й урок)" if new_slot else ""
        msg = f"Урок «{assignment.title}» успішно перенесено на {new_date.strftime('%d.%m.%Y')}{slot_text}! Причина: {reason_label}."
        messages.success(request, msg)

        if is_ajax:
            return JsonResponse({
                'success': True,
                'message': msg,
                'new_date': new_date.strftime('%d.%m.%Y'),
                'reason_display': reason_label,
                'reason_icon': reschedule_log.reason_icon,
                'new_slot_text': slot_text
            })

    referer = request.META.get('HTTP_REFERER')
    if referer and request.get_host() in referer:
        return redirect(referer)
    return redirect('teacher_dashboard')


@teacher_required
def api_next_lesson_slot(request):
    """
    API для авто-визначення наступного уроку за розкладом вчителя для обраного класу.
    """
    from datetime import datetime, timedelta, date
    from django.http import JsonResponse
    from django.utils import timezone

    teacher = request.user.teacher_profile
    class_id = request.GET.get('class_id')
    if not class_id:
        return JsonResponse({'success': False, 'error': 'Не вказано клас'}, status=400)

    now = timezone.localtime(timezone.now())
    today = now.date()
    schedules = list(TeacherLessonSchedule.objects.filter(
        teacher=teacher,
        class_group_id=class_id
    ).select_related('bell_slot').order_by('day_of_week', 'bell_slot__lesson_number'))

    if not schedules:
        # Немає розкладу для цього класу — пропонуємо завтра, 1-й урок
        tomorrow = today + timedelta(days=1)
        first_slot = BellSchedule.objects.order_by('lesson_number').first()
        return JsonResponse({
            'success': True,
            'has_schedule': False,
            'next_date': tomorrow.strftime('%Y-%m-%d'),
            'next_date_display': tomorrow.strftime('%d.%m.%Y'),
            'bell_slot_id': first_slot.id if first_slot else None,
            'lesson_number': first_slot.lesson_number if first_slot else 1,
            'info': 'Розклад для цього класу не налаштовано. Запропоновано наступний день.'
        })

    from .lesson_schedule import next_lesson
    subject_id = request.GET.get('subject_id')
    subject_id = int(subject_id) if subject_id and subject_id.isdigit() else None
    lesson, target_date = next_lesson(schedules, now, subject_id)
    if not lesson:
        return JsonResponse({'success': False, 'has_schedule': False,
                             'error': 'Немає уроків цього предмета для обраного класу.'})
    is_today = target_date == today
    ongoing = is_today and lesson.bell_slot.start_time <= now.time() < lesson.bell_slot.end_time
    prefix = 'Зараз' if ongoing else 'Сьогодні' if is_today else lesson.get_day_of_week_display()
    return JsonResponse({
        'success': True,
        'has_schedule': True,
        'next_date': target_date.isoformat(),
        'next_date_display': target_date.strftime('%d.%m.%Y'),
        'bell_slot_id': lesson.bell_slot_id,
        'lesson_number': lesson.bell_slot.lesson_number,
        'start_time': lesson.bell_slot.start_time.strftime('%H:%M'),
        'info': f"{prefix}, {lesson.bell_slot.lesson_number}-й урок ({target_date.strftime('%d.%m')})"
    })


@teacher_required
def teacher_rescheduled_calendar(request):
    """
    Окремий 30-денний календар перенесених уроків для вчителя.
    Відображає 30-денну сітку з відмітками причин перенесень, детальну таблицю
    та статистику за типами причин (повітряна тривога, хвороба тощо).
    """
    from datetime import datetime, timedelta, date
    from django.utils import timezone
    teacher = request.user.teacher_profile
    is_super = request.user.is_superuser or request.session.get('superadmin_mode')

    now = timezone.localtime(timezone.now())
    today = now.date()

    # Вікно на 30 днів (від -14 днів до +15 днів)
    center_date_str = request.GET.get('date')
    if center_date_str:
        try:
            center_date = datetime.strptime(center_date_str, '%Y-%m-%d').date()
        except ValueError:
            center_date = today
    else:
        center_date = today

    start_date = center_date - timedelta(days=14)
    end_date = center_date + timedelta(days=15)  # 30 днів

    qs = AssignmentRescheduleLog.objects.all().select_related(
        'assignment', 'teacher', 'class_group', 'original_bell_slot', 'new_bell_slot', 'assignment__subject'
    )
    if not is_super:
        qs = qs.filter(teacher=teacher)

    selected_class_id = request.GET.get('class_group')
    if selected_class_id:
        qs = qs.filter(class_group_id=selected_class_id)

    selected_reason = request.GET.get('reason_type')
    if selected_reason:
        qs = qs.filter(reason_type=selected_reason)

    logs_30_days = list(qs.filter(
        Q(new_date__range=[start_date, end_date]) | Q(original_date__range=[start_date, end_date])
    ).order_by('-new_date', '-rescheduled_at'))

    days_grid = []
    uk_weekdays_short = {1: 'Пн', 2: 'Вт', 3: 'Ср', 4: 'Чт', 5: 'Пт', 6: 'Сб', 7: 'Нд'}

    logs_by_new_date = {}
    logs_by_orig_date = {}
    for log in logs_30_days:
        logs_by_new_date.setdefault(log.new_date, []).append(log)
        logs_by_orig_date.setdefault(log.original_date, []).append(log)

    uk_months_short = {1: 'Січ', 2: 'Лют', 3: 'Бер', 4: 'Кві', 5: 'Тра', 6: 'Чер',
                       7: 'Лип', 8: 'Сер', 9: 'Вер', 10: 'Жов', 11: 'Лис', 12: 'Гру'}
    curr = start_date
    while curr <= end_date:
        new_logs = logs_by_new_date.get(curr, [])
        orig_logs = logs_by_orig_date.get(curr, [])
        days_grid.append({
            'date': curr,
            'date_str': curr.strftime('%Y-%m-%d'),
            'is_today': (curr == today),
            'is_weekend': (curr.weekday() >= 5),
            'weekday_name': uk_weekdays_short.get(curr.weekday() + 1, ''),
            'day_number': curr.day,
            'month_name': uk_months_short.get(curr.month, ''),
            'new_logs': new_logs,
            'orig_logs': orig_logs,
            'has_events': bool(new_logs or orig_logs),
            'count': len(new_logs) + len(orig_logs),
        })
        curr += timedelta(days=1)

    # Статистика за типами причин
    reason_stats = {}
    for choice_code, choice_title in AssignmentRescheduleLog.REASON_CHOICES:
        count = sum(1 for log in logs_30_days if log.reason_type == choice_code)
        if count > 0:
            reason_stats[choice_code] = {
                'title': choice_title,
                'count': count,
                'percent': int((count / len(logs_30_days)) * 100) if logs_30_days else 0,
            }

    teacher_classes = teaching_classes(teacher.classes.all()).order_by('grade', 'letter', 'name') if teacher else teaching_classes(ClassGroup.objects.all()).order_by('grade', 'letter', 'name')

    context = {
        'today': today,
        'center_date': center_date,
        'start_date': start_date,
        'end_date': end_date,
        'prev_date': (center_date - timedelta(days=30)).strftime('%Y-%m-%d'),
        'next_date': (center_date + timedelta(days=30)).strftime('%Y-%m-%d'),
        'days_grid': days_grid,
        'logs_list': logs_30_days,
        'total_rescheduled_count': len(logs_30_days),
        'reason_stats': reason_stats,
        'reason_choices': AssignmentRescheduleLog.REASON_CHOICES,
        'teacher_classes': teacher_classes,
        'selected_class_id': int(selected_class_id) if selected_class_id and selected_class_id.isdigit() else None,
        'selected_reason': selected_reason,
    }
    return render(request, 'feed/teacher_rescheduled_calendar.html', context)


@login_required
def api_today_schedule(request):
    """
    Повертає детальний JSON із розкладом на сьогодні, живим статусом поточного уроку
    та тривалістю перерв для модального вікна «Розклад на сьогодні».
    """
    from django.http import JsonResponse
    from django.utils import timezone

    teacher = getattr(request.user, 'teacher_profile', None)
    now = timezone.localtime(timezone.now())
    today_date = now.date()
    today_weekday = today_date.weekday() + 1
    now_minutes = now.time().hour * 60 + now.time().minute

    uk_weekdays = {1: 'Понеділок', 2: 'Вівторок', 3: 'Середа', 4: 'Четвер', 5: "П'ятниця", 6: 'Субота', 7: 'Неділя'}
    uk_months = {1: 'січня', 2: 'лютого', 3: 'березня', 4: 'квітня', 5: 'травня', 6: 'червня', 7: 'липня', 8: 'серпня', 9: 'вересня', 10: 'жовтня', 11: 'листопада', 12: 'грудня'}

    date_str = f"{today_date.day} {uk_months.get(today_date.month, '')} {today_date.year}"
    weekday_str = uk_weekdays.get(today_weekday, '')

    bell_slots = list(BellSchedule.objects.all().order_by('lesson_number'))
    lessons = []

    teacher_schedule_map = {}
    if teacher:
        for sch in TeacherLessonSchedule.objects.filter(teacher=teacher, day_of_week=today_weekday).select_related('bell_slot', 'class_group', 'subject'):
            teacher_schedule_map[sch.bell_slot_id] = sch

    active_status = 'free'
    current_lesson_num = None

    for i, slot in enumerate(bell_slots):
        s_min = slot.start_time.hour * 60 + slot.start_time.minute
        e_min = slot.end_time.hour * 60 + slot.end_time.minute

        is_current = (s_min <= now_minutes < e_min)
        is_past = (now_minutes >= e_min)
        is_future = (now_minutes < s_min)

        sch_entry = teacher_schedule_map.get(slot.id)
        class_name = sch_entry.class_group.name if sch_entry and sch_entry.class_group else None
        subject_name = sch_entry.subject.name if sch_entry and sch_entry.subject else None
        subject_icon = sch_entry.subject.icon if sch_entry and sch_entry.subject else '📚'
        subject_color = sch_entry.subject.color if sch_entry and sch_entry.subject else '#4f46e5'

        break_min = slot.get_break_after()
        is_break_now = False
        break_rem = 0
        if break_min and i + 1 < len(bell_slots):
            next_s_min = bell_slots[i + 1].start_time.hour * 60 + bell_slots[i + 1].start_time.minute
            if e_min <= now_minutes < next_s_min:
                is_break_now = True
                break_rem = next_s_min - now_minutes
                active_status = 'in_break'

        elapsed_minutes = 0
        progress_percent = 0
        if is_current:
            active_status = 'in_lesson'
            current_lesson_num = slot.lesson_number
            dur = max(1, e_min - s_min)
            elapsed_minutes = max(0, min(dur, now_minutes - s_min))
            progress_percent = min(100, max(0, int(round((elapsed_minutes / dur) * 100))))
        elif is_past:
            elapsed_minutes = slot.duration_minutes
            progress_percent = 100

        break_duration = 0
        break_elapsed = 0
        break_progress_pct = 0
        if is_break_now:
            next_s_min = bell_slots[i + 1].start_time.hour * 60 + bell_slots[i + 1].start_time.minute
            break_duration = max(1, next_s_min - e_min)
            break_elapsed = max(0, min(break_duration, now_minutes - e_min))
            break_progress_pct = min(100, max(0, int(round((break_elapsed / break_duration) * 100))))

        rem_minutes = max(0, e_min - now_minutes) if is_current else 0

        lessons.append({
            'slot_id': slot.id,
            'lesson_number': slot.lesson_number,
            'start_time': slot.start_time.strftime('%H:%M'),
            'end_time': slot.end_time.strftime('%H:%M'),
            'duration_minutes': slot.duration_minutes,
            'has_class': bool(class_name),
            'class_name': class_name,
            'subject_name': subject_name,
            'subject_icon': subject_icon,
            'subject_color': subject_color,
            'is_current': is_current,
            'is_past': is_past,
            'is_future': is_future,
            'rem_minutes': rem_minutes,
            'elapsed_minutes': elapsed_minutes,
            'progress_percent': progress_percent,
            'break_after': break_min,
            'is_break_now': is_break_now,
            'break_rem_minutes': break_rem,
            'break_duration_minutes': break_duration,
            'break_elapsed_minutes': break_elapsed,
            'break_progress_percent': break_progress_pct,
        })

    conducted_info = teacher.get_conducted_lessons_info() if teacher else None

    return JsonResponse({
        'success': True,
        'date_display': date_str,
        'weekday_display': weekday_str,
        'is_teacher': bool(teacher),
        'active_status': active_status,
        'current_lesson_num': current_lesson_num,
        'lessons': lessons,
        'conducted_info': conducted_info,
    })



@teacher_required
def update_conducted_lessons(request):
    """
    Оновлює кількість фактично проведених уроків вчителем
    або скидає її до автоматичного підрахунку системи.
    """
    from django.http import JsonResponse
    teacher = request.user.teacher_profile
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'reset':
            teacher.conducted_lessons_manual_count = None
            teacher.conducted_lessons_last_modified = timezone.now()
            teacher.save(update_fields=['conducted_lessons_manual_count', 'conducted_lessons_last_modified'])
            messages.success(request, 'Лічильник проведених уроків скинуто до автоматичного розрахунку системи! 🔄')
        else:
            count_val = request.POST.get('count')
            if count_val is not None and str(count_val).strip().isdigit():
                teacher.conducted_lessons_manual_count = int(count_val)
                teacher.conducted_lessons_last_modified = timezone.now()
                teacher.save(update_fields=['conducted_lessons_manual_count', 'conducted_lessons_last_modified'])
                messages.success(request, f'Кількість проведених уроків встановлено: {teacher.conducted_lessons_manual_count}! ✅')
            else:
                messages.error(request, 'Введіть коректне додатне число проведених уроків.')

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            info = teacher.get_conducted_lessons_info()
            return JsonResponse({'success': True, 'info': info})

    referer = request.META.get('HTTP_REFERER')
    if referer and request.get_host() in referer:
        return redirect(referer)
    return redirect('teacher_students')


@teacher_required
def export_assignment_zip(request, pk):
    from .assignment_archive import archive_assignments, export_bundle

    teacher = request.user.teacher_profile
    assignments = archive_assignments(teacher)
    if request.user.is_superuser or request.session.get('superadmin_mode'):
        assignments = assignments.model.objects.select_related('subject', 'default_ai_preset').prefetch_related(
            'classes', 'files', 'additional_links', 'youtube_links',
            'schedule_targets__class_group', 'schedule_targets__bell_slot')
    assignment = get_object_or_404(assignments, pk=pk)
    try:
        buffer = export_bundle([assignment], teacher)
    except ValueError as error:
        messages.error(request, str(error))
        return redirect('teacher_dashboard')
    title = ''.join(char for char in assignment.title if char.isalnum() or char in ' _-').strip()[:40] or 'task'
    return FileResponse(buffer, as_attachment=True, filename=f'schoolnet_task_{pk}_{title}.zip',
                        content_type='application/zip')


@teacher_required
def export_assignments_day_zip(request):
    from .assignment_archive import archive_assignments, export_bundle, ExportSelectionForm, export_selection_groups

    teacher = request.user.teacher_profile
    assignments = archive_assignments(teacher)
    selection_error = ''
    selected_ids = set()
    response_status = 200
    if request.method == 'POST':
        raw_ids = request.POST.getlist('assignments')
        if not raw_ids:
            selection_error = 'Позначте хоча б одне завдання або оберіть цілий день.'
        else:
            try:
                try:
                    selected_ids = {int(value) for value in raw_ids}
                except ValueError:
                    raise ValueError('Некоректний вибір завдань.') from None
                if any(value < 1 or value > 9223372036854775807 for value in selected_ids):
                    raise ValueError('Некоректний вибір завдань.')
                selected = list(assignments.filter(pk__in=selected_ids).order_by('pk'))
                if {assignment.pk for assignment in selected} != selected_ids:
                    selection_error = 'Одне з обраних завдань недоступне. Оновіть список і повторіть вибір.'
                    response_status = 400
                else:
                    buffer = export_bundle(selected, teacher)
                    stamp = timezone.localdate().strftime('%Y%m%d')
                    return FileResponse(buffer, as_attachment=True,
                                        filename=f'schoolnet_export_{stamp}_{len(selected)}_tasks.zip',
                                        content_type='application/zip')
            except (ValueError, OverflowError) as error:
                selection_error = str(error) if isinstance(error, ValueError) else 'Некоректний вибір завдань.'
                response_status = 400
    form = ExportSelectionForm(request.GET)
    groups = export_selection_groups(assignments, form.cleaned_data) if form.is_valid() else []
    return render(request, 'feed/export_assignments.html', {
        'teacher': teacher, 'filter_form': form, 'groups': groups,
        'assignment_count': len({row['assignment'].pk for group in groups for row in group['rows']}),
        'selection_error': selection_error, 'selected_ids': selected_ids,
    }, status=response_status)


@teacher_required
def import_assignments_zip(request):
    from .assignment_archive import import_bundle

    if request.method == 'POST':
        archive = request.FILES.get('archive')
        if not archive:
            messages.error(request, 'Оберіть ZIP-архів із завданнями.')
            return redirect('teacher_dashboard')
        try:
            count, files = import_bundle(archive, request.user.teacher_profile)
        except (ValueError, ValidationError, zipfile.BadZipFile, UnicodeError, OSError, RuntimeError, TypeError, KeyError) as error:
            logger.warning('Assignment archive import failed: %s', error)
            messages.error(request, f'Імпорт не виконано: {error}')
        else:
            log_submission_activity(request.user, 'assignment_imported',
                                    f'Вчитель імпортував {count} завдань та {files} файлів із ZIP-архіву')
            messages.success(request, f'Імпортовано {count} завдань та {files} файлів. Класи, дати, уроки й налаштування відновлено.')
    return redirect('teacher_dashboard')



def ai_job_status(request, job_id):
    from .models import AIJob
    from .ai_jobs import job_response
    job = get_object_or_404(AIJob.objects.select_related('submission__assignment', 'assignment'), pk=job_id)
    if job.kind == 'understanding':
        assignment = job.assignment
        is_teacher = bool(request.user.is_authenticated and (request.user.is_superuser or
            getattr(request.user, 'teacher_profile', None) == assignment.teacher))
        if not is_teacher and not (assignment.allow_student_ai_understanding and
                assignment.status in (Assignment.STATUS_PUBLISHED, Assignment.STATUS_ARCHIVED)):
            return JsonResponse({'error': 'Немає доступу'}, status=403)
        return job_response(job, is_teacher=is_teacher, request=request)
    if job.kind != 'student_check':
        if not request.user.is_authenticated or not job.submission or not can_manage_submission(request, job.submission):
            return JsonResponse({'error': 'Немає доступу'}, status=403)
    return job_response(job, request=request)
