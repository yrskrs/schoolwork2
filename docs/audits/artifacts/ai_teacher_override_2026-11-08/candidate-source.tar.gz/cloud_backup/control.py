"""Framework-neutral input validation and safe page data."""
import json
import re
import uuid
from datetime import datetime
from zoneinfo import ZoneInfo

SECRET_FIELDS = ('password', 'app_password', 'client_secret', 'refresh_token')
GOOGLE_FIELDS = ('client_id', 'client_secret', 'refresh_token', 'public_url', 'oauth')


def profile(owner, scope):
    if scope not in ('personal', 'server'):
        raise ValueError('Некоректний обсяг')
    return str(owner)+'/'+scope


def configuration(state, owner, scope):
    return {'provider':'nextcloud', 'repository':'', 'scope':scope, 'format':'incremental',
            'materials':True, 'students':True, 'student_files':True, 'automatic':False,
            'hour':2, 'frequency':'daily', **state.config(profile(owner, scope))}


def save_config(state, owner, scope, form):
    old = configuration(state, owner, scope)
    config = {**old}
    config['provider'] = str(form.get('provider', 'nextcloud')).strip()
    for key in GOOGLE_FIELDS:
        config.pop(key, None)
    for key in ('format','url','username'):
        config[key] = str(form.get(key, old.get(key, ''))).strip()
    existing_repository = old['repository'] if old.get('provider') == 'nextcloud' else ''
    repository = str(form.get('repository', '')).strip() or existing_repository or uuid.uuid4().hex
    if not re.fullmatch('[a-f0-9]{32}', repository):
        raise ValueError('Ідентифікатор сховища: 32 символи 0–9, a–f')
    for key in ('password', 'app_password'):
        if form.get(key): config[key] = str(form[key])
    if form.get('clear_password'):
        config['password'] = ''
    # Password rotation starts a new independent repository; old snapshots keep
    # their original password and are never mixed with new encrypted blocks.
    config['recovery_only'] = form.get('recovery_only') in ('1','on','true',True)
    if not config['recovery_only'] and old.get('repository') == repository and config.get('password','') != old.get('password',''):
        repository = uuid.uuid4().hex
    if form.get('new_repository'):
        repository = uuid.uuid4().hex
    config['repository'] = repository
    if config['provider'] != 'nextcloud':
        raise ValueError('Для резервних копій доступний лише Nextcloud')
    if config['format'] not in ('incremental','zip'):
        raise ValueError('Оберіть формат зі списку')
    config['scope'] = scope
    for key in ('materials','students','student_files','automatic'):
        config[key] = form.get(key) in ('1','on','true',True)
    config['student_files'] = config['students'] and config['student_files']
    config['frequency'] = str(form.get('frequency', 'daily'))
    if config['frequency'] not in ('daily','weekly'):
        raise ValueError('Некоректний розклад')
    try:
        config['hour'] = int(form.get('hour', 2))
    except (ValueError,TypeError):
        raise ValueError('Некоректна година') from None
    if not 0 <= config['hour'] <= 23:
        raise ValueError('Година має бути від 0 до 23')
    if any(len(str(v)) > 8000 for v in config.values()):
        raise ValueError('Завелике значення налаштування')
    if config.get('recovery_only'):
        config['automatic'] = False
    if config['automatic']:
        check_connection(config)
    state.save(profile(owner, scope), config)
    return config


def require_nextcloud(config):
    if config.get('provider') != 'nextcloud':
        raise ValueError('Для резервних копій доступний лише Nextcloud. Збережіть підключення Nextcloud')


def check_connection(config):
    require_nextcloud(config)
    if not all(config.get(k) for k in ('url', 'username', 'app_password')):
        raise ValueError('Спочатку вкажіть адресу Nextcloud, користувача й пароль додатка та збережіть налаштування')


def page_data(state, owner, scope):
    config = configuration(state, owner, scope)
    public = {key:value for key,value in config.items() if key not in SECRET_FIELDS and key not in GOOGLE_FIELDS}
    public['has_password'] = bool(config.get('password'))
    public['has_nextcloud_password'] = bool(config.get('app_password'))
    public['needs_connection'] = config['provider'] != 'nextcloud'
    if public['needs_connection']:
        public.update(provider='nextcloud', automatic=False, repository='')
    history = [row for row in state.history(owner) if row.get('scope','personal') == scope]
    snapshots = []
    for row in history:
        row['result'] = json.loads(row['result'])
        kind_labels = {'backup':'Резервування','list':'Пошук копій','verify':'Перевірка','restore':'Відновлення','download':'Підготовка ZIP'}
        status_labels = {'queued':'У черзі','running':'Виконується','completed':'Завершено','failed':'Помилка'}
        row['kind_label'] = kind_labels.get(row['kind'],row['kind'])
        row['status_label'] = status_labels.get(row['status'],row['status'])
        row['created_label'] = datetime.fromtimestamp(row['created'],ZoneInfo('Europe/Kyiv')).strftime('%d.%m.%Y %H:%M')
        result = row['result']
        row['summary'] = f"Записів даних: {result.get('records','—')}; об’єктів: {result.get('objects',result.get('records','—'))}; файлів: {result.get('files',result.get('files_count','—'))}; даних: {result.get('original_bytes',0)/1048576:.2f} МіБ; передано: {result.get('uploaded_bytes',0)/1048576:.2f} МіБ; повторно використано: {result.get('reused_bytes',0)/1048576:.2f} МіБ."
        if not snapshots and row['kind'] == 'list' and row['status'] == 'completed' and row['result'].get('repository') == config['repository']:
            snapshots = row['result'].get('snapshots', [])
    if public['needs_connection']:
        snapshots = []
    choices = [{'value':snapshot,'label':datetime.fromtimestamp(int(snapshot.split('-')[0])/1000,ZoneInfo('Europe/Kyiv')).strftime('%d.%m.%Y %H:%M:%S · Київ')} for snapshot in snapshots]
    return {'backup':public, 'jobs':history, 'snapshots':snapshots, 'snapshot_choices':choices, 'backup_notices':state.notices(owner)}


def enqueue(state, owner, scope, action, form):
    config = configuration(state, owner, scope)
    check_connection(config)
    if action not in ('backup','list','verify','restore','download'):
        raise ValueError('Невідома дія')
    if action == 'backup' and config.get('recovery_only'):
        raise ValueError('Це сховище підключене лише для відновлення. Для нових копій створіть нове сховище')
    payload = {'config':config}
    if action in ('verify','restore','download'):
        snapshot = str(form.get('snapshot',''))
        if not re.fullmatch(r'[0-9]{13}-[a-f0-9]{32}\.zip', snapshot):
            raise ValueError('Спочатку знайдіть та оберіть копію')
        payload['snapshot'] = snapshot
        payload['config']['_snapshot'] = snapshot
    if action == 'restore' and str(form.get('confirmation','')).strip() != 'ВІДНОВИТИ':
        raise ValueError('Введіть ВІДНОВИТИ. Відновлення призначене для нового встановлення без робіт')
    return state.enqueue(owner, action, payload)
