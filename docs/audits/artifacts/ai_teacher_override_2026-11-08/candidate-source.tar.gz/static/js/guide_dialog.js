/**
 * Управління інтерактивною інструкцією користувача з розділенням для вчителів та учнів
 */
(function() {
    function detectCurrentGuideContext() {
        const path = window.location.pathname || '/';

        // Сторінки вчителя
        if (path.indexOf('/teacher/updates/') === 0) {
            return { tab: 'teacher', cat: 'teacher_updates', label: 'Оновлення системи' };
        }
        if (path.indexOf('/teacher/view-file/') === 0) {
            return { tab: 'teacher', cat: 'teacher_fileviewer', label: 'Перевірка роботи у File Viewer' };
        }
        if (path.indexOf('/teacher/gradebook/') === 0 || path.indexOf('/gradebook/') === 0) {
            return { tab: 'teacher', cat: 'teacher_gradebook', label: 'Електронний журнал оцінок' };
        }
        if (path.indexOf('/teacher/students/') === 0) {
            const search = window.location.search || '';
            if (search.indexOf('tab=schedule') !== -1) {
                return { tab: 'teacher', cat: 'teacher_classes', label: 'Тижневий розклад уроків' };
            }
            if (search.indexOf('tab=lessons') !== -1) {
                return { tab: 'teacher', cat: 'teacher_classes', label: 'Проведені теми уроків' };
            }
            return { tab: 'teacher', cat: 'teacher_classes', label: 'Керування класами та учнями' };
        }
        if (path.indexOf('/teacher/ai-settings/') === 0 || path.indexOf('/teacher/ai/batch-check/') === 0 || path.indexOf('/teacher/ai') === 0) {
            return { tab: 'teacher', cat: 'teacher_ai_settings', label: 'Модуль ШІ: Налаштування та пакетна перевірка' };
        }
        if (path.indexOf('/teacher/settings/') === 0 || path.indexOf('/teacher/profile/') === 0 || path.indexOf('/teacher/school/settings/') === 0) {
            const activePane = Array.from(document.querySelectorAll('.settings-tab-pane')).find(pane => pane.style.display !== 'none');
            const settingsTab = activePane ? activePane.id.replace('tab-section-', '') : new URLSearchParams(window.location.search).get('tab');
            if (settingsTab === 'ai') return { tab: 'teacher', cat: 'teacher_ai_settings', label: 'Модуль ШІ: підключення, критерії, моделі, статистика й помилки' };
            if (settingsTab === 'api') return { tab: 'teacher', cat: 'teacher_api_settings', label: 'API та журнал' };
            return { tab: 'teacher', cat: 'teacher_settings', label: settingsTab === 'environment' ? 'Середовище та заклад: розклад і обсяг даних' : 'Профіль і налаштування закладу' };
        }
        if (path.indexOf('/teacher/submissions/') === 0 || /\/teacher\/assignment\/\d+\/submissions\/?/.test(path)) {
            return { tab: 'teacher', cat: 'teacher_submissions', label: 'Всі здані роботи та черга перевірки' };
        }
        if (path.indexOf('/teacher/rescheduled-calendar/') === 0 || /\/teacher\/assignment\/\d+\/reschedule\/?/.test(path)) {
            return { tab: 'teacher', cat: 'teacher_reschedule', label: 'Перенесення уроків та 30-денний календар' };
        }
        if (path.indexOf('/teacher/reports/') === 0 || path.indexOf('/teacher/reports-pdf/') === 0) {
            return { tab: 'teacher', cat: 'teacher_reports', label: 'Звіти успішності та експорт у PDF' };
        }
        if (path.indexOf('/teacher/activity/') === 0 || path.indexOf('/teacher/database/backup/') === 0) {
            return { tab: 'teacher', cat: 'teacher_activity', label: 'Журнал дій (Аудит) та резервні копії' };
        }
        if (path.indexOf('/teacher/assignment/create/') === 0 || /\/teacher\/assignment\/\d+\/edit\/?/.test(path)) {
            return { tab: 'teacher', cat: 'teacher_dashboard', label: 'Створення та редагування завдання' };
        }
        if (path.indexOf('/teacher/') === 0) {
            return { tab: 'teacher', cat: 'teacher_dashboard', label: 'Кабінет вчителя (Завдання)' };
        }

        // Сторінки учня
        if (/\/assignment\/\d+\/submit\/success\/?/.test(path)) {
            return { tab: 'student', cat: 'submit_success', label: 'Результат здачі та самоперевірка ШІ' };
        }
        if (/\/assignment\/\d+\/submit\/?/.test(path)) {
            return { tab: 'student', cat: 'submit_assignment', label: 'Здача роботи (Завантаження файлів)' };
        }
        if (/\/assignment\/\d+\/?/.test(path)) {
            return { tab: 'student', cat: 'assignment_detail', label: 'Сторінка завдання (Умови та матеріали)' };
        }
        if (path.indexOf('/my-submissions/') === 0) {
            return { tab: 'student', cat: 'my_submissions', label: 'Портал «Мої роботи»' };
        }
        if (/\/submission\/\d+\/?/.test(path)) {
            return { tab: 'student', cat: 'submission_detail', label: 'Деталі зданої роботи' };
        }
        if (path === '/' || path.indexOf('/feed/') === 0) {
            return { tab: 'student', cat: 'index', label: 'Головна стрічка (Календар та пошук)' };
        }
        return { tab: 'student', cat: 'index', label: 'Головна стрічка (Календар та пошук)' };
    }

    function getActivePane() {
        const paneTeacher = document.getElementById('guide-pane-teacher');
        if (paneTeacher && paneTeacher.style.display !== 'none') {
            return paneTeacher;
        }
        return document.getElementById('guide-pane-student');
    }

    if (document.getElementById('user-menu')) {
    window.switchGuideTab = function(tab) {
        const paneTeacher = document.getElementById('guide-pane-teacher');
        const paneStudent = document.getElementById('guide-pane-student');
        const btnTeacher = document.getElementById('guide-tab-btn-teacher');
        const btnStudent = document.getElementById('guide-tab-btn-student');

        if (!paneTeacher || !paneStudent) return;

        if (tab === 'student') {
            paneTeacher.style.display = 'none';
            paneStudent.style.display = 'flex';
            if (btnStudent) { btnStudent.classList.add('btn-primary'); btnStudent.classList.remove('btn-secondary'); }
            if (btnTeacher) { btnTeacher.classList.add('btn-secondary'); btnTeacher.classList.remove('btn-primary'); }
        } else {
            paneTeacher.style.display = 'flex';
            paneStudent.style.display = 'none';
            if (btnTeacher) { btnTeacher.classList.add('btn-primary'); btnTeacher.classList.remove('btn-secondary'); }
            if (btnStudent) { btnStudent.classList.add('btn-secondary'); btnStudent.classList.remove('btn-primary'); }
        }

        const searchInput = document.getElementById('guide-search-input');
        if (searchInput) {
            searchInput.value = '';
            filterGuideTopics('');
        }
    };
    }

    let guideReturnFocus = null;
    window.openGuideModal = async function(explicitCat) {
        if (!await window.mountDeferredDialog("guide-template")) return;
        const modal = document.getElementById('guide-modal');
        if (!modal) return;

        guideReturnFocus = document.activeElement;
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        modal.querySelector('button[onclick="closeGuideModal()"]').focus({preventScroll: true});

        // Скидання пошукового рядка
        const searchInput = document.getElementById('guide-search-input');
        if (searchInput) {
            searchInput.value = '';
            filterGuideTopics('');
        }

        // Автоматичне або примусове визначення поточної сторінки/теми
        let context = detectCurrentGuideContext();
        if (explicitCat) {
            context = {
                tab: (explicitCat.indexOf('teacher_') === 0 ? 'teacher' : 'student'),
                cat: explicitCat,
                label: 'Обраний розділ інструкції'
            };
        }

        if (document.getElementById('user-menu')) {
        // Якщо вчитель — перемикаємо на відповідну вкладку
        if (context.tab === 'teacher') {
            switchGuideTab('teacher');
        } else {
            switchGuideTab('student');
        }
        }

        // Очищення попередніх активних станів
        const allBadges = modal.querySelectorAll('.guide-active-page-badge');
        allBadges.forEach(b => b.style.display = 'none');

        const allCards = modal.querySelectorAll('.guide-card');
        allCards.forEach(card => {
            card.classList.remove('guide-card-active', 'guide-card-open');
            const body = card.querySelector('.guide-card-body');
            const button = card.querySelector('.guide-card-header');
            if (body) body.style.display = 'none';
            if (button) button.setAttribute('aria-expanded', 'false');
        });

        const idSuffix = context.cat.replace(/_/g, '-');
        const targetBadge = document.getElementById('badge-guide-' + idSuffix);
        const targetCard = document.getElementById('guide-category-' + idSuffix);
        const targetBody = document.getElementById('body-guide-' + idSuffix);

        const contextBanner = document.getElementById('guide-current-context-banner');
        const contextLabel = document.getElementById('guide-current-page-label');

        if (targetBadge && targetCard && targetBody) {
            targetBadge.style.display = 'inline-flex';
            targetCard.classList.add('guide-card-active', 'guide-card-open');

            // Автоматично відкриваємо акордеон для поточної сторінки
            targetBody.style.display = 'block';
            const btn = targetCard.querySelector('.guide-card-header');
            if (btn) btn.setAttribute('aria-expanded', 'true');

            if (contextBanner && contextLabel) {
                contextLabel.textContent = context.label;
                contextBanner.style.display = 'flex';
            }

            // Плавний скрол до потрібної картки
            setTimeout(() => {
                targetCard.scrollIntoView({ behavior: window.SchoolNetPerformance ? window.SchoolNetPerformance.scrollBehavior() : 'smooth', block: 'nearest' });
            }, 100);
        } else {
            if (contextBanner) contextBanner.style.display = 'none';
        }
    };

    window.closeGuideModal = function() {
        const modal = document.getElementById('guide-modal');
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = '';
            if (guideReturnFocus && guideReturnFocus.isConnected) guideReturnFocus.focus({preventScroll: true});
        }
    };

    window.toggleGuideCategory = function(catKey) {
        const idSuffix = catKey.replace(/_/g, '-');
        const body = document.getElementById('body-guide-' + idSuffix);
        const card = document.getElementById('guide-category-' + idSuffix);
        if (!body || !card) return;

        const btn = card.querySelector('.guide-card-header');
        const isHidden = (body.style.display === 'none' || !body.style.display);

        if (isHidden) {
            body.style.display = 'block';
            if (btn) btn.setAttribute('aria-expanded', 'true');
            card.classList.add('guide-card-open');
            setTimeout(() => {
                card.scrollIntoView({ behavior: window.SchoolNetPerformance ? window.SchoolNetPerformance.scrollBehavior() : 'smooth', block: 'nearest' });
            }, 80);
        } else {
            body.style.display = 'none';
            if (btn) btn.setAttribute('aria-expanded', 'false');
            card.classList.remove('guide-card-open');
        }
    };

    window.expandAllGuideCategories = function() {
        const pane = getActivePane();
        if (!pane) return;
        const cards = pane.querySelectorAll('.guide-card');
        cards.forEach(card => {
            const body = card.querySelector('.guide-card-body');
            const btn = card.querySelector('.guide-card-header');
            if (body) body.style.display = 'block';
            if (btn) btn.setAttribute('aria-expanded', 'true');
            card.classList.add('guide-card-open');
        });
    };

    window.collapseAllGuideCategories = function() {
        const pane = getActivePane();
        if (!pane) return;
        const cards = pane.querySelectorAll('.guide-card');
        cards.forEach(card => {
            const body = card.querySelector('.guide-card-body');
            const btn = card.querySelector('.guide-card-header');
            if (body) body.style.display = 'none';
            if (btn) btn.setAttribute('aria-expanded', 'false');
            card.classList.remove('guide-card-open');
        });
    };

    window.filterGuideTopics = function(query) {
        const q = (query || '').trim().toLowerCase();
        const pane = getActivePane();
        if (!pane) return;
        const cards = pane.querySelectorAll('.guide-card');
        const noResults = document.getElementById('guide-no-results');
        let visibleCount = 0;

        cards.forEach(card => {
            const keywords = (card.getAttribute('data-keywords') || '').toLowerCase();
            const textContent = (card.textContent || '').toLowerCase();

            if (!q || keywords.indexOf(q) !== -1 || textContent.indexOf(q) !== -1) {
                card.style.display = 'flex';
                visibleCount++;
                if (q.length >= 2) {
                    const body = card.querySelector('.guide-card-body');
                    const btn = card.querySelector('.guide-card-header');
                    if (body) body.style.display = 'block';
                    if (btn) btn.setAttribute('aria-expanded', 'true');
                    card.classList.add('guide-card-open');
                }
            } else {
                card.style.display = 'none';
            }
        });

        if (noResults) {
            noResults.style.display = (visibleCount === 0) ? 'block' : 'none';
        }
    };

    // Закриття клавішею Escape
    document.addEventListener('keydown', function(e) {
        const dialog = document.getElementById('guide-modal');
        if (e.key === 'Tab' && dialog && dialog.style.display === 'flex') {
            const controls = Array.from(dialog.querySelectorAll('button, a[href], input, select, textarea, [tabindex="0"]')).filter(el => !el.disabled && el.getClientRects().length);
            const first = controls[0], last = controls[controls.length - 1];
            if (e.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) {
                e.preventDefault(); last.focus();
            } else if (!e.shiftKey && (document.activeElement === last || !dialog.contains(document.activeElement))) {
                e.preventDefault(); first.focus();
            }
        }
        if (e.key === 'Escape') {
            const m = document.getElementById('guide-modal');
            if (m && m.style.display === 'flex') {
                closeGuideModal();
            }
        }
    });

    // Закриття при кліку на затемнений фон
    document.addEventListener('click', function(e) {
        const m = document.getElementById('guide-modal');
        if (m && e.target === m) {
            closeGuideModal();
        }
    });
})();
